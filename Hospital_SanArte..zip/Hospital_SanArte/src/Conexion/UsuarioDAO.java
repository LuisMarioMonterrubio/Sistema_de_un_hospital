/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author socta
 */
public class UsuarioDAO {
    public boolean usuarioTieneDependencias(Long usuarioId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
 
    /**
     * Clase interna para representar un usuario completo
     */
    public static class UsuarioCompleto {
                private Long id;
        private String nombre;
        private String apellidos;
        private String identificacion;
        private String email;
        private String telefono;
        private String tipoUsuario;
        private String usuarioSistema;
        private boolean activo;
        private Date fechaCreacion;
        
        // Nuevos campos para pacientes, médicos y citas
        private Integer edad;
        private String direccion;
        private String especialidad;
        private Long idPaciente;
        private Long idMedico;
        private Date fechaCita;
        private String descripcionCita;
        private String nombrePaciente;
        private String nombreMedico;

        // Constructores
        public UsuarioCompleto() {}
        
        public UsuarioCompleto(Long id, String nombre, String apellidos, String identificacion,
                               String email, String telefono, String tipoUsuario, String usuarioSistema,
                               boolean activo, Date fechaCreacion) {
            this.id = id;
            this.nombre = nombre;
            this.apellidos = apellidos;
            this.identificacion = identificacion;
            this.email = email;
            this.telefono = telefono;
            this.tipoUsuario = tipoUsuario;
            this.usuarioSistema = usuarioSistema;
            this.activo = activo;
            this.fechaCreacion = fechaCreacion;
        }
        
        // Getters y Setters
        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        
        public String getNombre() { return nombre; }
        public void setNombre(String nombre) { this.nombre = nombre; }
        
        public String getApellidos() { return apellidos; }
        public void setApellidos(String apellidos) { this.apellidos = apellidos; }
        
        public String getNombreCompleto() {
            return (nombre != null ? nombre : "") + " " + (apellidos != null ? apellidos : "");
        }
        
        public String getIdentificacion() { return identificacion; }
        public void setIdentificacion(String identificacion) { this.identificacion = identificacion; }
        
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        
        public String getTelefono() { return telefono; }
        public void setTelefono(String telefono) { this.telefono = telefono; }
        
        public String getTipoUsuario() { return tipoUsuario; }
        public void setTipoUsuario(String tipoUsuario) { this.tipoUsuario = tipoUsuario; }
        
        public String getUsuarioSistema() { return usuarioSistema; }
        public void setUsuarioSistema(String usuarioSistema) { this.usuarioSistema = usuarioSistema; }
        
        public boolean isActivo() { return activo; }
        public void setActivo(boolean activo) { this.activo = activo; }
        
        public Date getFechaCreacion() { return fechaCreacion; }
        public void setFechaCreacion(Date fechaCreacion) { this.fechaCreacion = fechaCreacion; }
        
        public Integer getEdad() { return edad; }
        public void setEdad(Integer edad) { this.edad = edad; }
        
        public String getDireccion() { return direccion; }
        public void setDireccion(String direccion) { this.direccion = direccion; }
        
        public String getEspecialidad() { return especialidad; }
        public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }
        
        public Long getIdPaciente() { return idPaciente; }
        public void setIdPaciente(Long idPaciente) { this.idPaciente = idPaciente; }
        
        public Long getIdMedico() { return idMedico; }
        public void setIdMedico(Long idMedico) { this.idMedico = idMedico; }
        
        public Date getFechaCita() { return fechaCita; }
        public void setFechaCita(Date fechaCita) { this.fechaCita = fechaCita; }
        
        public String getDescripcionCita() { return descripcionCita; }
        public void setDescripcionCita(String descripcionCita) { this.descripcionCita = descripcionCita; }
        
        public String getNombrePaciente() { return nombrePaciente; }
        public void setNombrePaciente(String nombrePaciente) { this.nombrePaciente = nombrePaciente; }
        
        public String getNombreMedico() { return nombreMedico; }
        public void setNombreMedico(String nombreMedico) { this.nombreMedico = nombreMedico; }
    }

    
    /**
     * GENERAR PRÓXIMO ID DISPONIBLE
     */
    public Long generarProximoId() {
        String sql = "SELECT nextval('usuarios_id_seq') as proximo_id";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            if (rs.next()) {
                return rs.getLong("proximo_id");
            }
            
        } catch (SQLException e) {
            System.err.println("Error al generar próximo ID: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * INSERTAR NUEVO USUARIO CON ID AUTO-GENERADO
     */
    public boolean insertarUsuario(UsuarioCompleto usuario, Long tipoUsuarioId) {
        String sql = "INSERT INTO usuarios (nombre, apellidos, identificacion, email, telefono, " +
                    "tipo_usuario_id, usuario_sistema, activo) VALUES (?, ?, ?, ?, ?, ?, ?, ?) RETURNING id";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, usuario.getNombre());
            pstmt.setString(2, usuario.getApellidos());
            pstmt.setString(3, usuario.getIdentificacion());
            pstmt.setString(4, usuario.getEmail());
            pstmt.setString(5, usuario.getTelefono() != null ? usuario.getTelefono() : "");
            pstmt.setLong(6, tipoUsuarioId);
            pstmt.setString(7, usuario.getUsuarioSistema());
            pstmt.setBoolean(8, true);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                Long idGenerado = rs.getLong("id");
                usuario.setId(idGenerado);
                System.out.println("✅ Usuario insertado con ID: " + idGenerado);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error al insertar usuario: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * ACTUALIZAR USUARIO
     */
    public boolean actualizarUsuario(Long id, String nombre, String apellidos, String tipoUsuario, String identificacion, String email) {
        // Validar que no existan duplicados (excluyendo el registro actual)
        if (existeIdentificacionExcluyendoId(identificacion, id)) {
            System.err.println("Ya existe otro usuario con esta identificación");
            return false;
        }
        
        if (existeEmailExcluyendoId(email, id)) {
            System.err.println("Ya existe otro usuario con este email");
            return false;
        }
        
        String sql = "UPDATE usuarios SET nombre = ?, apellidos = ?, identificacion = ?, email = ?, tipo_usuario_id = ? WHERE id = ? AND activo = true";
        
        try (Connection conn = ConexionDB.getConexion()) {
            Long tipoUsuarioId = obtenerIdTipoUsuario(tipoUsuario);
            if (tipoUsuarioId == null) {
                System.err.println("Tipo de usuario no encontrado: " + tipoUsuario);
                return false;
            }
            
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, nombre);
                pstmt.setString(2, apellidos);
                pstmt.setString(3, identificacion);
                pstmt.setString(4, email);
                pstmt.setLong(5, tipoUsuarioId);
                pstmt.setLong(6, id);
                
                int filasAfectadas = pstmt.executeUpdate();
                return filasAfectadas > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al actualizar usuario: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * OBTENER TODOS LOS USUARIOS ACTIVOS
     */
    public List<UsuarioCompleto> obtenerTodosLosUsuarios() {
        String sql = "SELECT u.id, u.nombre, u.apellidos, u.identificacion, u.email, u.telefono, " +
                    "tu.nombre as tipo_usuario, u.usuario_sistema, u.activo, u.fecha_creacion " +
                    "FROM usuarios u " +
                    "JOIN tipos_usuario tu ON u.tipo_usuario_id = tu.id " +
                    "WHERE u.activo = true " +
                    "ORDER BY u.nombre, u.apellidos";
        
        List<UsuarioCompleto> usuarios = new ArrayList<>();
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                UsuarioCompleto usuario = new UsuarioCompleto();
                usuario.setId(rs.getLong("id"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setApellidos(rs.getString("apellidos"));
                usuario.setIdentificacion(rs.getString("identificacion"));
                usuario.setEmail(rs.getString("email"));
                usuario.setTelefono(rs.getString("telefono"));
                usuario.setTipoUsuario(rs.getString("tipo_usuario"));
                usuario.setUsuarioSistema(rs.getString("usuario_sistema"));
                usuario.setActivo(rs.getBoolean("activo"));
                usuario.setFechaCreacion(rs.getDate("fecha_creacion"));
                
                usuarios.add(usuario);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener usuarios: " + e.getMessage());
            e.printStackTrace();
        }
        
        return usuarios;
    }
    
    /**
     * BUSCAR USUARIOS POR CRITERIO
     */
    public List<UsuarioCompleto> buscarUsuarios(String textoBusqueda, String criterio) {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT u.id, u.nombre, u.apellidos, u.identificacion, u.email, u.telefono, ");
        sql.append("tu.nombre as tipo_usuario, u.usuario_sistema, u.activo, u.fecha_creacion ");
        sql.append("FROM usuarios u ");
        sql.append("JOIN tipos_usuario tu ON u.tipo_usuario_id = tu.id ");
        sql.append("WHERE u.activo = true ");
        
        // Agregar condición de búsqueda según el criterio
        switch (criterio.toLowerCase()) {
            case "nombre":
                sql.append("AND LOWER(u.nombre) LIKE LOWER(?) ");
                break;
            case "apellidos":
                sql.append("AND LOWER(u.apellidos) LIKE LOWER(?) ");
                break;
            case "identificación":
                sql.append("AND u.identificacion LIKE ? ");
                break;
            case "tipo de usuario":
                sql.append("AND LOWER(tu.nombre) LIKE LOWER(?) ");
                break;
            default:
                // Búsqueda general en todos los campos
                sql.append("AND (LOWER(u.nombre) LIKE LOWER(?) OR LOWER(u.apellidos) LIKE LOWER(?) ");
                sql.append("OR u.identificacion LIKE ? OR LOWER(tu.nombre) LIKE LOWER(?)) ");
                break;
        }
        
        sql.append("ORDER BY u.nombre, u.apellidos");
        
        List<UsuarioCompleto> usuarios = new ArrayList<>();
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            String parametroBusqueda = "%" + textoBusqueda + "%";
            
            if (criterio.toLowerCase().equals("general")) {
                // Para búsqueda general, establecer el parámetro en todas las posiciones
                pstmt.setString(1, parametroBusqueda);
                pstmt.setString(2, parametroBusqueda);
                pstmt.setString(3, parametroBusqueda);
                pstmt.setString(4, parametroBusqueda);
            } else {
                // Para búsqueda específica, solo un parámetro
                pstmt.setString(1, parametroBusqueda);
            }
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                UsuarioCompleto usuario = new UsuarioCompleto();
                usuario.setId(rs.getLong("id"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setApellidos(rs.getString("apellidos"));
                usuario.setIdentificacion(rs.getString("identificacion"));
                usuario.setEmail(rs.getString("email"));
                usuario.setTelefono(rs.getString("telefono"));
                usuario.setTipoUsuario(rs.getString("tipo_usuario"));
                usuario.setUsuarioSistema(rs.getString("usuario_sistema"));
                usuario.setActivo(rs.getBoolean("activo"));
                usuario.setFechaCreacion(rs.getDate("fecha_creacion"));
                
                usuarios.add(usuario);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al buscar usuarios: " + e.getMessage());
            e.printStackTrace();
        }
        
        return usuarios;
    }
    
    /**
     * ELIMINAR USUARIO (Eliminación lógica)
     */
    public boolean eliminarUsuario(Long usuarioId) {
        String sql = "UPDATE usuarios SET activo = false WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, usuarioId);
            
            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al eliminar usuario: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * OBTENER TIPOS DE USUARIO
     */
    public List<String> obtenerTiposUsuario() {
        String sql = "SELECT nombre FROM tipos_usuario WHERE activo = true ORDER BY nombre";
        List<String> tipos = new ArrayList<>();
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                tipos.add(rs.getString("nombre"));
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener tipos de usuario: " + e.getMessage());
            e.printStackTrace();
        }
        
        return tipos;
    }
    
    /**
     * OBTENER ID DE TIPO DE USUARIO POR NOMBRE
     */
    public Long obtenerIdTipoUsuario(String nombreTipo) {
        String sql = "SELECT id FROM tipos_usuario WHERE nombre = ? AND activo = true";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, nombreTipo);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getLong("id");
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener ID tipo usuario: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * VERIFICAR SI EXISTE IDENTIFICACIÓN
     */
    public boolean existeIdentificacion(String identificacion) {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE identificacion = ? AND activo = true";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, identificacion);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al verificar identificación: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * VERIFICAR SI EXISTE EMAIL
     */
    public boolean existeEmail(String email) {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE email = ? AND activo = true";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al verificar email: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * VERIFICAR SI EXISTE IDENTIFICACIÓN EXCLUYENDO UN ID ESPECÍFICO
     */
    public boolean existeIdentificacionExcluyendoId(String identificacion, Long idExcluir) {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE identificacion = ? AND id != ? AND activo = true";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, identificacion);
            pstmt.setLong(2, idExcluir);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al verificar identificación: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * VERIFICAR SI EXISTE EMAIL EXCLUYENDO UN ID ESPECÍFICO
     */
    public boolean existeEmailExcluyendoId(String email, Long idExcluir) {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE email = ? AND id != ? AND activo = true";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, email);
            pstmt.setLong(2, idExcluir);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al verificar email: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * VALIDAR FORMATO DE EMAIL
     */
    public boolean validarFormatoEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        
        // Validación básica de email
        String emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return email.matches(emailRegex);
    }
    
    /**
     * GENERAR USUARIO SISTEMA ÚNICO
     */
    public String generarUsuarioSistemaUnico(String nombre, String apellidos) {
        String baseUsuario = nombre.substring(0, 1).toLowerCase() +
                            apellidos.replace(" ", "").toLowerCase();
        
        String usuarioFinal = baseUsuario;
        int contador = 1;
        
        // Verificar si el usuario ya existe y generar uno único
        while (existeUsuarioSistema(usuarioFinal)) {
            usuarioFinal = baseUsuario + contador;
            contador++;
        }
        
        return usuarioFinal;
    }
    
    /**
     * VERIFICAR SI EXISTE USUARIO SISTEMA
     */
    public boolean existeUsuarioSistema(String usuarioSistema) {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE usuario_sistema = ? AND activo = true";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, usuarioSistema);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al verificar usuario sistema: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    
      // ========================================================================
    // NUEVOS MÉTODOS PARA PACIENTES, MÉDICOS Y CITAS
    // ========================================================================
    
    /**
     * OBTENER TODOS LOS REGISTROS DE UN TIPO ESPECÍFICO
     */
    public List<UsuarioCompleto> obtenerTodosLosRegistros(String tipo) {
        List<UsuarioCompleto> registros = new ArrayList<>();
        String sql = "";
        
        switch(tipo) {
            case "PACIENTE":
                sql = "SELECT * FROM paciente";
                break;
            case "MÉDICO":
                sql = "SELECT * FROM medico";
                break;
            case "CITA":
                sql = "SELECT c.id_cita, p.nombre AS paciente_nombre, m.nombre AS medico_nombre, " +
                      "c.fecha, c.descripcion, c.id_paciente, c.id_medico " +
                      "FROM cita c " +
                      "JOIN paciente p ON c.id_paciente = p.id_paciente " +
                      "JOIN medico m ON c.id_medico = m.id_medico";
                break;
        }
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                UsuarioCompleto registro = new UsuarioCompleto();
                switch(tipo) {
                    case "PACIENTE":
                        registro.setId(rs.getLong("id_paciente"));
                        registro.setNombre(rs.getString("nombre"));
                        registro.setEdad(rs.getInt("edad"));
                        registro.setDireccion(rs.getString("direccion"));
                        break;
                    case "MÉDICO":
                        registro.setId(rs.getLong("id_medico"));
                        registro.setNombre(rs.getString("nombre"));
                        registro.setEspecialidad(rs.getString("especialidad"));
                        break;
                    case "CITA":
                        registro.setId(rs.getLong("id_cita"));
                        registro.setNombrePaciente(rs.getString("paciente_nombre"));
                        registro.setNombreMedico(rs.getString("medico_nombre"));
                        registro.setFechaCita(rs.getDate("fecha"));
                        registro.setDescripcionCita(rs.getString("descripcion"));
                        registro.setIdPaciente(rs.getLong("id_paciente"));
                        registro.setIdMedico(rs.getLong("id_medico"));
                        break;
                }
                registros.add(registro);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener registros: " + e.getMessage());
            e.printStackTrace();
        }
        return registros;
    }
    
    /**
     * INSERTAR NUEVO PACIENTE
     */
    public boolean insertarPaciente(String nombre, int edad, String direccion) {
        String sql = "INSERT INTO paciente (nombre, edad, direccion) VALUES (?, ?, ?)";
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            pstmt.setInt(2, edad);
            pstmt.setString(3, direccion);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar paciente: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * ACTUALIZAR PACIENTE
     */
    public boolean actualizarPaciente(Long id, String nombre, int edad, String direccion) {
        String sql = "UPDATE paciente SET nombre = ?, edad = ?, direccion = ? WHERE id_paciente = ?";
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            pstmt.setInt(2, edad);
            pstmt.setString(3, direccion);
            pstmt.setLong(4, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar paciente: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * ELIMINAR PACIENTE
     */
    public boolean eliminarPaciente(Long id) {
        if (tieneCitasAsociadas(id, "paciente")) {
            System.err.println("No se puede eliminar, tiene citas asociadas");
            return false;
        }
        
        String sql = "DELETE FROM paciente WHERE id_paciente = ?";
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar paciente: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * INSERTAR NUEVO MÉDICO
     */
    public boolean insertarMedico(String nombre, String especialidad) {
        String sql = "INSERT INTO medico (nombre, especialidad) VALUES (?, ?)";
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            pstmt.setString(2, especialidad);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar médico: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * ACTUALIZAR MÉDICO
     */
    public boolean actualizarMedico(Long id, String nombre, String especialidad) {
        String sql = "UPDATE medico SET nombre = ?, especialidad = ? WHERE id_medico = ?";
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            pstmt.setString(2, especialidad);
            pstmt.setLong(3, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar médico: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * ELIMINAR MÉDICO
     */
    public boolean eliminarMedico(Long id) {
        if (tieneCitasAsociadas(id, "medico")) {
            System.err.println("No se puede eliminar, tiene citas asociadas");
            return false;
        }
        
        String sql = "DELETE FROM medico WHERE id_medico = ?";
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar médico: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * INSERTAR NUEVA CITA
     */
    public boolean insertarCita(Long idPaciente, Long idMedico, Date fecha, String descripcion) {
        String sql = "INSERT INTO cita (id_paciente, id_medico, fecha, descripcion) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, idPaciente);
            pstmt.setLong(2, idMedico);
            pstmt.setDate(3, new java.sql.Date(fecha.getTime()));
            pstmt.setString(4, descripcion);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar cita: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * ACTUALIZAR CITA
     */
    public boolean actualizarCita(Long id, Long idPaciente, Long idMedico, Date fecha, String descripcion) {
        String sql = "UPDATE cita SET id_paciente = ?, id_medico = ?, fecha = ?, descripcion = ? WHERE id_cita = ?";
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, idPaciente);
            pstmt.setLong(2, idMedico);
            pstmt.setDate(3, new java.sql.Date(fecha.getTime()));
            pstmt.setString(4, descripcion);
            pstmt.setLong(5, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar cita: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * ELIMINAR CITA
     */
    public boolean eliminarCita(Long id) {
        String sql = "DELETE FROM cita WHERE id_cita = ?";
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar cita: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * VERIFICAR SI UN REGISTRO TIENE CITAS ASOCIADAS
     */
    private boolean tieneCitasAsociadas(Long id, String tipo) {
        String sql = "SELECT COUNT(*) FROM cita WHERE " + 
                    (tipo.equals("paciente") ? "id_paciente" : "id_medico") + " = ?";
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        } catch (SQLException e) {
            System.err.println("Error al verificar dependencias: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * OBTENER TODOS LOS PACIENTES PARA COMBOBOX
     */
    public List<UsuarioCompleto> obtenerTodosPacientes() {
        String sql = "SELECT id_paciente, nombre FROM paciente ORDER BY nombre";
        return obtenerEntidadesParaCombo(sql);
    }
    
    /**
     * OBTENER TODOS LOS MÉDICOS PARA COMBOBOX
     */
    public List<UsuarioCompleto> obtenerTodosMedicos() {
        String sql = "SELECT id_medico, nombre FROM medico ORDER BY nombre";
        return obtenerEntidadesParaCombo(sql);
    }
    
    private List<UsuarioCompleto> obtenerEntidadesParaCombo(String sql) {
        List<UsuarioCompleto> entidades = new ArrayList<>();
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                UsuarioCompleto entidad = new UsuarioCompleto();
                entidad.setId(rs.getLong(1));
                entidad.setNombre(rs.getString(2));
                entidades.add(entidad);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener datos para combo: " + e.getMessage());
            e.printStackTrace();
        }
        return entidades;
    }

}