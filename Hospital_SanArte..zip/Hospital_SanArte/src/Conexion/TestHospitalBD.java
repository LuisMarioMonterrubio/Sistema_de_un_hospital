/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Conexion;
import Conexion.ConexionDB;
import Conexion.PacienteDAO;
import Conexion.Paciente;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author socta
 */
public class TestHospitalBD {
    private static Scanner scanner = new Scanner(System.in);
    private static PacienteDAO pacienteDAO = new PacienteDAO();
    private static CitaDAO citaDAO = new CitaDAO();
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    
    public static void main(String[] args) {
        System.out.println("=== SISTEMA DE PRUEBA - HOSPITAL SANARTE ===");
        System.out.println("Iniciando pruebas de conexión y funcionalidad...\n");
        
        // 1. Probar conexión
        if (probarConexion()) {
            System.out.println("✅ Conexión exitosa!\n");
            
            // 2. Mostrar menú de pruebas
            mostrarMenu();
        } else {
            System.out.println("❌ Error de conexión. Verifica tu configuración.");
            System.out.println("Revisa:");
            System.out.println("- Que PostgreSQL esté ejecutándose");
            System.out.println("- La contraseña en ConexionDB.java");
            System.out.println("- Que la base de datos 'hospital_sanarte' exista");
            System.out.println("- Que el schema 'hospital' y las tablas estén creadas");
        }
    }
    
    // Probar conexión a la base de datos
    private static boolean probarConexion() {
        System.out.println("🔗 Probando conexión a la base de datos...");
        
        try {
            Connection conn = ConexionDB.getConexion();
            if (conn != null && !conn.isClosed()) {
                System.out.println("✅ Conexión establecida correctamente");
                
                // Probar que el schema hospital existe
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'hospital'");
                if (rs.next()) {
                    int tablas = rs.getInt(1);
                    System.out.println("✅ Schema 'hospital' encontrado con " + tablas + " tablas");
                    
                    if (tablas > 0) {
                        return true;
                    } else {
                        System.out.println("⚠️  El schema 'hospital' existe pero no tiene tablas");
                        return false;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("❌ Error de conexión: " + e.getMessage());
            return false;
        }
        
        return false;
    }
    
    // Mostrar menú de opciones
    private static void mostrarMenu() {
        int opcion;
        
        do {
            System.out.println("\n=== MENÚ DE PRUEBAS ===");
            System.out.println("1. Mostrar todas las tablas");
            System.out.println("2. Mostrar datos existentes");
            System.out.println("3. Probar PacienteDAO - Listar pacientes");
            System.out.println("4. Probar PacienteDAO - Buscar paciente por ID");
            System.out.println("5. Probar PacienteDAO - Historial médico");
            System.out.println("6. Probar CitaDAO - Listar citas");
            System.out.println("7. Probar CitaDAO - Crear nueva cita");
            System.out.println("8. Probar CitaDAO - Estadísticas");
            System.out.println("9. Prueba completa CRUD Pacientes");
            System.out.println("10. Prueba completa CRUD Citas");
            System.out.println("0. Salir");
            System.out.print("Selecciona una opción: ");
            
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer
            
            switch (opcion) {
                case 1: mostrarTablas(); break;
                case 2: mostrarDatosExistentes(); break;
                case 3: probarListarPacientes(); break;
                case 4: probarBuscarPaciente(); break;
                case 5: probarHistorialMedico(); break;
                case 6: probarListarCitas(); break;
                case 7: probarCrearCita(); break;
                case 8: probarEstadisticasCitas(); break;
                case 9: pruebaCompletaPacientes(); break;
                case 10: pruebaCompletaCitas(); break;
                case 0: System.out.println("¡Hasta luego!"); break;
                default: System.out.println("Opción no válida");
            }
            
        } while (opcion != 0);
        
        // Cerrar conexión al salir
        ConexionDB.cerrarConexion();
    }
    
    // 1. Mostrar todas las tablas
    private static void mostrarTablas() {
        System.out.println("\n📋 TABLAS EN EL SCHEMA 'hospital':");
        
        try (Connection conn = ConexionDB.getConexion()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(
                "SELECT table_name FROM information_schema.tables " +
                "WHERE table_schema = 'hospital' ORDER BY table_name"
            );
            
            int contador = 1;
            while (rs.next()) {
                System.out.println(contador + ". " + rs.getString("table_name"));
                contador++;
            }
            
        } catch (SQLException e) {
            System.out.println("❌ Error al obtener tablas: " + e.getMessage());
        }
    }
    
    // 2. Mostrar datos existentes
    private static void mostrarDatosExistentes() {
        System.out.println("\n📊 DATOS EXISTENTES EN LA BASE DE DATOS:");
        
        try (Connection conn = ConexionDB.getConexion()) {
            Statement stmt = conn.createStatement();
            
            // Contar registros en cada tabla principal
            String[] tablas = {"tipos_usuario", "usuarios", "especialidades", "medicos", "pacientes", "consultas"};
            
            for (String tabla : tablas) {
                ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM " + tabla);
                if (rs.next()) {
                    System.out.println("• " + tabla + ": " + rs.getInt(1) + " registros");
                }
            }
            
        } catch (SQLException e) {
            System.out.println("❌ Error al contar registros: " + e.getMessage());
        }
    }
    
    // 3. Probar listar pacientes
    private static void probarListarPacientes() {
        System.out.println("\n👥 PROBANDO: Obtener historial médico de paciente ID 1");
        
        Object[][] historial = pacienteDAO.obtenerHistorialMedico(1);
        
        if (historial.length > 0) {
            System.out.println("✅ Historial obtenido exitosamente:");
            System.out.println("Registros encontrados: " + historial.length);
            
            for (Object[] fila : historial) {
                System.out.printf("Fecha: %s | Doctor: %s | Diagnóstico: %s%n", 
                    fila[0], fila[1], fila[2]);
            }
        } else {
            System.out.println("⚠️ No se encontró historial para el paciente ID 1");
        }
    }
    
    // 4. Probar buscar paciente
    private static void probarBuscarPaciente() {
        System.out.println("\n🔍 PROBANDO: Buscar paciente por ID");
        System.out.print("Ingresa el ID del paciente: ");
        
        try {
            int id = scanner.nextInt();
            scanner.nextLine();
            
            Paciente paciente = pacienteDAO.obtenerPacientePorId(id);
            
            if (paciente != null) {
                System.out.println("✅ Paciente encontrado:");
                System.out.println("Nombre: " + paciente.getNombreCompleto());
                System.out.println("Identificación: " + paciente.getIdentificacion());
                System.out.println("Email: " + paciente.getEmail());
                System.out.println("Historia: " + paciente.getNumeroHistoria());
            } else {
                System.out.println("❌ No se encontró paciente con ID: " + id);
            }
            
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
            scanner.nextLine();
        }
    }
    
    // 5. Probar historial médico
    private static void probarHistorialMedico() {
        System.out.println("\n📋 PROBANDO: Obtener historial médico");
        System.out.print("Ingresa el ID del paciente: ");
        
        try {
            int id = scanner.nextInt();
            scanner.nextLine();
            
            Object[][] historial = pacienteDAO.obtenerHistorialMedico(id);
            
            if (historial.length > 0) {
                System.out.println("✅ Historial médico encontrado:");
                System.out.println("─".repeat(80));
                
                for (Object[] fila : historial) {
                    System.out.printf("📅 %s | 👨‍⚕️ %s%n", fila[0], fila[1]);
                    System.out.printf("🔍 Diagnóstico: %s%n", fila[2]);
                    System.out.printf("💊 Tratamiento: %s%n", fila[3]);
                    System.out.printf("📝 Receta: %s%n", fila[4]);
                    System.out.println("─".repeat(80));
                }
            } else {
                System.out.println("⚠️ No se encontró historial para el paciente ID: " + id);
            }
            
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
            scanner.nextLine();
        }
    }
    
    // 6. Probar listar citas
    private static void probarListarCitas() {
        System.out.println("\n📅 PROBANDO: Obtener citas de paciente");
        System.out.print("Ingresa el ID del paciente: ");
        
        try {
            int id = scanner.nextInt();
            scanner.nextLine();
            
            List<CitaDAO.Cita> citas = citaDAO.obtenerCitasPorPaciente(id);
            
            if (!citas.isEmpty()) {
                System.out.println("✅ Citas encontradas:");
                System.out.println("─".repeat(80));
                
                for (CitaDAO.Cita cita : citas) {
                    System.out.printf("ID: %d | Fecha: %s | Estado: %s%n", 
                        cita.getId(), cita.getFechaConsulta(), cita.getEstado());
                    System.out.printf("Motivo: %s%n", cita.getMotivoConsulta());
                    System.out.println("─".repeat(80));
                }
            } else {
                System.out.println("⚠️ No se encontraron citas para el paciente ID: " + id);
            }
            
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
            scanner.nextLine();
        }
    }
    
    // 7. Probar crear cita
    private static void probarCrearCita() {
        System.out.println("\n➕ PROBANDO: Crear nueva cita");
        
        try {
            System.out.print("ID del paciente: ");
            int pacienteId = scanner.nextInt();
            
            System.out.print("ID del médico: ");
            int medicoId = scanner.nextInt();
            scanner.nextLine();
            
            System.out.print("Motivo de la consulta: ");
            String motivo = scanner.nextLine();
            
            // Crear cita para mañana a las 10:00
            Timestamp fechaCita = new Timestamp(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
            
            CitaDAO.Cita nuevaCita = new CitaDAO.Cita(pacienteId, medicoId, fechaCita, motivo);
            
            if (citaDAO.insertarCita(nuevaCita)) {
                System.out.println("✅ Cita creada exitosamente con ID: " + nuevaCita.getId());
            } else {
                System.out.println("❌ Error al crear la cita");
            }
            
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
            scanner.nextLine();
        }
    }
    
    // 8. Probar estadísticas de citas
    private static void probarEstadisticasCitas() {
        System.out.println("\n📊 PROBANDO: Estadísticas de citas");
        
        Object[][] estadisticas = citaDAO.obtenerEstadisticasCitas();
        
        if (estadisticas.length > 0) {
            System.out.println("✅ Estadísticas obtenidas:");
            System.out.println("─".repeat(40));
            
            for (Object[] fila : estadisticas) {
                System.out.printf("Estado: %-15s | Cantidad: %d%n", fila[0], fila[1]);
            }
            System.out.println("─".repeat(40));
        } else {
            System.out.println("⚠️ No hay datos de citas disponibles");
        }
    }
    
    // 9. Prueba completa CRUD Pacientes
    private static void pruebaCompletaPacientes() {
        System.out.println("\n🧪 PRUEBA COMPLETA CRUD PACIENTES");
        
        try {
            // Buscar un paciente existente
            System.out.println("1️⃣ Buscando paciente ID 1...");
            Paciente paciente = pacienteDAO.obtenerPacientePorId(1);
            
            if (paciente != null) {
                System.out.println("✅ Paciente encontrado: " + paciente.getNombreCompleto());
                
                // Obtener historial
                System.out.println("2️⃣ Obteniendo historial médico...");
                Object[][] historial = pacienteDAO.obtenerHistorialMedico(1);
                System.out.println("✅ Historial obtenido: " + historial.length + " registros");
                
                // Obtener citas programadas
                System.out.println("3️⃣ Obteniendo citas programadas...");
                Object[][] citas = pacienteDAO.obtenerCitasProgramadas(1);
                System.out.println("✅ Citas programadas: " + citas.length + " registros");
                
                // Obtener mensajes
                System.out.println("4️⃣ Obteniendo mensajes...");
                List<String> mensajes = pacienteDAO.obtenerMensajesNotificaciones(1);
                System.out.println("✅ Mensajes obtenidos: " + mensajes.size() + " mensajes");
                
                System.out.println("\n🎉 PRUEBA COMPLETA PACIENTES EXITOSA");
            } else {
                System.out.println("❌ No se encontró el paciente ID 1");
            }
            
        } catch (Exception e) {
            System.out.println("❌ Error en prueba completa: " + e.getMessage());
        }
    }
    
    // 10. Prueba completa CRUD Citas
    private static void pruebaCompletaCitas() {
        System.out.println("\n🧪 PRUEBA COMPLETA CRUD CITAS");
        
        try {
            // Crear cita de prueba
            System.out.println("1️⃣ Creando cita de prueba...");
            Timestamp fechaCita = new Timestamp(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
            CitaDAO.Cita citaPrueba = new CitaDAO.Cita(1, 1, fechaCita, "Consulta de prueba CRUD");
            
            if (citaDAO.insertarCita(citaPrueba)) {
                System.out.println("✅ Cita creada con ID: " + citaPrueba.getId());
                
                // Buscar la cita creada
                System.out.println("2️⃣ Buscando cita creada...");
                CitaDAO.Cita citaEncontrada = citaDAO.obtenerCitaPorId(citaPrueba.getId());
                
                if (citaEncontrada != null) {
                    System.out.println("✅ Cita encontrada: " + citaEncontrada.getMotivoConsulta());
                    
                    // Actualizar estado
                    System.out.println("3️⃣ Actualizando estado a 'Confirmada'...");
                    if (citaDAO.actualizarEstadoCita(citaEncontrada.getId(), "Confirmada")) {
                        System.out.println("✅ Estado actualizado exitosamente");
                        
                        // Eliminar cita (cancelar)
                        System.out.println("4️⃣ Cancelando cita...");
                        if (citaDAO.eliminarCita(citaEncontrada.getId())) {
                            System.out.println("✅ Cita cancelada exitosamente");
                            System.out.println("\n🎉 PRUEBA COMPLETA CITAS EXITOSA");
                        } else {
                            System.out.println("❌ Error al cancelar cita");
                        }
                    } else {
                        System.out.println("❌ Error al actualizar estado");
                    }
                } else {
                    System.out.println("❌ No se pudo encontrar la cita creada");
                }
            } else {
                System.out.println("❌ Error al crear cita de prueba");
            }
            
        } catch (Exception e) {
            System.out.println("❌ Error en prueba completa citas: " + e.getMessage());
        }
    }
  
}
