/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author socta
 */
public class DoctorDAO {
    // Clase interna para representar un doctor completo
    public static class DoctorCompleto {
        private Long id;
        private String nombre;
        private String apellidos;
        private String identificacion;
        private String email;
        private String telefonoPersonal;
        private String telefonoConsultorio;
        private Integer aniosExperiencia;
        private String universidadEgreso;
        private String horarioConsulta;
        private String especialidad;
        private String certificaciones;

        // Getters y Setters
        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        
        public String getNombre() { return nombre; }
        public void setNombre(String nombre) { this.nombre = nombre; }
        
        public String getApellidos() { return apellidos; }
        public void setApellidos(String apellidos) { this.apellidos = apellidos; }
        
        public String getNombreCompleto() {
            return (nombre != null ? nombre : "") + " " + (apellidos != null ? apellidos : "");
        }
        
        public String getIdentificacion() { return identificacion; }
        public void setIdentificacion(String identificacion) { this.identificacion = identificacion; }
        
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        
        public String getTelefonoPersonal() { return telefonoPersonal; }
        public void setTelefonoPersonal(String telefonoPersonal) { this.telefonoPersonal = telefonoPersonal; }
        
        public String getTelefonoConsultorio() { return telefonoConsultorio; }
        public void setTelefonoConsultorio(String telefonoConsultorio) { this.telefonoConsultorio = telefonoConsultorio; }
        
        public Integer getAniosExperiencia() { return aniosExperiencia; }
        public void setAniosExperiencia(Integer aniosExperiencia) { this.aniosExperiencia = aniosExperiencia; }
        
        public String getUniversidadEgreso() { return universidadEgreso; }
        public void setUniversidadEgreso(String universidadEgreso) { this.universidadEgreso = universidadEgreso; }
        
        public String getHorarioConsulta() { return horarioConsulta; }
        public void setHorarioConsulta(String horarioConsulta) { this.horarioConsulta = horarioConsulta; }
        
        public String getEspecialidad() { return especialidad; }
        public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }
        
        public String getCertificaciones() { return certificaciones; }
        public void setCertificaciones(String certificaciones) { this.certificaciones = certificaciones; }
    }

    /**
     * OBTENER TODOS LOS DOCTORES CON DETALLES
     */
    public List<DoctorCompleto> obtenerTodosDoctores() {
        List<DoctorCompleto> doctores = new ArrayList<>();
        String sql = "SELECT u.id, u.nombre, u.apellidos, u.identificacion, u.email, u.telefono, "
                   + "dd.telefono_consultorio, dd.anios_experiencia, dd.universidad_egreso, dd.horario_consulta, "
                   + "e.nombre AS especialidad, "
                   + "STRING_AGG(dc.nombre_certificacion || ' (' || dc.institucion_emisora || ')', ', ') AS certificaciones "
                   + "FROM usuarios u "
                   + "JOIN medicos m ON u.id = m.usuario_id "
                   + "JOIN especialidades e ON m.especialidad_id = e.id "
                   + "JOIN doctor_detalles dd ON u.id = dd.usuario_id "
                   + "LEFT JOIN doctor_certificaciones dc ON dd.id_doctor = dc.doctor_id "
                   + "WHERE u.activo = true "
                   + "GROUP BY u.id, u.nombre, u.apellidos, u.identificacion, u.email, u.telefono, "
                   + "dd.telefono_consultorio, dd.anios_experiencia, dd.universidad_egreso, dd.horario_consulta, e.nombre "
                   + "ORDER BY u.apellidos, u.nombre";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                DoctorCompleto doctor = new DoctorCompleto();
                doctor.setId(rs.getLong("id"));
                doctor.setNombre(rs.getString("nombre"));
                doctor.setApellidos(rs.getString("apellidos"));
                doctor.setIdentificacion(rs.getString("identificacion"));
                doctor.setEmail(rs.getString("email"));
                doctor.setTelefonoPersonal(rs.getString("telefono"));
                doctor.setTelefonoConsultorio(rs.getString("telefono_consultorio"));
                doctor.setAniosExperiencia(rs.getInt("anios_experiencia"));
                doctor.setUniversidadEgreso(rs.getString("universidad_egreso"));
                doctor.setHorarioConsulta(rs.getString("horario_consulta"));
                doctor.setEspecialidad(rs.getString("especialidad"));
                doctor.setCertificaciones(rs.getString("certificaciones"));
                
                doctores.add(doctor);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener doctores: " + e.getMessage());
            e.printStackTrace();
        }
        
        return doctores;
    }
    
    /**
     * BUSCAR DOCTORES POR ESPECIALIDAD
     */
    public List<DoctorCompleto> buscarDoctoresPorEspecialidad(String especialidad) {
        List<DoctorCompleto> doctores = new ArrayList<>();
        String sql = "SELECT u.id, u.nombre, u.apellidos, u.identificacion, u.email, u.telefono, "
                   + "dd.telefono_consultorio, dd.anios_experiencia, dd.universidad_egreso, dd.horario_consulta, "
                   + "e.nombre AS especialidad, "
                   + "STRING_AGG(dc.nombre_certificacion || ' (' || dc.institucion_emisora || ')', ', ') AS certificaciones "
                   + "FROM usuarios u "
                   + "JOIN medicos m ON u.id = m.usuario_id "
                   + "JOIN especialidades e ON m.especialidad_id = e.id "
                   + "JOIN doctor_detalles dd ON u.id = dd.usuario_id "
                   + "LEFT JOIN doctor_certificaciones dc ON dd.id_doctor = dc.doctor_id "
                   + "WHERE u.activo = true AND LOWER(e.nombre) LIKE LOWER(?) "
                   + "GROUP BY u.id, u.nombre, u.apellidos, u.identificacion, u.email, u.telefono, "
                   + "dd.telefono_consultorio, dd.anios_experiencia, dd.universidad_egreso, dd.horario_consulta, e.nombre "
                   + "ORDER BY u.apellidos, u.nombre";

        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, "%" + especialidad + "%");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                DoctorCompleto doctor = new DoctorCompleto();
                doctor.setId(rs.getLong("id"));
                doctor.setNombre(rs.getString("nombre"));
                doctor.setApellidos(rs.getString("apellidos"));
                doctor.setIdentificacion(rs.getString("identificacion"));
                doctor.setEmail(rs.getString("email"));
                doctor.setTelefonoPersonal(rs.getString("telefono"));
                doctor.setTelefonoConsultorio(rs.getString("telefono_consultorio"));
                doctor.setAniosExperiencia(rs.getInt("anios_experiencia"));
                doctor.setUniversidadEgreso(rs.getString("universidad_egreso"));
                doctor.setHorarioConsulta(rs.getString("horario_consulta"));
                doctor.setEspecialidad(rs.getString("especialidad"));
                doctor.setCertificaciones(rs.getString("certificaciones"));
                
                doctores.add(doctor);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al buscar doctores: " + e.getMessage());
            e.printStackTrace();
        }
        
        return doctores;
    }

}
