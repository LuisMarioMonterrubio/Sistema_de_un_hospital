/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author Luis Mario
 */
public class ConexionDB {
   private static final String URL = "jdbc:postgresql://localhost:5432/hospital_sanarte?currentSchema=hospital";
    private static final String USUARIO = "postgres";
    private static final String PASSWORD = "DURAZNo2004";
    private static Connection conexion = null;
    
    // Método para conectar
    public static Connection getConexion() {
        try {
            if (conexion == null || conexion.isClosed()) {
                Class.forName("org.postgresql.Driver");
                conexion = DriverManager.getConnection(URL, USUARIO, PASSWORD);
                // Establecer el schema
                java.sql.Statement stmt = conexion.createStatement();
                stmt.execute("SET search_path TO hospital");
                System.out.println("Conexión exitosa a la base de datos");
            }
        } catch (Exception e) {
            System.err.println("Error de conexión: " + e.getMessage());
            e.printStackTrace();
        }
        return conexion;
    }
    
    // Método para cerrar conexión
    public static void cerrarConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                System.out.println("Conexión cerrada");
            }
        } catch (SQLException e) {
            System.err.println("Error al cerrar conexión: " + e.getMessage());
        }
    }

    public static boolean probarConexion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}