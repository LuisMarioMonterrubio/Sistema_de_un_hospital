/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import Conexion.ConexionDB;
/**
 *
 * @author Luis Mario
 */
public class CitaDAO {
public Object[][] obtenerCitasParaDoctorPorFecha(long idDoctor, java.sql.Date fecha) {
    String sql = "SELECT TO_CHAR(c.fecha_consulta, 'HH24:MI') AS hora, "
               + "CONCAT(u.nombre, ' ', u.apellidos) AS paciente, "
               + "c.motivo_consulta, c.estado "
               + "FROM consultas c "
               + "JOIN pacientes p ON c.paciente_id = p.id "
               + "JOIN usuarios u ON p.usuario_id = u.id "
               + "WHERE c.medico_id = ? AND DATE(c.fecha_consulta) = ? "
               + "ORDER BY c.fecha_consulta";
    
    List<Object[]> resultados = new ArrayList<>();
    
    try (Connection conn = ConexionDB.getConexion();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setLong(1, idDoctor);
        pstmt.setDate(2, fecha);
        ResultSet rs = pstmt.executeQuery();
        
        while (rs.next()) {
            Object[] fila = {
                rs.getString("hora"),
                rs.getString("paciente"),
                rs.getString("motivo_consulta"),
                rs.getString("estado")
            };
            resultados.add(fila);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return resultados.toArray(new Object[0][]);
}
    
    public static class Cita {
        private Long id;
        private int pacienteId;
        private int medicoId;
        private Timestamp fechaConsulta;
        private String motivoConsulta;
        private String diagnostico;
        private String tratamiento;
        private String observaciones;
        private String estado;
        private Timestamp fechaCreacion;
        
        // Constructores
        public Cita() {}
        
        public Cita(int pacienteId, int medicoId, Timestamp fechaConsulta, String motivoConsulta) {
            this.pacienteId = pacienteId;
            this.medicoId = medicoId;
            this.fechaConsulta = fechaConsulta;
            this.motivoConsulta = motivoConsulta;
            this.estado = "Programada";
            this.fechaCreacion = new Timestamp(System.currentTimeMillis());
        }
        
        // Getters y Setters
        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        
        public int getPacienteId() { return pacienteId; }
        public void setPacienteId(int pacienteId) { this.pacienteId = pacienteId; }
        
        public int getMedicoId() { return medicoId; }
        public void setMedicoId(int medicoId) { this.medicoId = medicoId; }
        
        public Timestamp getFechaConsulta() { return fechaConsulta; }
        public void setFechaConsulta(Timestamp fechaConsulta) { this.fechaConsulta = fechaConsulta; }
        
        public String getMotivoConsulta() { return motivoConsulta; }
        public void setMotivoConsulta(String motivoConsulta) { this.motivoConsulta = motivoConsulta; }
        
        public String getDiagnostico() { return diagnostico; }
        public void setDiagnostico(String diagnostico) { this.diagnostico = diagnostico; }
        
        public String getTratamiento() { return tratamiento; }
        public void setTratamiento(String tratamiento) { this.tratamiento = tratamiento; }
        
        public String getObservaciones() { return observaciones; }
        public void setObservaciones(String observaciones) { this.observaciones = observaciones; }
        
        public String getEstado() { return estado; }
        public void setEstado(String estado) { this.estado = estado; }
        
        public Timestamp getFechaCreacion() { return fechaCreacion; }
        public void setFechaCreacion(Timestamp fechaCreacion) { this.fechaCreacion = fechaCreacion; }
    }
    
    /**
     * INSERTAR NUEVA CITA
     */
    public boolean insertarCita(Cita cita) {
        String sql = "INSERT INTO consultas (paciente_id, medico_id, fecha_consulta, motivo_consulta, estado) " +
                    "VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, cita.getPacienteId());
            pstmt.setInt(2, cita.getMedicoId());
            pstmt.setTimestamp(3, cita.getFechaConsulta());
            pstmt.setString(4, cita.getMotivoConsulta());
            pstmt.setString(5, cita.getEstado());
            
            int filasAfectadas = pstmt.executeUpdate();
            
            if (filasAfectadas > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    cita.setId(rs.getLong(1));
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al insertar cita: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * OBTENER TODAS LAS CITAS DE UN PACIENTE
     */
    public List<Cita> obtenerCitasPorPaciente(int pacienteId) {
        String sql = "SELECT * FROM consultas WHERE paciente_id = ? ORDER BY fecha_consulta DESC";
        List<Cita> citas = new ArrayList<>();
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, pacienteId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Cita cita = new Cita();
                cita.setId(rs.getLong("id"));
                cita.setPacienteId(rs.getInt("paciente_id"));
                cita.setMedicoId(rs.getInt("medico_id"));
                cita.setFechaConsulta(rs.getTimestamp("fecha_consulta"));
                cita.setMotivoConsulta(rs.getString("motivo_consulta"));
                cita.setDiagnostico(rs.getString("diagnostico"));
                cita.setTratamiento(rs.getString("tratamiento"));
                cita.setObservaciones(rs.getString("observaciones"));
                cita.setEstado(rs.getString("estado"));
                cita.setFechaCreacion(rs.getTimestamp("fecha_creacion"));
                
                citas.add(cita);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener citas por paciente: " + e.getMessage());
            e.printStackTrace();
        }
        
        return citas;
    }
    
    /**
     * ACTUALIZAR ESTADO DE UNA CITA
     */
    public boolean actualizarEstadoCita(Long citaId, String nuevoEstado) {
        String sql = "UPDATE consultas SET estado = ? WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, nuevoEstado);
            pstmt.setLong(2, citaId);
            
            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al actualizar estado de cita: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * OBTENER CITAS POR FECHA
     */
    public List<Cita> obtenerCitasPorFecha(Date fecha) {
        String sql = "SELECT * FROM consultas WHERE DATE(fecha_consulta) = ? ORDER BY fecha_consulta";
        List<Cita> citas = new ArrayList<>();
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setDate(1, fecha);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Cita cita = new Cita();
                cita.setId(rs.getLong("id"));
                cita.setPacienteId(rs.getInt("paciente_id"));
                cita.setMedicoId(rs.getInt("medico_id"));
                cita.setFechaConsulta(rs.getTimestamp("fecha_consulta"));
                cita.setMotivoConsulta(rs.getString("motivo_consulta"));
                cita.setDiagnostico(rs.getString("diagnostico"));
                cita.setTratamiento(rs.getString("tratamiento"));
                cita.setObservaciones(rs.getString("observaciones"));
                cita.setEstado(rs.getString("estado"));
                cita.setFechaCreacion(rs.getTimestamp("fecha_creacion"));
                
                citas.add(cita);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener citas por fecha: " + e.getMessage());
            e.printStackTrace();
        }
        
        return citas;
    }
    
    /**
     * ELIMINAR CITA (Eliminación lógica)
     */
    public boolean eliminarCita(Long citaId) {
        return actualizarEstadoCita(citaId, "Cancelada");
    }
    
    /**
     * OBTENER ESTADÍSTICAS DE CITAS
     */
    public Object[][] obtenerEstadisticasCitas() {
        String sql = "SELECT estado, COUNT(*) as cantidad FROM consultas GROUP BY estado ORDER BY cantidad DESC";
        List<Object[]> filas = new ArrayList<>();
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                Object[] fila = {
                    rs.getString("estado"),
                    rs.getInt("cantidad")
                };
                filas.add(fila);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener estadísticas de citas: " + e.getMessage());
            e.printStackTrace();
        }
        
        return filas.toArray(new Object[0][]);
    }
    
    /**
     * BUSCAR CITA POR ID
     */
    public Cita obtenerCitaPorId(Long id) {
        String sql = "SELECT * FROM consultas WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                Cita cita = new Cita();
                cita.setId(rs.getLong("id"));
                cita.setPacienteId(rs.getInt("paciente_id"));
                cita.setMedicoId(rs.getInt("medico_id"));
                cita.setFechaConsulta(rs.getTimestamp("fecha_consulta"));
                cita.setMotivoConsulta(rs.getString("motivo_consulta"));
                cita.setDiagnostico(rs.getString("diagnostico"));
                cita.setTratamiento(rs.getString("tratamiento"));
                cita.setObservaciones(rs.getString("observaciones"));
                cita.setEstado(rs.getString("estado"));
                cita.setFechaCreacion(rs.getTimestamp("fecha_creacion"));
                
                return cita;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener cita por ID: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
}
