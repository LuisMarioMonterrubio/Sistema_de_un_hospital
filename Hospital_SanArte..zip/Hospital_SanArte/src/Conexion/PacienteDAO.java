/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;
import Conexion.ConexionDB;
import Conexion.Paciente;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author socta
 */
public class PacienteDAO {
    /**
     * OBTENER HISTORIAL MÉDICO DEL PACIENTE
     * Para cargar datos en tablaHistorial
     */
    public Object[][] obtenerHistorialMedico(int idPaciente) {
        String sql = "SELECT c.fecha_consulta, " +
                    "CONCAT(um.nombre, ' ', um.apellidos) as doctor, " +
                    "c.diagnostico, c.tratamiento, " +
                    "COALESCE(STRING_AGG(CONCAT(med.nombre, ' ', rm.dosis), ', '), 'N/A') as receta " +
                    "FROM consultas c " +
                    "JOIN pacientes p ON c.paciente_id = p.id " +
                    "JOIN medicos m ON c.medico_id = m.id " +
                    "JOIN usuarios um ON m.usuario_id = um.id " +
                    "LEFT JOIN recetas r ON c.id = r.consulta_id " +
                    "LEFT JOIN receta_medicamentos rm ON r.id = rm.receta_id " +
                    "LEFT JOIN medicamentos med ON rm.medicamento_id = med.id " +
                    "WHERE p.id = ? AND c.estado = 'Completada' " +
                    "GROUP BY c.id, c.fecha_consulta, um.nombre, um.apellidos, c.diagnostico, c.tratamiento " +
                    "ORDER BY c.fecha_consulta DESC";
        
        List<Object[]> filas = new ArrayList<>();
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPaciente);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Object[] fila = {
                    rs.getDate("fecha_consulta"),
                    rs.getString("doctor"),
                    rs.getString("diagnostico"),
                    rs.getString("tratamiento"),
                    rs.getString("receta")
                };
                filas.add(fila);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener historial médico: " + e.getMessage());
            e.printStackTrace();
        }
        
        return filas.toArray(new Object[0][]);
    }
    
    /**
     * OBTENER CITAS PROGRAMADAS DEL PACIENTE
     * Para cargar datos en tablaCitas
     */
    public Object[][] obtenerCitasProgramadas(int idPaciente) {
        String sql = "SELECT c.fecha_consulta, " +
                    "TO_CHAR(c.fecha_consulta, 'HH24:MI') as hora, " +
                    "CONCAT(um.nombre, ' ', um.apellidos) as doctor, " +
                    "e.nombre as especialidad, " +
                    "c.estado, c.id " +
                    "FROM consultas c " +
                    "JOIN pacientes p ON c.paciente_id = p.id " +
                    "JOIN medicos m ON c.medico_id = m.id " +
                    "JOIN usuarios um ON m.usuario_id = um.id " +
                    "JOIN especialidades e ON m.especialidad_id = e.id " +
                    "WHERE p.id = ? AND c.estado IN ('Programada', 'Confirmada') " +
                    "AND c.fecha_consulta >= CURRENT_DATE " +
                    "ORDER BY c.fecha_consulta ASC";
        
        List<Object[]> filas = new ArrayList<>();
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPaciente);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Object[] fila = {
                    rs.getDate("fecha_consulta"),
                    rs.getString("hora"),
                    rs.getString("doctor"),
                    rs.getString("especialidad"),
                    rs.getString("estado"),
                    "" // Columna de acciones (botón)
                };
                filas.add(fila);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener citas programadas: " + e.getMessage());
            e.printStackTrace();
        }
        
        return filas.toArray(new Object[0][]);
    }
    
    /**
     * OBTENER AGENDA DISPONIBLE
     * Para cargar datos en tablaAgenda
     */
    public Object[][] obtenerAgendaDisponible(String especialidadFiltro, String fechaFiltro) {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT DISTINCT c.fecha_consulta, ");
        sql.append("TO_CHAR(c.fecha_consulta, 'HH24:MI') as hora, ");
        sql.append("CONCAT(um.nombre, ' ', um.apellidos) as medico, ");
        sql.append("e.nombre as especialidad, ");
        sql.append("m.id as medico_id ");
        sql.append("FROM consultas c ");
        sql.append("JOIN medicos m ON c.medico_id = m.id ");
        sql.append("JOIN usuarios um ON m.usuario_id = um.id ");
        sql.append("JOIN especialidades e ON m.especialidad_id = e.id ");
        sql.append("WHERE c.estado = 'Disponible' ");
        sql.append("AND c.fecha_consulta >= CURRENT_DATE ");
        
        List<Object> parametros = new ArrayList<>();
        
        if (especialidadFiltro != null && !especialidadFiltro.equals("Todas")) {
            sql.append("AND e.nombre = ? ");
            parametros.add(especialidadFiltro);
        }
        
        if (fechaFiltro != null && !fechaFiltro.trim().isEmpty()) {
            sql.append("AND DATE(c.fecha_consulta) = ? ");
            parametros.add(Date.valueOf(fechaFiltro));
        }
        
        sql.append("ORDER BY c.fecha_consulta ASC");
        
        List<Object[]> filas = new ArrayList<>();
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < parametros.size(); i++) {
                pstmt.setObject(i + 1, parametros.get(i));
            }
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Object[] fila = {
                    rs.getDate("fecha_consulta"),
                    rs.getString("hora"),
                    rs.getString("medico"),
                    rs.getString("especialidad"),
                    "" // Columna de reservar (botón)
                };
                filas.add(fila);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener agenda disponible: " + e.getMessage());
            e.printStackTrace();
        }
        
        return filas.toArray(new Object[0][]);
    }
    
    /**
     * AGENDAR NUEVA CITA
     * Para el método procesarAgendarCita()
     */
    public boolean agendarNuevaCita(int idPaciente, String especialidad, String medico, 
                                   String fecha, String hora, String motivo) {
        String sql = "INSERT INTO consultas (paciente_id, medico_id, fecha_consulta, motivo_consulta, estado) " +
                    "VALUES (?, " +
                    "(SELECT m.id FROM medicos m " +
                    " JOIN usuarios u ON m.usuario_id = u.id " +
                    " JOIN especialidades e ON m.especialidad_id = e.id " +
                    " WHERE CONCAT(u.nombre, ' ', u.apellidos) = ? AND e.nombre = ?), " +
                    "?, ?, 'Programada')";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPaciente);
            pstmt.setString(2, medico);
            pstmt.setString(3, especialidad);
            pstmt.setTimestamp(4, Timestamp.valueOf(fecha + " " + hora + ":00"));
            pstmt.setString(5, motivo);
            
            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al agendar nueva cita: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * CANCELAR CITA
     * Para el CancelarCitaEditor
     */
    public boolean cancelarCita(int idPaciente, String fecha, String hora, String doctor) {
        String sql = "UPDATE consultas SET estado = 'Cancelada' " +
                    "WHERE paciente_id = ? " +
                    "AND DATE(fecha_consulta) = ? " +
                    "AND TO_CHAR(fecha_consulta, 'HH24:MI') = ? " +
                    "AND medico_id = (SELECT m.id FROM medicos m " +
                    "                 JOIN usuarios u ON m.usuario_id = u.id " +
                    "                 WHERE CONCAT(u.nombre, ' ', u.apellidos) = ?)";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPaciente);
            pstmt.setDate(2, Date.valueOf(fecha));
            pstmt.setString(3, hora);
            pstmt.setString(4, doctor);
            
            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al cancelar cita: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * RESERVAR CITA DESDE AGENDA
     * Para el ReservarCitaEditor
     */
    public boolean reservarCita(int idPaciente, String fecha, String hora, String medico, String especialidad) {
        String sql = "UPDATE consultas SET paciente_id = ?, estado = 'Confirmada' " +
                    "WHERE DATE(fecha_consulta) = ? " +
                    "AND TO_CHAR(fecha_consulta, 'HH24:MI') = ? " +
                    "AND medico_id = (SELECT m.id FROM medicos m " +
                    "                 JOIN usuarios u ON m.usuario_id = u.id " +
                    "                 JOIN especialidades e ON m.especialidad_id = e.id " +
                    "                 WHERE CONCAT(u.nombre, ' ', u.apellidos) = ? " +
                    "                 AND e.nombre = ?) " +
                    "AND estado = 'Disponible'";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPaciente);
            pstmt.setDate(2, Date.valueOf(fecha));
            pstmt.setString(3, hora);
            pstmt.setString(4, medico);
            pstmt.setString(5, especialidad);
            
            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al reservar cita: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * OBTENER MENSAJES Y NOTIFICACIONES
     * Para cargar datos en listaMensajes
     */
    public List<String> obtenerMensajesNotificaciones(int idPaciente) {
        String sql = "SELECT 'Recordatorio: Tiene una cita el ' || " +
                    "TO_CHAR(c.fecha_consulta, 'DD/MM/YYYY') || ' a las ' || " +
                    "TO_CHAR(c.fecha_consulta, 'HH24:MI') || ' con ' || " +
                    "CONCAT(um.nombre, ' ', um.apellidos) || ' (' || " +
                    "TO_CHAR(c.fecha_creacion, 'YYYY-MM-DD') || ')' as mensaje " +
                    "FROM consultas c " +
                    "JOIN medicos m ON c.medico_id = m.id " +
                    "JOIN usuarios um ON m.usuario_id = um.id " +
                    "WHERE c.paciente_id = ? AND c.estado IN ('Programada', 'Confirmada') " +
                    "AND c.fecha_consulta >= CURRENT_DATE " +
                    "ORDER BY c.fecha_consulta ASC";
        
        List<String> mensajes = new ArrayList<>();
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idPaciente);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                mensajes.add("📅 " + rs.getString("mensaje"));
            }
            
            // Agregar mensajes genéricos si no hay citas
            if (mensajes.isEmpty()) {
                mensajes.add("🏥 Bienvenido al portal de pacientes SanArte (2024-07-23)");
                mensajes.add("📋 Recuerde mantener actualizada su información de contacto (2024-07-20)");
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener mensajes: " + e.getMessage());
            e.printStackTrace();
        }
        
        return mensajes;
    }
    
    /**
     * OBTENER DATOS DEL PACIENTE POR ID
     * Para inicializar la ventana con datos del paciente
     */
    public Paciente obtenerPacientePorId(int id) {
        String sql = "SELECT p.id, p.usuario_id, u.nombre, u.apellidos, u.identificacion, " +
                    "u.email, u.telefono, u.fecha_nacimiento, u.genero, u.direccion, u.ciudad, " +
                    "p.numero_historia, p.tipo_sangre, p.alergias, p.enfermedades_cronicas, " +
                    "p.contacto_emergencia_nombre, p.contacto_emergencia_telefono, p.seguro_medico " +
                    "FROM pacientes p " +
                    "JOIN usuarios u ON p.usuario_id = u.id " +
                    "WHERE p.id = ? AND p.activo = true";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                Paciente paciente = new Paciente();
                paciente.setId(rs.getLong("id"));
                paciente.setUsuarioId(rs.getLong("usuario_id"));
                paciente.setNombre(rs.getString("nombre"));
                paciente.setApellidos(rs.getString("apellidos"));
                paciente.setIdentificacion(rs.getString("identificacion"));
                paciente.setEmail(rs.getString("email"));
                paciente.setTelefono(rs.getString("telefono"));
                paciente.setFechaNacimiento(rs.getDate("fecha_nacimiento"));
                paciente.setGenero(rs.getString("genero"));
                paciente.setDireccion(rs.getString("direccion"));
                paciente.setCiudad(rs.getString("ciudad"));
                paciente.setNumeroHistoria(rs.getString("numero_historia"));
                paciente.setTipoSangre(rs.getString("tipo_sangre"));
                paciente.setAlergias(rs.getString("alergias"));
                paciente.setEnfermedadesCronicas(rs.getString("enfermedades_cronicas"));
                paciente.setContactoEmergenciaNombre(rs.getString("contacto_emergencia_nombre"));
                paciente.setContactoEmergenciaTelefono(rs.getString("contacto_emergencia_telefono"));
                paciente.setSeguroMedico(rs.getString("seguro_medico"));
                
                return paciente;
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener paciente por ID: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * OBTENER ESPECIALIDADES DISPONIBLES
     * Para llenar los ComboBox
     */
    public List<String> obtenerEspecialidades() {
        String sql = "SELECT nombre FROM especialidades WHERE activo = true ORDER BY nombre";
        List<String> especialidades = new ArrayList<>();
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                especialidades.add(rs.getString("nombre"));
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener especialidades: " + e.getMessage());
            e.printStackTrace();
        }
        
        return especialidades;
    }
    
    /**
     * OBTENER MÉDICOS POR ESPECIALIDAD
     * Para llenar el ComboBox de médicos
     */
    public List<String> obtenerMedicosPorEspecialidad(String especialidad) {
        String sql = "SELECT CONCAT(u.nombre, ' ', u.apellidos) as nombre_completo " +
                    "FROM medicos m " +
                    "JOIN usuarios u ON m.usuario_id = u.id " +
                    "JOIN especialidades e ON m.especialidad_id = e.id " +
                    "WHERE e.nombre = ? AND m.activo = true " +
                    "ORDER BY u.nombre, u.apellidos";
        
        List<String> medicos = new ArrayList<>();
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, especialidad);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                medicos.add(rs.getString("nombre_completo"));
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener médicos por especialidad: " + e.getMessage());
            e.printStackTrace();
        }
        
        return medicos;
    }

    public Object[][] obtenerPacientesPorDoctor(long parseLong) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
 
    
}
