/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Ventanas;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author socta
 */
public class VisualizarUsuarios extends javax.swing.JFrame {
  /**
     * Creates new form VisualizarUsuarios
     */
    public VisualizarUsuarios() {
        initComponents();
        inicializarComponentes();
        personalizarComponentes();
        actualizarTabla();
    }
    /**
 * Filtra la tabla según el texto de búsqueda
 */
/**
     * Filtra la tabla según el texto de búsqueda
     */
    private void filtrarTabla(String texto) {
        DefaultTableModel modelo = (DefaultTableModel) tablaUsuarios.getModel();
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(modelo);
        tablaUsuarios.setRowSorter(sorter);
        
        if (texto.length() == 0) {
            sorter.setRowFilter(null);
        } else {
            try {
                // Filtrar por la columna seleccionada en el combo
                int columnaSeleccionada = cmbFiltro.getSelectedIndex() + 1; // +1 porque la primera columna es ID
                sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto, columnaSeleccionada));
            } catch (Exception e) {
                System.out.println("Error al filtrar: " + e.getMessage());
                sorter.setRowFilter(null);
            }
        }
        
        // Actualizar etiqueta de información
        actualizarEtiquetaInfo();
    }

    /**
     * Actualiza la tabla según los filtros seleccionados
     */
    private void actualizarTabla() {
        DefaultTableModel modelo = (DefaultTableModel) tablaUsuarios.getModel();
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(modelo);
        tablaUsuarios.setRowSorter(sorter);
        
        // Si no se muestran inactivos, filtrar por estado "Activo"
        if (!chkMostrarInactivos.isSelected()) {
            sorter.setRowFilter(RowFilter.regexFilter("Activo", 6)); // 6 es la columna de Estado
        } else {
            sorter.setRowFilter(null); // Mostrar todos
        }
        
        // Actualizar etiqueta de información
        actualizarEtiquetaInfo();
    }

    /**
     * Actualiza la etiqueta de información con el total de usuarios mostrados
     */
    private void actualizarEtiquetaInfo() {
        int totalFilas = tablaUsuarios.getRowCount();
        lblInfo.setText("Total de usuarios: " + totalFilas);
    }

    /**
     * Inicializa los componentes con valores predeterminados
     */
    private void inicializarComponentes() {
     // Inicializar combo de filtros
    cmbFiltro.removeAllItems();
    cmbFiltro.addItem("Nombre");
    cmbFiltro.addItem("Apellidos");
    cmbFiltro.addItem("Tipo de Usuario");
    cmbFiltro.addItem("Identificación");
    cmbFiltro.addItem("Email");
    
    // Configurar tabla
    tablaUsuarios.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
    tablaUsuarios.setAutoCreateRowSorter(true);
    
    // Centrar la ventana
    this.setLocationRelativeTo(null);
    
    // MEJORADO: Configurar cierre de ventana correctamente
    this.setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
    this.addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowClosing(java.awt.event.WindowEvent evt) {
            // Llamar al mismo método que el botón volver
            btnVolverActionPerformed(new java.awt.event.ActionEvent(this, 0, ""));
        }
    });
    
    // Configurar título de la ventana
    this.setTitle("Sistema SanArte - Visualizar Usuarios");
    }

    /**
     * Personaliza la apariencia de los componentes
     */
    private void personalizarComponentes() {
        // Personalizar botones
        personalizarBoton(btnExportar, new Color(46, 139, 87), Color.WHITE);
        personalizarBoton(btnImprimir, new Color(65, 105, 225), Color.WHITE);
        personalizarBoton(btnVolver, new Color(0, 51, 102), Color.WHITE);
        personalizarBoton(btnBuscar, new Color(100, 149, 237), Color.WHITE);
        
        // Personalizar tabla
        tablaUsuarios.setRowHeight(25);
        tablaUsuarios.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        tablaUsuarios.getTableHeader().setBackground(new Color(70, 130, 180));
        tablaUsuarios.getTableHeader().setForeground(Color.WHITE);
    }

    /**
     * Personaliza un botón con colores y efectos
     */
    private void personalizarBoton(JButton boton, Color fondo, Color texto) {
        boton.setBackground(fondo);
        boton.setForeground(texto);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createRaisedBevelBorder(),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Efecto hover
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(mezclarColores(fondo, Color.BLACK, 0.1f));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(fondo);
            }
        });
    }

    /**
     * Mezcla dos colores con un porcentaje dado
     */
    private Color mezclarColores(Color color1, Color color2, float porcentaje) {
        int r = (int) (color1.getRed() * (1 - porcentaje) + color2.getRed() * porcentaje);
        int g = (int) (color1.getGreen() * (1 - porcentaje) + color2.getGreen() * porcentaje);
        int b = (int) (color1.getBlue() * (1 - porcentaje) + color2.getBlue() * porcentaje);
        return new Color(r, g, b);
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelTitulo = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        panelPrincipal = new javax.swing.JPanel();
        lblFiltro = new javax.swing.JLabel();
        cmbFiltro = new javax.swing.JComboBox<>();
        lblBusqueda = new javax.swing.JLabel();
        txtBusqueda = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        scrollTabla = new java.awt.ScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaUsuarios = new javax.swing.JTable();
        lblInfo = new javax.swing.JLabel();
        chkMostrarInactivos = new javax.swing.JCheckBox();
        panelBotones = new javax.swing.JPanel();
        btnExportar = new javax.swing.JButton();
        btnImprimir = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Visualizar Usuarios");
        setPreferredSize(new java.awt.Dimension(900, 600));

        panelTitulo.setBackground(new java.awt.Color(70, 130, 180));
        panelTitulo.setPreferredSize(new java.awt.Dimension(900, 60));
        panelTitulo.setLayout(null);

        lblTitulo.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(255, 255, 255));
        lblTitulo.setText("Visualizar Usuarios");
        panelTitulo.add(lblTitulo);
        lblTitulo.setBounds(350, 15, 250, 30);

        getContentPane().add(panelTitulo, java.awt.BorderLayout.PAGE_START);

        panelPrincipal.setBackground(new java.awt.Color(240, 248, 255));
        panelPrincipal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblFiltro.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblFiltro.setText("Filtrar por");
        panelPrincipal.add(lblFiltro, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, 100, 25));

        cmbFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbFiltro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFiltroActionPerformed(evt);
            }
        });
        panelPrincipal.add(cmbFiltro, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, 150, 25));

        lblBusqueda.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblBusqueda.setText("Buscar");
        panelPrincipal.add(lblBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 30, 80, 25));
        panelPrincipal.add(txtBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 30, 250, 25));

        btnBuscar.setBackground(new java.awt.Color(100, 149, 237));
        btnBuscar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnBuscar.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        panelPrincipal.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 30, 100, 25));

        tablaUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"1", "Juan", "Pérez", "Doctor", "12345678", "[juan.perez@ejemplo.com](mailto:juan.perez@ejemplo.com", "Activo"},
                {"2", "María", "López", "Enfermera", "87654321", "maria.lopez@ejemplo.com](mailto:maria.lopez@ejemplo.com", "Activo"},
                {"3", "Carlos", "Rodríguez", "Administrativo", "13579246", "carlos.rodriguez@ejemplo.com", "Activo"},
                {"4", "Ana", "Martínez", "Paciente", "24681357", "ana.martinez@ejemplo.com](mailto:ana.martinez@ejemplo.com", "Inactivo"},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Apellidos", "Tipo Usuario", "Identificación", "Email", "Estado"
            }
        ));
        tablaUsuarios.setPreferredSize(new java.awt.Dimension(525, 100));
        jScrollPane1.setViewportView(tablaUsuarios);

        scrollTabla.add(jScrollPane1);

        panelPrincipal.add(scrollTabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 800, 350));

        lblInfo.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblInfo.setText("Total de usuarios: ");
        panelPrincipal.add(lblInfo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 440, 200, 25));

        chkMostrarInactivos.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        chkMostrarInactivos.setSelected(true);
        chkMostrarInactivos.setText("Mostrar usuarios inactivos");
        chkMostrarInactivos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkMostrarInactivosActionPerformed(evt);
            }
        });
        panelPrincipal.add(chkMostrarInactivos, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 440, 200, 25));

        getContentPane().add(panelPrincipal, java.awt.BorderLayout.CENTER);

        panelBotones.setBackground(new java.awt.Color(70, 130, 180));
        panelBotones.setPreferredSize(new java.awt.Dimension(900, 60));
        panelBotones.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 15));

        btnExportar.setBackground(new java.awt.Color(46, 139, 87));
        btnExportar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnExportar.setForeground(new java.awt.Color(255, 255, 255));
        btnExportar.setText("Exportar a Excel");
        btnExportar.setPreferredSize(new java.awt.Dimension(150, 40));
        btnExportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportarActionPerformed(evt);
            }
        });
        panelBotones.add(btnExportar);

        btnImprimir.setBackground(new java.awt.Color(65, 105, 225));
        btnImprimir.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnImprimir.setForeground(new java.awt.Color(255, 255, 255));
        btnImprimir.setText("Imprimir");
        btnImprimir.setPreferredSize(new java.awt.Dimension(120, 40));
        btnImprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimirActionPerformed(evt);
            }
        });
        panelBotones.add(btnImprimir);

        btnVolver.setBackground(new java.awt.Color(0, 51, 102));
        btnVolver.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver");
        btnVolver.setPreferredSize(new java.awt.Dimension(120, 40));
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        panelBotones.add(btnVolver);

        getContentPane().add(panelBotones, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFiltroActionPerformed
        // Actualizar la tabla según el filtro seleccionado
        actualizarTabla();
    }//GEN-LAST:event_cmbFiltroActionPerformed

    private void chkMostrarInactivosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkMostrarInactivosActionPerformed
        // Actualizar la tabla según el estado del checkbox
        actualizarTabla();
    }//GEN-LAST:event_chkMostrarInactivosActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
         // Simulación de búsqueda
        String textoBusqueda = txtBusqueda.getText().trim();
        if (textoBusqueda.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                    "Por favor, ingrese un texto para buscar", 
                    "Campo vacío", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Aquí iría el código para buscar en la base de datos
        // Por ahora, solo mostramos un mensaje
        JOptionPane.showMessageDialog(this, 
                "Búsqueda realizada con éxito", 
                "Búsqueda", JOptionPane.INFORMATION_MESSAGE);
        
        // Simulación de filtrado en la tabla
        filtrarTabla(textoBusqueda);
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnExportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportarActionPerformed
        // Simulación de exportación a Excel
        JOptionPane.showMessageDialog(this, 
                "La lista de usuarios ha sido exportada a Excel correctamente", 
                "Exportación exitosa", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnExportarActionPerformed

    private void btnImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimirActionPerformed
         // Simulación de impresión
        JOptionPane.showMessageDialog(this, 
                "La lista de usuarios ha sido enviada a la impresora", 
                "Impresión", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnImprimirActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
       // Mostrar confirmación antes de salir
    int confirmacion = JOptionPane.showConfirmDialog(
        this,
        "¿Está seguro que desea volver al menú de administración?",
        "Confirmar regreso",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE);
    
    if (confirmacion == JOptionPane.YES_OPTION) {
        // Cerrar esta ventana
        this.dispose();
        
        // Volver a la ventana de Administrador
        try {
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {
                    new Administrador().setVisible(true);
                }
            });
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error al abrir la ventana de Administrador: " + e.getMessage(),
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            
            // En caso de error, cerrar la aplicación
            System.exit(0);
        }
    }
    // Si selecciona "No", permanece en la ventana actual
    }//GEN-LAST:event_btnVolverActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VisualizarUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VisualizarUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VisualizarUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VisualizarUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VisualizarUsuarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnExportar;
    private javax.swing.JButton btnImprimir;
    private javax.swing.JButton btnVolver;
    private javax.swing.JCheckBox chkMostrarInactivos;
    private javax.swing.JComboBox<String> cmbFiltro;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBusqueda;
    private javax.swing.JLabel lblFiltro;
    private javax.swing.JLabel lblInfo;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JPanel panelBotones;
    private javax.swing.JPanel panelPrincipal;
    private javax.swing.JPanel panelTitulo;
    private java.awt.ScrollPane scrollTabla;
    private javax.swing.JTable tablaUsuarios;
    private javax.swing.JTextField txtBusqueda;
    // End of variables declaration//GEN-END:variables
}
