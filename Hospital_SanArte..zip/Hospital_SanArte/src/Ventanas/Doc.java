/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Ventanas;
import Conexion.CitaDAO;
import Conexion.PacienteDAO;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.MessagingException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


// Librerías para PDF
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import elementos.Correo;


/**
 *
 * @author socta
 */
public class Doc extends javax.swing.JFrame {
// ==================== VARIABLES ====================
    
    // Colores del tema SanaArte
    private static final Color COLOR_AZUL_OSCURO = new Color(70, 130, 180);
    private static final Color COLOR_AZUL_CLARO = new Color(240, 248, 255);
    private static final Color COLOR_VERDE = new Color(46, 139, 87);
    private static final Color COLOR_ROJO = new Color(220, 53, 69);
    private static final Color COLOR_NARANJA = new Color(255, 165, 0);
    private static final Color COLOR_GRIS_SECUNDARIO = new Color(108, 117, 125);
    
    // Datos del doctor
    private String nombreDoctor;
    private String especialidad;
    private String idDoctor;
    private Calendar fechaActual;
    
    // Ruta para guardar PDFs
    private static final String RUTA_PDF = "C:\\Users\\socta\\Documents\\PDF_Hospital\\";

    // ==================== CONSTRUCTOR ====================
    
    /**
     * Constructor que recibe los datos del doctor
     */
    public Doc(String nombre, String especialidad, String id) {
        this.nombreDoctor = nombre;
        this.especialidad = especialidad;
        this.idDoctor = id;
        this.fechaActual = Calendar.getInstance();
        
        initComponents();
        configurarVentana();
        inicializarDatos();
        cargarAgenda();
    cargarPacientes();
    }
    private void cargarAgenda() {
    try {
        CitaDAO citaDAO = new CitaDAO();
        Date fecha = fechaActual.getTime();
        Object[][] citas = citaDAO.obtenerCitasParaDoctorPorFecha(
            Long.parseLong(idDoctor.split("-")[1]), // Asume formato "DOC-123"
            new java.sql.Date(fecha.getTime())
        );

        DefaultTableModel modelo = (DefaultTableModel) tablaCitas.getModel();
        modelo.setRowCount(0);
        
        for (Object[] fila : citas) {
            modelo.addRow(fila);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, 
            "Error al cargar agenda: " + e.getMessage(),
            "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void cargarPacientes() {
    try {
        PacienteDAO pacienteDAO = new PacienteDAO();
        Object[][] pacientes = pacienteDAO.obtenerPacientesPorDoctor(
            Long.parseLong(idDoctor.split("-")[1])
        );

        DefaultTableModel modelo = (DefaultTableModel) tablaPacientes.getModel();
        modelo.setRowCount(0);
        
        comboPacientes.removeAllItems();
        for (Object[] fila : pacientes) {
            modelo.addRow(fila);
            comboPacientes.addItem((String) fila[1]); // Nombre completo
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, 
            "Error al cargar pacientes: " + e.getMessage(),
            "Error", JOptionPane.ERROR_MESSAGE);
    }
}
    /**
     * Constructor por defecto
     */
    public Doc() {
        this("Dr. Ejemplo", "Medicina General", "DOC-001");
    }

    // ==================== CONFIGURACIÓN ====================
    
    /**
     * Configuración inicial de la ventana
     */
    private void configurarVentana() {
        this.setLocationRelativeTo(null);
        this.setTitle("SanaArte Hospital - Portal del Doctor");
        this.setResizable(false);
        
        // Configurar cierre de ventana
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                btnCerrarSesionActionPerformed(null);
            }
        });
        
        // Configurar efectos hover para botones laterales
        configurarEfectosHover();
        
        // Configurar tablas
        configurarTablas();
        
        // Crear directorio para PDFs si no existe
        crearDirectorioPDF();
        
        // Agregar el botón "Enviar Correo"
        agregarBotonEnviarCorreo();
    }
    
    /**
     * Crear directorio para PDFs
     */
    private void crearDirectorioPDF() {
        File directorio = new File(RUTA_PDF);
        if (!directorio.exists()) {
            directorio.mkdirs();
        }
    }
    
    /**
     * Agregar botón Enviar Correo al panel de botones de receta
     */
    private void agregarBotonEnviarCorreo() {
        javax.swing.JButton btnEnviarCorreo = new javax.swing.JButton();
        btnEnviarCorreo.setBackground(new Color(255, 193, 7)); // Color amarillo
        btnEnviarCorreo.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnEnviarCorreo.setForeground(Color.WHITE);
         // Necesitarás agregar este icono
        btnEnviarCorreo.setText("Enviar Correo");
        btnEnviarCorreo.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 20, 12, 20));
        btnEnviarCorreo.setBorderPainted(false);
        btnEnviarCorreo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEnviarCorreo.setFocusPainted(false);
        
        // Agregar evento
        btnEnviarCorreo.addActionListener(evt -> btnEnviarCorreoActionPerformed(evt));
        
        // Agregar al panel
        panelBotonesReceta.add(btnEnviarCorreo);
        panelBotonesReceta.revalidate();
        panelBotonesReceta.repaint();
    }
    
    /**
     * Inicializar datos del doctor y componentes
     */
    private void inicializarDatos() {
        // Actualizar información del doctor
        lblNombreDoctor.setText("Dr. " + nombreDoctor);
        lblEspecialidad.setText(especialidad);
        lblIdDoctor.setText("ID: " + idDoctor);
        
        // Actualizar fecha actual
        actualizarFechaLabel();
        
        // Actualizar fecha en recetas
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        txtFechaReceta.setText(formatoFecha.format(new Date()));
        
        // Cargar datos de ejemplo en las tablas
        cargarDatosEjemplo();
        
        // Mostrar agenda por defecto
        CardLayout cl = (CardLayout) panelContenido.getLayout();
        cl.show(panelContenido, "agenda");
        actualizarBotonActivo(btnAgenda);
    }

    // ==================== MÉTODOS ====================
    
    /**
     * Actualizar el label de fecha actual
     */
    private void actualizarFechaLabel() {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy", new Locale("es", "ES"));
        lblFechaActual.setText("Agenda - " + formatoFecha.format(fechaActual.getTime()));
    }
    
    /**
     * Cargar datos de ejemplo en las tablas
     */
    private void cargarDatosEjemplo() {
        // Datos para tabla de citas
        DefaultTableModel modeloCitas = (DefaultTableModel) tablaCitas.getModel();
        modeloCitas.setRowCount(0);
        Object[][] datosCitas = {
            {"08:00", "Juan Pérez García", "Control rutinario", "Confirmada"},
            {"09:30", "María López Rodríguez", "Dolor de cabeza persistente", "Confirmada"},
            {"11:00", "---", "Horario disponible", "Libre"},
            {"12:30", "Carlos Rodríguez Martín", "Resultados de análisis", "Pendiente"},
            {"14:00", "Ana Martínez López", "Consulta de seguimiento", "Confirmada"},
            {"15:30", "---", "Horario disponible", "Libre"}
        };
        for (Object[] fila : datosCitas) {
            modeloCitas.addRow(fila);
        }
        
        // Datos para tabla de pacientes
        DefaultTableModel modeloPacientes = (DefaultTableModel) tablaPacientes.getModel();
        modeloPacientes.setRowCount(0);
        Object[][] datosPacientes = {
            {"P-1001", "Juan Pérez García", "15/03/2024", "12/04/2024", "555-0101"},
            {"P-1002", "María López Rodríguez", "20/03/2024", "18/04/2024", "555-0102"},
            {"P-1003", "Carlos Rodríguez Martín", "10/03/2024", "05/04/2024", "555-0103"},
            {"P-1004", "Ana Martínez López", "25/03/2024", "22/04/2024", "555-0104"},
            {"P-1005", "Luis González Pérez", "18/03/2024", "15/04/2024", "555-0105"}
        };
        for (Object[] fila : datosPacientes) {
            modeloPacientes.addRow(fila);
        }
        
        // Datos para combo de pacientes
        comboPacientes.removeAllItems();
        comboPacientes.addItem("Juan Pérez García");
        comboPacientes.addItem("María López Rodríguez");
        comboPacientes.addItem("Carlos Rodríguez Martín");
        comboPacientes.addItem("Ana Martínez López");
        comboPacientes.addItem("Luis González Pérez");
    }
    
    /**
     * Actualizar el botón activo en el panel lateral
     */
    private void actualizarBotonActivo(javax.swing.JButton botonActivo) {
        // Resetear todos los botones
        btnAgenda.setBackground(COLOR_AZUL_OSCURO);
        btnPacientes.setBackground(COLOR_AZUL_OSCURO);
        btnRecetas.setBackground(COLOR_AZUL_OSCURO);
        
        // Activar el botón seleccionado
        botonActivo.setBackground(new Color(100, 149, 237));
    }
    
    /**
     * Configurar efectos hover para todos los botones
     */
    private void configurarEfectosHover() {
        // Agregar efectos hover a los botones laterales
        javax.swing.JButton[] botones = {btnAgenda, btnPacientes, btnRecetas};
        
        for (javax.swing.JButton boton : botones) {
            boton.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    if (!boton.getBackground().equals(new Color(100, 149, 237))) {
                        boton.setBackground(new Color(90, 140, 190));
                    }
                }
                
                @Override
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    if (!boton.getBackground().equals(new Color(100, 149, 237))) {
                        boton.setBackground(COLOR_AZUL_OSCURO);
                    }
                }
            });
        }
    }
    
    /**
     * Configurar propiedades de las tablas
     */
    private void configurarTablas() {
        // Configurar tabla de citas
        tablaCitas.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tablaCitas.getTableHeader().setReorderingAllowed(false);
        tablaCitas.setRowHeight(35);
        
        // Configurar tabla de pacientes
        tablaPacientes.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tablaPacientes.getTableHeader().setReorderingAllowed(false);
        tablaPacientes.setRowHeight(35);
    }
    
    /**
     * Validar campos del formulario de recetas
     */
    private boolean validarFormularioReceta() {
        if (txtReceta.getText().trim().isEmpty() || txtReceta.getText().equals("Escriba aquí la prescripción médica")) {
            JOptionPane.showMessageDialog(this, 
                "Por favor, escriba la prescripción médica.",
                "Campo Requerido", JOptionPane.WARNING_MESSAGE);
            txtReceta.requestFocus();
            return false;
        }
        
        if (txtDiagnosticoReceta.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Por favor, ingrese el diagnóstico.",
                "Campo Requerido", JOptionPane.WARNING_MESSAGE);
            txtDiagnosticoReceta.requestFocus();
            return false;
        }
        
        return true;
    }
    
    /**
     * Limpiar formulario de recetas
     */
    private void limpiarFormularioReceta() {
        txtDiagnosticoReceta.setText("");
        txtReceta.setText("Escriba aquí la prescripción médica");
        comboPacientes.setSelectedIndex(0);
    }
    
    /**
     * Generar PDF de la receta
     */
    private boolean generarPDFReceta() {
        try {
            String nombreArchivo = RUTA_PDF + "Receta_" + 
                System.currentTimeMillis() + ".pdf";
            
            Document documento = new Document(PageSize.A4);
            PdfWriter.getInstance(documento, new FileOutputStream(nombreArchivo));
            
            documento.open();
            
            // Título del hospital
            com.itextpdf.text.Font tituloFont = new com.itextpdf.text.Font(FontFamily.HELVETICA, 18, com.itextpdf.text.Font.BOLD);
            Paragraph titulo = new Paragraph("HOSPITAL SANARTE", tituloFont);
            titulo.setAlignment(Element.ALIGN_CENTER);
            documento.add(titulo);
            
            documento.add(new Paragraph(" ")); // Espacio
            
            // Información del doctor
            com.itextpdf.text.Font normalFont = new com.itextpdf.text.Font(FontFamily.HELVETICA, 12);
            documento.add(new Paragraph("Doctor: " + lblNombreDoctor.getText(), normalFont));
            documento.add(new Paragraph("Especialidad: " + lblEspecialidad.getText(), normalFont));
            documento.add(new Paragraph("ID: " + lblIdDoctor.getText(), normalFont));
            documento.add(new Paragraph("Fecha: " + txtFechaReceta.getText(), normalFont));
            
            documento.add(new Paragraph(" ")); // Espacio
            
            // Información del paciente
            com.itextpdf.text.Font boldFont = new com.itextpdf.text.Font(FontFamily.HELVETICA, 12, com.itextpdf.text.Font.BOLD);
            documento.add(new Paragraph("RECETA MÉDICA", boldFont));
            documento.add(new Paragraph(" "));
            
             documento.add(new Paragraph("Paciente: " + comboPacientes.getSelectedItem().toString(), normalFont));
            documento.add(new Paragraph("Diagnóstico: " + txtDiagnosticoReceta.getText(), normalFont));
            
            documento.add(new Paragraph(" ")); // Espacio
            
            // Prescripción
            documento.add(new Paragraph("PRESCRIPCIÓN:", boldFont));
            documento.add(new Paragraph(txtReceta.getText(), normalFont));
            
            documento.add(new Paragraph(" ")); // Espacio
            documento.add(new Paragraph(" ")); // Espacio
            
            // Firma
            documento.add(new Paragraph("_________________________", normalFont));
            documento.add(new Paragraph("Firma del Doctor", normalFont));
            
            documento.close();
            
            // Actualizar la ruta para el envío de correo
            System.setProperty("ultima.receta.pdf", nombreArchivo);
            
            return true;
            
        } catch (DocumentException | java.io.IOException e) {
            JOptionPane.showMessageDialog(this,
                "Error al generar el PDF: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    /**
     * Mostrar mensaje de confirmación
     */
    private boolean mostrarConfirmacion(String mensaje, String titulo) {
        int resultado = JOptionPane.showConfirmDialog(
            this, 
            mensaje,
            titulo,
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
        return resultado == JOptionPane.YES_OPTION;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        panelLateral = new javax.swing.JPanel();
        lblFotoDoctor = new javax.swing.JLabel();
        lblNombreDoctor = new javax.swing.JLabel();
        lblEspecialidad = new javax.swing.JLabel();
        lblIdDoctor = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        btnAgenda = new javax.swing.JButton();
        btnPacientes = new javax.swing.JButton();
        btnRecetas = new javax.swing.JButton();
        btnCerrarSesion = new javax.swing.JButton();
        panelContenido = new javax.swing.JPanel();
        panelAgenda = new javax.swing.JPanel();
        panelSuperiorAgenda = new javax.swing.JPanel();
        lblFechaActual = new javax.swing.JLabel();
        panelControlesAgenda = new javax.swing.JPanel();
        btnDiaAnterior = new javax.swing.JButton();
        btnHoy = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaCitas = new javax.swing.JTable();
        panelBotonesAgenda = new javax.swing.JPanel();
        btnReagendarCita = new javax.swing.JButton();
        btnCancelarCita = new javax.swing.JButton();
        btnAtenderCita = new javax.swing.JButton();
        panelPacientes = new javax.swing.JPanel();
        panelSuperiorPacientes = new javax.swing.JPanel();
        lblTituloPacientes = new javax.swing.JLabel();
        panelBusquedaPacientes = new javax.swing.JPanel();
        btnBuscar = new javax.swing.JLabel();
        txtBuscarPaciente = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaPacientes = new javax.swing.JTable();
        panelBotones = new javax.swing.JPanel();
        btnVerHistorial = new javax.swing.JButton();
        btnNuevaCita = new javax.swing.JButton();
        panelRecetas = new javax.swing.JPanel();
        lblTituloRecetas = new javax.swing.JLabel();
        panelFormularioReceta = new javax.swing.JPanel();
        panelCamposReceta = new javax.swing.JPanel();
        lblPacienteReceta = new javax.swing.JLabel();
        comboPacientes = new javax.swing.JComboBox<>();
        lblFechaReceta = new javax.swing.JLabel();
        txtFechaReceta = new javax.swing.JTextField();
        lblDiagnosticoReceta = new javax.swing.JLabel();
        txtDiagnosticoReceta = new javax.swing.JTextField();
        panelRecetaTexto = new javax.swing.JPanel();
        lblPrescripcion = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtReceta = new javax.swing.JTextArea();
        panelBotonesReceta = new javax.swing.JPanel();
        btnLimpiarReceta = new javax.swing.JButton();
        btnImprimirReceta = new javax.swing.JButton();
        btnGuardarReceta = new javax.swing.JButton();
        btnEnviarCorreo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("SanaArte Hospital - Portal del Doctor");
        setMinimumSize(new java.awt.Dimension(1000, 700));
        setPreferredSize(new java.awt.Dimension(1200, 800));

        panelLateral.setBackground(new java.awt.Color(70, 130, 180));
        panelLateral.setPreferredSize(new java.awt.Dimension(280, 600));
        panelLateral.setLayout(new javax.swing.BoxLayout(panelLateral, javax.swing.BoxLayout.Y_AXIS));

        lblFotoDoctor.setFont(new java.awt.Font("Segoe UI", 0, 40)); // NOI18N
        lblFotoDoctor.setForeground(new java.awt.Color(255, 255, 255));
        lblFotoDoctor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFotoDoctor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Doctors_Photos_--r.png"))); // NOI18N
        panelLateral.add(lblFotoDoctor);

        lblNombreDoctor.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        lblNombreDoctor.setForeground(new java.awt.Color(255, 255, 255));
        lblNombreDoctor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNombreDoctor.setText("Dr. Nombre Apellido");
        panelLateral.add(lblNombreDoctor);

        lblEspecialidad.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblEspecialidad.setForeground(new java.awt.Color(255, 255, 255));
        lblEspecialidad.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEspecialidad.setText("Especialidad Médica");
        panelLateral.add(lblEspecialidad);

        lblIdDoctor.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        lblIdDoctor.setForeground(new java.awt.Color(180, 200, 255));
        lblIdDoctor.setText("ID: DO001");
        panelLateral.add(lblIdDoctor);
        panelLateral.add(jSeparator1);

        btnAgenda.setBackground(new java.awt.Color(70, 130, 180));
        btnAgenda.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnAgenda.setForeground(new java.awt.Color(255, 255, 255));
        btnAgenda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/_Calendario__.png"))); // NOI18N
        btnAgenda.setText("Agenda");
        btnAgenda.setBorderPainted(false);
        btnAgenda.setFocusPainted(false);
        btnAgenda.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAgenda.setMaximumSize(new java.awt.Dimension(220, 35));
        btnAgenda.setPreferredSize(new java.awt.Dimension(250, 45));
        btnAgenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgendaActionPerformed(evt);
            }
        });
        panelLateral.add(btnAgenda);

        btnPacientes.setBackground(new java.awt.Color(70, 130, 180));
        btnPacientes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnPacientes.setForeground(new java.awt.Color(255, 255, 255));
        btnPacientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Clientes.png"))); // NOI18N
        btnPacientes.setText("Mis Pacientes");
        btnPacientes.setBorderPainted(false);
        btnPacientes.setFocusPainted(false);
        btnPacientes.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPacientes.setMaximumSize(new java.awt.Dimension(220, 35));
        btnPacientes.setPreferredSize(new java.awt.Dimension(250, 45));
        btnPacientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPacientesActionPerformed(evt);
            }
        });
        panelLateral.add(btnPacientes);

        btnRecetas.setBackground(new java.awt.Color(70, 130, 180));
        btnRecetas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnRecetas.setForeground(new java.awt.Color(255, 255, 255));
        btnRecetas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Resetas-r-.png"))); // NOI18N
        btnRecetas.setText("Recetas");
        btnRecetas.setBorderPainted(false);
        btnRecetas.setFocusPainted(false);
        btnRecetas.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnRecetas.setMaximumSize(new java.awt.Dimension(220, 35));
        btnRecetas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecetasActionPerformed(evt);
            }
        });
        panelLateral.add(btnRecetas);

        btnCerrarSesion.setBackground(new java.awt.Color(108, 117, 125));
        btnCerrarSesion.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnCerrarSesion.setForeground(new java.awt.Color(255, 255, 255));
        btnCerrarSesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/exit--r.png"))); // NOI18N
        btnCerrarSesion.setText("Cerrar Sesión");
        btnCerrarSesion.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnCerrarSesion.setMaximumSize(new java.awt.Dimension(220, 35));
        btnCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarSesionActionPerformed(evt);
            }
        });
        panelLateral.add(btnCerrarSesion);

        getContentPane().add(panelLateral, java.awt.BorderLayout.LINE_START);

        panelContenido.setBackground(new java.awt.Color(255, 255, 255));
        panelContenido.setLayout(new java.awt.CardLayout());

        panelAgenda.setBackground(new java.awt.Color(255, 255, 255));
        panelAgenda.setLayout(new java.awt.BorderLayout());

        panelSuperiorAgenda.setBackground(new java.awt.Color(255, 255, 255));
        panelSuperiorAgenda.setLayout(new java.awt.BorderLayout());

        lblFechaActual.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblFechaActual.setForeground(new java.awt.Color(70, 130, 180));
        lblFechaActual.setText("Agenda - Lunes, 28 de Julio de 2025");
        panelSuperiorAgenda.add(lblFechaActual, java.awt.BorderLayout.WEST);

        panelControlesAgenda.setBackground(new java.awt.Color(255, 255, 255));
        panelControlesAgenda.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnDiaAnterior.setBackground(new java.awt.Color(248, 249, 250));
        btnDiaAnterior.setForeground(new java.awt.Color(108, 117, 125));
        btnDiaAnterior.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/flecha-izi.png"))); // NOI18N
        btnDiaAnterior.setBorderPainted(false);
        btnDiaAnterior.setFocusPainted(false);
        btnDiaAnterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDiaAnteriorActionPerformed(evt);
            }
        });
        panelControlesAgenda.add(btnDiaAnterior);

        btnHoy.setBackground(new java.awt.Color(248, 249, 250));
        btnHoy.setForeground(new java.awt.Color(108, 117, 125));
        btnHoy.setText("Hoy");
        btnHoy.setBorderPainted(false);
        btnHoy.setFocusPainted(false);
        btnHoy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHoyActionPerformed(evt);
            }
        });
        panelControlesAgenda.add(btnHoy);

        jButton1.setBackground(new java.awt.Color(248, 249, 250));
        jButton1.setForeground(new java.awt.Color(108, 117, 125));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/flecha-.png"))); // NOI18N
        jButton1.setBorderPainted(false);
        jButton1.setFocusPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        panelControlesAgenda.add(jButton1);

        panelSuperiorAgenda.add(panelControlesAgenda, java.awt.BorderLayout.EAST);

        panelAgenda.add(panelSuperiorAgenda, java.awt.BorderLayout.PAGE_START);

        tablaCitas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Hora", "Paciente", "Motivo", "Estado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablaCitas);

        panelAgenda.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        panelBotonesAgenda.setBackground(new java.awt.Color(255, 255, 255));
        panelBotonesAgenda.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnReagendarCita.setBackground(new java.awt.Color(255, 165, 0));
        btnReagendarCita.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnReagendarCita.setForeground(new java.awt.Color(255, 255, 255));
        btnReagendarCita.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/calendariofechas--.png"))); // NOI18N
        btnReagendarCita.setText("Reagendar");
        btnReagendarCita.setBorderPainted(false);
        btnReagendarCita.setFocusPainted(false);
        btnReagendarCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReagendarCitaActionPerformed(evt);
            }
        });
        panelBotonesAgenda.add(btnReagendarCita);

        btnCancelarCita.setBackground(new java.awt.Color(220, 53, 69));
        btnCancelarCita.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnCancelarCita.setForeground(new java.awt.Color(255, 255, 255));
        btnCancelarCita.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/eliminar.png"))); // NOI18N
        btnCancelarCita.setText("Cancelar");
        btnCancelarCita.setBorderPainted(false);
        btnCancelarCita.setFocusPainted(false);
        btnCancelarCita.setPreferredSize(new java.awt.Dimension(111, 34));
        btnCancelarCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarCitaActionPerformed(evt);
            }
        });
        panelBotonesAgenda.add(btnCancelarCita);

        btnAtenderCita.setBackground(new java.awt.Color(46, 139, 87));
        btnAtenderCita.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnAtenderCita.setForeground(new java.awt.Color(255, 255, 255));
        btnAtenderCita.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/like_-.png"))); // NOI18N
        btnAtenderCita.setText("Atender");
        btnAtenderCita.setBorderPainted(false);
        btnAtenderCita.setFocusPainted(false);
        btnAtenderCita.setPreferredSize(new java.awt.Dimension(111, 34));
        btnAtenderCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtenderCitaActionPerformed(evt);
            }
        });
        panelBotonesAgenda.add(btnAtenderCita);

        panelAgenda.add(panelBotonesAgenda, java.awt.BorderLayout.PAGE_END);

        panelContenido.add(panelAgenda, "card2");

        panelPacientes.setLayout(new java.awt.BorderLayout());

        panelSuperiorPacientes.setBackground(new java.awt.Color(255, 255, 255));
        panelSuperiorPacientes.setLayout(new java.awt.BorderLayout());

        lblTituloPacientes.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTituloPacientes.setForeground(new java.awt.Color(70, 130, 180));
        lblTituloPacientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Icon_histori.png"))); // NOI18N
        lblTituloPacientes.setText("Mis Pacientes");
        panelSuperiorPacientes.add(lblTituloPacientes, java.awt.BorderLayout.NORTH);

        panelBusquedaPacientes.setBackground(new java.awt.Color(255, 255, 255));

        btnBuscar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/lupa.png"))); // NOI18N
        btnBuscar.setText("Buscar");
        panelBusquedaPacientes.add(btnBuscar);

        txtBuscarPaciente.setColumns(20);
        txtBuscarPaciente.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        panelBusquedaPacientes.add(txtBuscarPaciente);

        panelSuperiorPacientes.add(panelBusquedaPacientes, java.awt.BorderLayout.SOUTH);

        panelPacientes.add(panelSuperiorPacientes, java.awt.BorderLayout.PAGE_START);

        tablaPacientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre Completo", "Última Visita", "Próxima Cita", "Teléfono"
            }
        ));
        jScrollPane2.setViewportView(tablaPacientes);

        panelPacientes.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        panelBotones.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnVerHistorial.setBackground(new java.awt.Color(70, 130, 180));
        btnVerHistorial.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/historial-medico.png"))); // NOI18N
        btnVerHistorial.setText("Ver Historial");
        btnVerHistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerHistorialActionPerformed(evt);
            }
        });
        panelBotones.add(btnVerHistorial);

        btnNuevaCita.setBackground(new java.awt.Color(46, 139, 87));
        btnNuevaCita.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/nuevo.png"))); // NOI18N
        btnNuevaCita.setText("Nueva Cita");
        btnNuevaCita.setPreferredSize(new java.awt.Dimension(113, 40));
        btnNuevaCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevaCitaActionPerformed(evt);
            }
        });
        panelBotones.add(btnNuevaCita);

        panelPacientes.add(panelBotones, java.awt.BorderLayout.PAGE_END);

        panelContenido.add(panelPacientes, "card3");

        panelRecetas.setBackground(new java.awt.Color(255, 255, 255));
        panelRecetas.setLayout(new java.awt.BorderLayout());

        lblTituloRecetas.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTituloRecetas.setForeground(new java.awt.Color(70, 130, 180));
        lblTituloRecetas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/medico.png"))); // NOI18N
        lblTituloRecetas.setText("Generar Receta Médica");
        lblTituloRecetas.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 25, 0));
        panelRecetas.add(lblTituloRecetas, java.awt.BorderLayout.NORTH);

        panelFormularioReceta.setBackground(new java.awt.Color(255, 255, 255));
        panelFormularioReceta.setLayout(new java.awt.BorderLayout());

        panelCamposReceta.setBackground(new java.awt.Color(248, 249, 250));
        panelCamposReceta.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panelCamposReceta.setLayout(new java.awt.GridBagLayout());

        lblPacienteReceta.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblPacienteReceta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/paciente.png"))); // NOI18N
        lblPacienteReceta.setText("Paciente");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(10, 10, 10, 10);
        panelCamposReceta.add(lblPacienteReceta, gridBagConstraints);

        comboPacientes.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        comboPacientes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(10, 10, 10, 10);
        panelCamposReceta.add(comboPacientes, gridBagConstraints);

        lblFechaReceta.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblFechaReceta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/receta---.png"))); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(10, 10, 10, 10);
        panelCamposReceta.add(lblFechaReceta, gridBagConstraints);

        txtFechaReceta.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtFechaReceta.setText("28/07/2025");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(10, 10, 10, 10);
        panelCamposReceta.add(txtFechaReceta, gridBagConstraints);

        lblDiagnosticoReceta.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblDiagnosticoReceta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Diagnostico.png"))); // NOI18N
        lblDiagnosticoReceta.setText("Diagnóstico");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(10, 10, 10, 10);
        panelCamposReceta.add(lblDiagnosticoReceta, gridBagConstraints);

        txtDiagnosticoReceta.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(10, 10, 10, 10);
        panelCamposReceta.add(txtDiagnosticoReceta, gridBagConstraints);

        panelFormularioReceta.add(panelCamposReceta, java.awt.BorderLayout.PAGE_START);

        panelRecetaTexto.setBackground(new java.awt.Color(255, 255, 255));
        panelRecetaTexto.setLayout(new java.awt.BorderLayout());

        lblPrescripcion.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPrescripcion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/simbolo-de-la-medicina.png"))); // NOI18N
        lblPrescripcion.setText("Prescripción Médica");
        lblPrescripcion.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelRecetaTexto.add(lblPrescripcion, java.awt.BorderLayout.PAGE_START);

        jScrollPane3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(222, 226, 230)));

        txtReceta.setBackground(new java.awt.Color(255, 255, 255));
        txtReceta.setColumns(50);
        txtReceta.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtReceta.setLineWrap(true);
        txtReceta.setRows(12);
        txtReceta.setText("Escriba aquí la prescripción médica");
        txtReceta.setWrapStyleWord(true);
        txtReceta.setBorder(javax.swing.BorderFactory.createEmptyBorder(15, 15, 15, 15));
        jScrollPane3.setViewportView(txtReceta);

        panelRecetaTexto.add(jScrollPane3, java.awt.BorderLayout.CENTER);

        panelFormularioReceta.add(panelRecetaTexto, java.awt.BorderLayout.CENTER);

        panelBotonesReceta.setBackground(new java.awt.Color(255, 255, 255));
        panelBotonesReceta.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panelBotonesReceta.setForeground(new java.awt.Color(255, 255, 255));
        panelBotonesReceta.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 0));

        btnLimpiarReceta.setBackground(new java.awt.Color(108, 117, 125));
        btnLimpiarReceta.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnLimpiarReceta.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpiarReceta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Basurero--.png"))); // NOI18N
        btnLimpiarReceta.setText("Limpiar");
        btnLimpiarReceta.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 20, 12, 20));
        btnLimpiarReceta.setBorderPainted(false);
        btnLimpiarReceta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnLimpiarReceta.setFocusPainted(false);
        btnLimpiarReceta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarRecetaActionPerformed(evt);
            }
        });
        panelBotonesReceta.add(btnLimpiarReceta);

        btnImprimirReceta.setBackground(new java.awt.Color(70, 130, 180));
        btnImprimirReceta.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnImprimirReceta.setForeground(new java.awt.Color(255, 255, 255));
        btnImprimirReceta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/impresora.png"))); // NOI18N
        btnImprimirReceta.setText("Imprimir");
        btnImprimirReceta.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 20, 12, 20));
        btnImprimirReceta.setBorderPainted(false);
        btnImprimirReceta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnImprimirReceta.setFocusPainted(false);
        btnImprimirReceta.setPreferredSize(new java.awt.Dimension(133, 53));
        btnImprimirReceta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimirRecetaActionPerformed(evt);
            }
        });
        panelBotonesReceta.add(btnImprimirReceta);

        btnGuardarReceta.setBackground(new java.awt.Color(46, 139, 87));
        btnGuardarReceta.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnGuardarReceta.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardarReceta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/disquete.png"))); // NOI18N
        btnGuardarReceta.setText("Guardar");
        btnGuardarReceta.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 12, 12, 20));
        btnGuardarReceta.setBorderPainted(false);
        btnGuardarReceta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnGuardarReceta.setFocusPainted(false);
        btnGuardarReceta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarRecetaActionPerformed(evt);
            }
        });
        panelBotonesReceta.add(btnGuardarReceta);

        btnEnviarCorreo.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnEnviarCorreo.setForeground(new java.awt.Color(255, 255, 255));
        btnEnviarCorreo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/gmail.png"))); // NOI18N
        btnEnviarCorreo.setText("Enviar Correo");
        btnEnviarCorreo.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 12, 12, 20));
        btnEnviarCorreo.setBorderPainted(false);
        btnEnviarCorreo.setFocusPainted(false);
        btnEnviarCorreo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarCorreoActionPerformed(evt);
            }
        });
        panelBotonesReceta.add(btnEnviarCorreo);

        panelFormularioReceta.add(panelBotonesReceta, java.awt.BorderLayout.PAGE_END);

        panelRecetas.add(panelFormularioReceta, java.awt.BorderLayout.CENTER);

        panelContenido.add(panelRecetas, "card4");

        getContentPane().add(panelContenido, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgendaActionPerformed
        // TODO add your handling code here:
        CardLayout cl = (CardLayout) panelContenido.getLayout();
        cl.show(panelContenido, "card2"); // Usar "card2"
        actualizarBotonActivo(btnAgenda);
    }//GEN-LAST:event_btnAgendaActionPerformed

    private void btnPacientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPacientesActionPerformed
        CardLayout cl = (CardLayout) panelContenido.getLayout();
        cl.show(panelContenido, "card3"); // Usar "card3"
        actualizarBotonActivo(btnPacientes);
    }//GEN-LAST:event_btnPacientesActionPerformed

    private void btnRecetasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecetasActionPerformed
        // TODO add your handling code here:
        CardLayout cl = (CardLayout) panelContenido.getLayout();
        cl.show(panelContenido, "card4"); // Usar "card4"
        actualizarBotonActivo(btnRecetas);
    }//GEN-LAST:event_btnRecetasActionPerformed

    private void btnCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarSesionActionPerformed
        // TODO add your handling code here:
        if (mostrarConfirmacion("¿Está seguro que desea cerrar sesión?", "Confirmar cierre de sesión")) {
            this.dispose();
            try {
                new Acces().setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir la ventana de acceso: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
                System.exit(0);
            }
        }
    }//GEN-LAST:event_btnCerrarSesionActionPerformed

    // Eventos de controles de fecha
    private void btnDiaAnteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDiaAnteriorActionPerformed
        // TODO add your handling code here:
        fechaActual.add(Calendar.DAY_OF_MONTH, -1);
    actualizarFechaLabel();
    cargarAgenda(); // Actualizar agenda al cambiar fecha
    }//GEN-LAST:event_btnDiaAnteriorActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        fechaActual.add(Calendar.DAY_OF_MONTH, 1);
    actualizarFechaLabel();
    cargarAgenda(); // Actualizar agenda al cambiar fecha
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnHoyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHoyActionPerformed
        // TODO add your handling code here:
            fechaActual = Calendar.getInstance();
    actualizarFechaLabel();
    cargarAgenda(); // Actualizar agenda al cambiar fecha
    }//GEN-LAST:event_btnHoyActionPerformed

    private void btnAtenderCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtenderCitaActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = tablaCitas.getSelectedRow();
        if (filaSeleccionada != -1) {
            String paciente = (String) tablaCitas.getValueAt(filaSeleccionada, 1);
            if (!paciente.equals("---")) {
                JOptionPane.showMessageDialog(this, 
                    "Iniciando atención para: " + paciente,
                    "Atender Cita", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "No hay paciente asignado en este horario.",
                    "Horario Libre", JOptionPane.WARNING_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "Por favor, seleccione una cita para atender.",
                "Seleccionar Cita", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnAtenderCitaActionPerformed

    private void btnCancelarCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarCitaActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = tablaCitas.getSelectedRow();
        if (filaSeleccionada != -1) {
            String paciente = (String) tablaCitas.getValueAt(filaSeleccionada, 1);
            if (!paciente.equals("---")) {
                if (mostrarConfirmacion("¿Está seguro que desea cancelar la cita de " + paciente + "?", "Cancelar Cita")) {
                    DefaultTableModel modelo = (DefaultTableModel) tablaCitas.getModel();
                    modelo.setValueAt("---", filaSeleccionada, 1);
                    modelo.setValueAt("Horario disponible", filaSeleccionada, 2);
                    modelo.setValueAt("Libre", filaSeleccionada, 3);
                    JOptionPane.showMessageDialog(this, 
                        "Cita cancelada exitosamente.",
                        "Cita Cancelada", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, 
                    "No hay cita para cancelar en este horario.",
                    "Horario Libre", JOptionPane.WARNING_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "Por favor, seleccione una cita para cancelar.",
                "Seleccionar Cita", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnCancelarCitaActionPerformed

    private void btnReagendarCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReagendarCitaActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = tablaCitas.getSelectedRow();
        if (filaSeleccionada != -1) {
            String paciente = (String) tablaCitas.getValueAt(filaSeleccionada, 1);
            if (!paciente.equals("---")) {
                JOptionPane.showMessageDialog(this, 
                    "Función de reagendar cita para " + paciente + " en desarrollo.",
                    "Reagendar Cita", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "No hay cita para reagendar en este horario.",
                    "Horario Libre", JOptionPane.WARNING_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "Por favor, seleccione una cita para reagendar.",
                "Seleccionar Cita", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnReagendarCitaActionPerformed

    private void btnVerHistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerHistorialActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = tablaPacientes.getSelectedRow();
        if (filaSeleccionada != -1) {
            String paciente = (String) tablaPacientes.getValueAt(filaSeleccionada, 1);
            JOptionPane.showMessageDialog(this, 
                "Abriendo historial médico de: " + paciente,
                "Historial Médico", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Por favor, seleccione un paciente para ver su historial.",
                "Seleccionar Paciente", JOptionPane.WARNING_MESSAGE);
        }
        
    }//GEN-LAST:event_btnVerHistorialActionPerformed

    private void btnNuevaCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevaCitaActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(this, 
            "Función para agendar nueva cita en desarrollo.",
            "Nueva Cita", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnNuevaCitaActionPerformed

    private void btnLimpiarRecetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarRecetaActionPerformed
        // TODO add your handling code here:
        limpiarFormularioReceta();
        JOptionPane.showMessageDialog(this, 
            "Formulario limpiado exitosamente.",
            "Limpiar Formulario", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnLimpiarRecetaActionPerformed

    private void btnImprimirRecetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimirRecetaActionPerformed
        // TODO add your handling code here:
         if (validarFormularioReceta()) {
            if (generarPDFReceta()) {
                JOptionPane.showMessageDialog(this, 
                    "PDF generado exitosamente.\nUbicación: " + RUTA_PDF,
                    "PDF Generado", JOptionPane.INFORMATION_MESSAGE);
                
                // Intentar abrir el PDF
                try {
                    String rutaPDF = System.getProperty("ultima.receta.pdf");
                    if (rutaPDF != null && Desktop.isDesktopSupported()) {
                        Desktop.getDesktop().open(new File(rutaPDF));
                    }
                } catch (Exception e) {
                    System.err.println("No se pudo abrir el PDF: " + e.getMessage());
                }
            }
        }
    }//GEN-LAST:event_btnImprimirRecetaActionPerformed

    private void btnGuardarRecetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarRecetaActionPerformed
        // TODO add your handling code here:
        if (validarFormularioReceta()) {
            if (generarPDFReceta()) {
                // Guardar en la ruta específica
                String rutaFinal = RUTA_PDF + "Confirmacion.pdf";
                try {
                    String rutaTemp = System.getProperty("ultima.receta.pdf");
                    if (rutaTemp != null) {
                        // Copiar el archivo temporal a la ruta final
                        java.nio.file.Files.copy(
                            java.nio.file.Paths.get(rutaTemp),
                            java.nio.file.Paths.get(rutaFinal),
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING
                        );
                        
                        JOptionPane.showMessageDialog(this, 
                            "Receta guardada exitosamente para: " + comboPacientes.getSelectedItem() + 
                            "\nUbicación: " + rutaFinal,
                            "Receta Guardada", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this,
                        "Error al guardar el archivo: " + e.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }//GEN-LAST:event_btnGuardarRecetaActionPerformed

    private void btnEnviarCorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarCorreoActionPerformed
        // TODO add your handling code here:
        try {
            // Validar formulario primero
            if (!validarFormularioReceta()) {
                return;
            }
            
            // Generar PDF si no existe
            String rutaArchivo = RUTA_PDF + "Confirmacion.pdf";
            File archivoPDF = new File(rutaArchivo);
            
            if (!archivoPDF.exists()) {
                if (!generarPDFReceta()) {
                    return;
                }
                // Copiar a la ruta de confirmación
                try {
                    String rutaTemp = System.getProperty("ultima.receta.pdf");
                    if (rutaTemp != null) {
                        java.nio.file.Files.copy(
                            java.nio.file.Paths.get(rutaTemp),
                            java.nio.file.Paths.get(rutaArchivo),
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING
                        );
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this,
                        "Error al preparar el archivo para envío: " + e.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            
            // Configurar datos del correo
            String remitente = "hospitalsanarte49@gmail.com";
            String contraseña = "coik fdgz iafw byyr";
            String destinatario = "luismariodiaz456@gmail.com";
            
            // Crear instancia de correo
            Correo correo = new Correo();
            correo.setRemitente(remitente, contraseña);
            correo.setDestinatario(destinatario);
            
            // Configurar contenido del correo
            String asunto = "Receta Médica - Hospital SanaArte";
            String mensaje = "Estimado/a paciente,\n\n" +
                           "Adjunto encontrará su receta médica emitida por:\n" +
                           "Doctor: " + lblNombreDoctor.getText() + "\n" +
                           "Especialidad: " + lblEspecialidad.getText() + "\n" +
                           "Fecha: " + txtFechaReceta.getText() + "\n" +
                           "Paciente: " + comboPacientes.getSelectedItem() + "\n\n" +
                           "Saludos cordiales,\n" +
                           "Hospital SanaArte";
            
            correo.setContenido(asunto, mensaje);
            correo.agregarArchivo(rutaArchivo);
            
            // Mostrar mensaje de envío
            JOptionPane.showMessageDialog(this,
                "Enviando correo electrónico...\nEsto puede tomar unos momentos.",
                "Enviando Correo", JOptionPane.INFORMATION_MESSAGE);
            
            // Enviar correo
            correo.enviarCorreo();
            
            JOptionPane.showMessageDialog(this,
                "¡Correo enviado exitosamente!\n\n" +
                "Destinatario: " + destinatario + "\n" +
                "Archivo adjunto: Confirmacion.pdf\n" +
                "Paciente: " + comboPacientes.getSelectedItem(),
                "Correo Enviado", JOptionPane.INFORMATION_MESSAGE);
                
        } catch (MessagingException ex) {
            Logger.getLogger(Doc.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this,
                "Error al enviar el correo: " + ex.getMessage() + 
                "\n\nVerifique su conexión a internet y los datos del correo.",
                "Error de Envío", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            Logger.getLogger(Doc.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this,
                "Error inesperado: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnEnviarCorreoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Doc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Doc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Doc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Doc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Doc().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgenda;
    private javax.swing.JButton btnAtenderCita;
    private javax.swing.JLabel btnBuscar;
    private javax.swing.JButton btnCancelarCita;
    private javax.swing.JButton btnCerrarSesion;
    private javax.swing.JButton btnDiaAnterior;
    private javax.swing.JButton btnEnviarCorreo;
    private javax.swing.JButton btnGuardarReceta;
    private javax.swing.JButton btnHoy;
    private javax.swing.JButton btnImprimirReceta;
    private javax.swing.JButton btnLimpiarReceta;
    private javax.swing.JButton btnNuevaCita;
    private javax.swing.JButton btnPacientes;
    private javax.swing.JButton btnReagendarCita;
    private javax.swing.JButton btnRecetas;
    private javax.swing.JButton btnVerHistorial;
    private javax.swing.JComboBox<String> comboPacientes;
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblDiagnosticoReceta;
    private javax.swing.JLabel lblEspecialidad;
    private javax.swing.JLabel lblFechaActual;
    private javax.swing.JLabel lblFechaReceta;
    private javax.swing.JLabel lblFotoDoctor;
    private javax.swing.JLabel lblIdDoctor;
    private javax.swing.JLabel lblNombreDoctor;
    private javax.swing.JLabel lblPacienteReceta;
    private javax.swing.JLabel lblPrescripcion;
    private javax.swing.JLabel lblTituloPacientes;
    private javax.swing.JLabel lblTituloRecetas;
    private javax.swing.JPanel panelAgenda;
    private javax.swing.JPanel panelBotones;
    private javax.swing.JPanel panelBotonesAgenda;
    private javax.swing.JPanel panelBotonesReceta;
    private javax.swing.JPanel panelBusquedaPacientes;
    private javax.swing.JPanel panelCamposReceta;
    private javax.swing.JPanel panelContenido;
    private javax.swing.JPanel panelControlesAgenda;
    private javax.swing.JPanel panelFormularioReceta;
    private javax.swing.JPanel panelLateral;
    private javax.swing.JPanel panelPacientes;
    private javax.swing.JPanel panelRecetaTexto;
    private javax.swing.JPanel panelRecetas;
    private javax.swing.JPanel panelSuperiorAgenda;
    private javax.swing.JPanel panelSuperiorPacientes;
    private javax.swing.JTable tablaCitas;
    private javax.swing.JTable tablaPacientes;
    private javax.swing.JTextField txtBuscarPaciente;
    private javax.swing.JTextField txtDiagnosticoReceta;
    private javax.swing.JTextField txtFechaReceta;
    private javax.swing.JTextArea txtReceta;
    // End of variables declaration//GEN-END:variables
}
