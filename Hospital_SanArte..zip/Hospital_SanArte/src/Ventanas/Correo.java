/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ventanas;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import java.io.File;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;




/**
 *
 * @author socta
 */
public class Correo {
    private String remitente;
    private String contraseña;
    private String destinatario;
    private String asunto;
    private String mensaje;
    private String rutaArchivo;
    
    /**
     * Configurar datos del remitente
     */
    public void setRemitente(String email, String password) {
        this.remitente = email;
        this.contraseña = password;
    }
    
    /**
     * Configurar destinatario
     */
    public void setDestinatario(String email) {
        this.destinatario = email;
    }
    
    /**
     * Configurar contenido del correo
     */
    public void setContenido(String asunto, String mensaje) {
        this.asunto = asunto;
        this.mensaje = mensaje;
    }
    
    /**
     * Agregar archivo adjunto
     */
    public void agregarArchivo(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }
    
    /**
     * Enviar correo electrónico
     */
    public void enviarCorreo() throws MessagingException {
        // Configurar propiedades del servidor SMTP de Gmail
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        
        // Crear sesión con autenticación
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, contraseña);
            }
        });
        
        try {
            // Crear mensaje
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(remitente));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject(asunto);
            
            // Crear contenido multipart para texto y archivo
            Multipart multipart = new MimeMultipart();
            
            // Parte del texto
            BodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setText(mensaje);
            multipart.addBodyPart(messageBodyPart);
            
            // Parte del archivo adjunto
            if (rutaArchivo != null && !rutaArchivo.isEmpty()) {
                File archivo = new File(rutaArchivo);
                if (archivo.exists()) {
                    messageBodyPart = new MimeBodyPart();
                    // ✅ ESTO FUNCIONA
                    FileDataSource source = new FileDataSource(archivo);
                    messageBodyPart.setDataHandler(new DataHandler(source));
                    messageBodyPart.setFileName(archivo.getName());
                    multipart.addBodyPart(messageBodyPart);
                }
            }
            
            // Establecer contenido del mensaje
            message.setContent(multipart);
            
            // Enviar mensaje
            Transport.send(message);
            
        } catch (Exception e) {
            throw new MessagingException("Error al enviar correo: " + e.getMessage(), e);
        }
    }
    
}
