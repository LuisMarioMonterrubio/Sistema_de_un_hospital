/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Ventanas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.netbeans.lib.awtextra.AbsoluteConstraints;

/**
 *
 * @author socta
 */
public class insertarUsuario extends javax.swing.JFrame {
// Variables de instancia
    private int ultimaPestanaVisitada = 0;
    
    /**
     * Creates new form insertarUsuario
     */
    public insertarUsuario() {
        initComponents();
        personalizarComponentes();
        inicializarComponentes();
        configurarAdaptabilidad();
        
        // Centrar en pantalla
        this.setLocationRelativeTo(null);
        
        // Configurar cierre de ventana
        this.setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        
        // Mostrar ventana
        this.setVisible(true);
    }
    
    /** Personaliza la apariencia de los componentes */
    private void personalizarComponentes() {
        // Configurar colores de fondo
        Color fondoAzulClaro = new Color(230, 240, 250);
        Color azulOscuro = new Color(70, 130, 180);
        Color azulMedio = new Color(100, 149, 237);
        
        // Personalizar paneles
        panelDatosPersonales.setBackground(fondoAzulClaro);
        panelDatosContacto.setBackground(fondoAzulClaro);
        panelCredenciales.setBackground(fondoAzulClaro);
        panelPermisos.setBackground(fondoAzulClaro);
        panelBotones.setBackground(azulOscuro);
        
        // Añadir bordes a los paneles
        panelDatosPersonales.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panelDatosContacto.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panelCredenciales.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panelPermisos.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Personalizar botones principales
        btnGuardar.setBackground(new Color(46, 139, 87));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFont(new Font("Arial", Font.BOLD, 14));
        btnGuardar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createRaisedBevelBorder(),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)));
        btnGuardar.setPreferredSize(new Dimension(120, 40));
        
        btnCancelar.setBackground(new Color(220, 20, 60));
        btnCancelar.setForeground(Color.WHITE);
        btnCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        btnCancelar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createRaisedBevelBorder(),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)));
        btnCancelar.setPreferredSize(new Dimension(120, 40));
        
        // Personalizar botón generar email
        btnGenerarEmail.setBackground(new Color(100, 149, 237));
        btnGenerarEmail.setForeground(Color.WHITE);
        btnGenerarEmail.setFont(new Font("Arial", Font.BOLD, 12));
        btnGenerarEmail.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createRaisedBevelBorder(),
            BorderFactory.createEmptyBorder(3, 8, 3, 8)));
        
        // Personalizar JTabbedPane
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));
        tabbedPane.setBackground(azulMedio);
        tabbedPane.setForeground(Color.WHITE);
        
        // Personalizar etiquetas
        Font fuenteEtiquetas = new Font("Arial", Font.BOLD, 14);
        Color colorEtiquetas = new Color(0, 51, 102);
        
        // Aplicar estilo a todas las etiquetas
        lblNombre.setFont(fuenteEtiquetas);
        lblNombre.setForeground(colorEtiquetas);
        lblApellidos.setFont(fuenteEtiquetas);
        lblApellidos.setForeground(colorEtiquetas);
        lblFechaNacimiento.setFont(fuenteEtiquetas);
        lblFechaNacimiento.setForeground(colorEtiquetas);
        lblGenero.setFont(fuenteEtiquetas);
        lblGenero.setForeground(colorEtiquetas);
        lblTipoUsuario.setFont(fuenteEtiquetas);
        lblTipoUsuario.setForeground(colorEtiquetas);
        lblIdentificacion.setFont(fuenteEtiquetas);
        lblIdentificacion.setForeground(colorEtiquetas);
        lblEspecialidad.setFont(fuenteEtiquetas);
        lblEspecialidad.setForeground(colorEtiquetas);
        lblDireccion.setFont(fuenteEtiquetas);
        lblDireccion.setForeground(colorEtiquetas);
        lblCiudad.setFont(fuenteEtiquetas);
        lblCiudad.setForeground(colorEtiquetas);
        lblEstado.setFont(fuenteEtiquetas);
        lblEstado.setForeground(colorEtiquetas);
        lblCodigoPostal.setFont(fuenteEtiquetas);
        lblCodigoPostal.setForeground(colorEtiquetas);
        lblTelefono.setFont(fuenteEtiquetas);
        lblTelefono.setForeground(colorEtiquetas);
        lblEmail.setFont(fuenteEtiquetas);
        lblEmail.setForeground(colorEtiquetas);
        lblUsuario.setFont(fuenteEtiquetas);
        lblUsuario.setForeground(colorEtiquetas);
        lblPassword.setFont(fuenteEtiquetas);
        lblPassword.setForeground(colorEtiquetas);
        lblConfirmarPassword.setFont(fuenteEtiquetas);
        lblConfirmarPassword.setForeground(colorEtiquetas);
        
        // Personalizar campos de texto
        Font fuenteCampos = new Font("Arial", Font.PLAIN, 14);
        txtNombre.setFont(fuenteCampos);
        txtApellidos.setFont(fuenteCampos);
        txtFechaNacimiento.setFont(fuenteCampos);
        txtIdentificacion.setFont(fuenteCampos);
        txtDireccion.setFont(fuenteCampos);
        txtCiudad.setFont(fuenteCampos);
        txtEstado.setFont(fuenteCampos);
        txtCodigoPostal.setFont(fuenteCampos);
        txtTelefono.setFont(fuenteCampos);
        txtEmail.setFont(fuenteCampos);
        txtUsuario.setFont(fuenteCampos);
        
        // Personalizar combos
        cmbGenero.setFont(fuenteCampos);
        cmbTipoUsuario.setFont(fuenteCampos);
        cmbEspecialidad.setFont(fuenteCampos);
        
        // Personalizar etiqueta de sugerencia de email
        lblSugerenciaEmail.setFont(new Font("Arial", Font.ITALIC, 12));
        lblSugerenciaEmail.setForeground(new Color(100, 100, 100));
        
        // Añadir listener para cambios en el tabbedPane
        tabbedPane.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                validarPestanaActual();
            }
        });
    }
    
    /** Configura la adaptabilidad de la ventana */
    private void configurarAdaptabilidad() {
        // Establecer tamaño mínimo
        this.setMinimumSize(new Dimension(900, 650));
        
        // Añadir listener para redimensionar componentes cuando cambia el tamaño de la ventana
        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                ajustarComponentes();
            }
        });
        
        // Ajustar componentes inicialmente
        ajustarComponentes();
    }
    
    /** Ajusta los componentes según el tamaño de la ventana */
    private void ajustarComponentes() {
        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();
        
        // Ajustar panelTitulo
        panelTitulo.setPreferredSize(new Dimension(width, 60));
        
        // Centrar el título
        lblTitulo.setBounds((width - lblTitulo.getPreferredSize().width) / 2, 15,
                lblTitulo.getPreferredSize().width, lblTitulo.getPreferredSize().height);
        
        // Ajustar tabbedPane con espacio para el panel de botones
        tabbedPane.setPreferredSize(new Dimension(width - 40, height - 160));
        
        // Ajustar panelBotones
        panelBotones.setPreferredSize(new Dimension(width, 60));
        
        revalidate();
        repaint();
    }
    
    /**
     * Valida los campos de la pestaña actual antes de cambiar
     */
    private void validarPestanaActual() {
        int indice = tabbedPane.getSelectedIndex();
        
        // Solo validamos al avanzar, no al retroceder
        if (indice > ultimaPestanaVisitada) {
            switch (ultimaPestanaVisitada) {
                case 0: // Validar Datos Personales
                    if (txtNombre.getText().isEmpty() || txtApellidos.getText().isEmpty() ||
                            txtIdentificacion.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(this,
                                "Por favor, complete los campos obligatorios antes de continuar",
                                "Campos incompletos", JOptionPane.WARNING_MESSAGE);
                        tabbedPane.setSelectedIndex(0);
                        return;
                    }
                    break;
                    
                case 2: // Validar Credenciales
                    String password = new String(txtPassword.getPassword());
                    String confirmPassword = new String(txtConfirmarPassword.getPassword());
                    
                    if (!password.isEmpty() && !password.equals(confirmPassword)) {
                        JOptionPane.showMessageDialog(this,
                                "Las contraseñas no coinciden",
                                "Error de validación", JOptionPane.ERROR_MESSAGE);
                        tabbedPane.setSelectedIndex(2);
                        return;
                    }
                    break;
            }
        }
        
        ultimaPestanaVisitada = indice;
    }
    
    /**
     * Inicializa y muestra la ventana
     */
    public void mostrar() {
        // Centrar en pantalla
        this.setLocationRelativeTo(null);
        
        // Inicializar componentes
        inicializarComponentes();
        
        // Mostrar ventana
        this.setVisible(true);
    }
    
    /**
     * Inicializa los componentes con valores predeterminados
     */
    private void inicializarComponentes() {
        // Inicializar combo de género
        cmbGenero.removeAllItems();
        cmbGenero.addItem("Seleccione...");
        cmbGenero.addItem("Masculino");
        cmbGenero.addItem("Femenino");
        cmbGenero.addItem("Otro");
        
        // Inicializar combo de tipo de usuario
        cmbTipoUsuario.removeAllItems();
        cmbTipoUsuario.addItem("Seleccione...");
        cmbTipoUsuario.addItem("Doctor");
        cmbTipoUsuario.addItem("Enfermero/a");
        cmbTipoUsuario.addItem("Administrativo");
        cmbTipoUsuario.addItem("Paciente");
        
        // Inicializar combo de especialidad
        cmbEspecialidad.removeAllItems();
        cmbEspecialidad.addItem("Seleccione...");
        cmbEspecialidad.addItem("Medicina General");
        cmbEspecialidad.addItem("Pediatría");
        cmbEspecialidad.addItem("Cardiología");
        cmbEspecialidad.addItem("Dermatología");
        cmbEspecialidad.addItem("Ginecología");
        cmbEspecialidad.addItem("Traumatología");
        cmbEspecialidad.addItem("Oftalmología");
        cmbEspecialidad.setEnabled(false); // Deshabilitado por defecto
        
        // Añadir listener para mostrar/ocultar campos según el tipo de usuario
        cmbTipoUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                String tipoSeleccionado = (String) cmbTipoUsuario.getSelectedItem();
                boolean esDoctor = "Doctor".equals(tipoSeleccionado);
                
                // Mostrar/ocultar campos de especialidad
                cmbEspecialidad.setEnabled(esDoctor);
                
                // Configurar permisos predeterminados según el tipo
                configurarPermisosSegunTipo(tipoSeleccionado);
            }
        });
        
        // Agregar listeners para generar email automáticamente
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                actualizarSugerenciaEmail();
            }
        });
        
        txtApellidos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                actualizarSugerenciaEmail();
            }
        });
    }
    
    /**
     * Configura los permisos predeterminados según el tipo de usuario
     */
    private void configurarPermisosSegunTipo(String tipo) {
        // Limpiar todos los permisos
        chkHistoriasClinicas.setSelected(false);
        chkFacturacion.setSelected(false);
        chkInventario.setSelected(false);
        chkReportes.setSelected(false);
        chkAdministrador.setSelected(false);
        
        // Configurar según tipo
        switch (tipo) {
            case "Doctor":
                chkHistoriasClinicas.setSelected(true);
                break;
            case "Enfermero/a":
                chkHistoriasClinicas.setSelected(true);
                break;
            case "Administrativo":
                chkFacturacion.setSelected(true);
                chkInventario.setSelected(true);
                break;
            case "Paciente":
                // Sin permisos especiales
                break;
        }
    }
    
    /**
     * Actualiza la sugerencia de email mientras el usuario escribe
     */
    private void actualizarSugerenciaEmail() {
        String nombre = txtNombre.getText().trim();
        String apellidos = txtApellidos.getText().trim();
        
        if (!nombre.isEmpty() && !apellidos.isEmpty()) {
            String emailSugerido = generarEmailPrincipal(nombre, apellidos);
            lblSugerenciaEmail.setText("Sugerencia: " + emailSugerido);
            lblSugerenciaEmail.setForeground(new Color(100, 149, 237)); // Azul
        } else {
            lblSugerenciaEmail.setText("Sugerencia: Se generará automáticamente basado en nombre y apellidos");
            lblSugerenciaEmail.setForeground(new Color(100, 100, 100)); // Gris
        }
    }
    
    /**
     * Genera el email principal (primera opción)
     */
    private String generarEmailPrincipal(String nombre, String apellidos) {
        nombre = limpiarTexto(nombre);
        apellidos = limpiarTexto(apellidos);
        String primerApellido = apellidos.split(" ")[0];
        
        return nombre.toLowerCase() + "." + primerApellido.toLowerCase() + "@sanarte.com";
    }
    
    /**
     * Genera múltiples opciones de email basadas en nombre y apellidos
     */
    private String[] generarOpcionesEmail(String nombre, String apellidos) {
        // Limpiar y normalizar texto
        nombre = limpiarTexto(nombre);
        apellidos = limpiarTexto(apellidos);
        
        // Obtener primer apellido
        String primerApellido = apellidos.split(" ")[0];
        
        // Dominio del sistema médico
        String dominio = "@sanarte.com";
        
        // Generar diferentes formatos
        String[] opciones = {
            nombre.toLowerCase() + "." + primerApellido.toLowerCase() + dominio,
            nombre.toLowerCase() + primerApellido.toLowerCase() + dominio,
            nombre.charAt(0) + primerApellido.toLowerCase() + dominio,
            nombre.toLowerCase() + "." + apellidos.toLowerCase().replace(" ", ".") + dominio,
            nombre.toLowerCase() + "_" + primerApellido.toLowerCase() + dominio,
            primerApellido.toLowerCase() + "." + nombre.toLowerCase() + dominio
        };
        
        return opciones;
    }
    
    /**
     * Genera un email alternativo cuando el principal ya existe
     */
    private String generarEmailAlternativo(String nombre, String apellidos) {
        nombre = limpiarTexto(nombre);
        apellidos = limpiarTexto(apellidos);
        String primerApellido = apellidos.split(" ")[0];
        
        // Generar número aleatorio para hacer único el email
        int numeroAleatorio = (int) (Math.random() * 999) + 1;
        
        return nombre.toLowerCase() + "." + primerApellido.toLowerCase() + 
               numeroAleatorio + "@sanarte.com";
    }
    
    /**
     * Simula la verificación de si un email ya existe en el sistema
     */
    private boolean verificarEmailExistente(String email) {
        // Lista de emails que ya "existen" en el sistema (simulación)
        String[] emailsExistentes = {
            "admin@sanarte.com",
            "doctor@sanarte.com",
            "juan.perez@sanarte.com",
            "maria.lopez@sanarte.com",
            "carlos.rodriguez@sanarte.com"
        };
        
        for (String emailExistente : emailsExistentes) {
            if (emailExistente.equalsIgnoreCase(email)) {
                return true;
            }
        }
        
        // Simulación: 20% de probabilidad de que el email ya exista
        return Math.random() < 0.2;
    }
    
    /**
     * Limpia el texto removiendo acentos y caracteres especiales
     */
    private String limpiarTexto(String texto) {
        if (texto == null) return "";
        
        // Remover acentos y caracteres especiales
        texto = texto.replaceAll("[áàäâ]", "a")
                     .replaceAll("[éèëê]", "e")
                     .replaceAll("[íìïî]", "i")
                     .replaceAll("[óòöô]", "o")
                     .replaceAll("[úùüû]", "u")
                     .replaceAll("[ñ]", "n")
                     .replaceAll("[ç]", "c");
        
        // Remover espacios extra y caracteres no alfanuméricos
        texto = texto.replaceAll("[^a-zA-Z0-9\\s]", "")
                     .replaceAll("\\s+", " ")
                     .trim();
        
        return texto;
    }
    
    /**
     * Valida el formato del email
     */
    private boolean validarEmail(String email) {
       if (email == null || email.trim().isEmpty()) {
        return false;
    }
    
    // Patrón más permisivo para emails del sistema
    String regex = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
    
    // Validación adicional para emails de sanarte.com
    if (email.toLowerCase().contains("@sanarte.com")) {
        // Más permisivo para emails del sistema
        return email.matches("^[a-zA-Z0-9._-]+@sanarte\\.com$");
    }
    
    return email.matches(regex);
    }
    
    // Agregar este método para manejar el cierre de ventana con la X
    private void formWindowClosing(java.awt.event.WindowEvent evt) {
        // Llamar al mismo método que el botón cancelar
        btnCancelarActionPerformed(null);
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelTitulo = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        tabbedPane = new javax.swing.JTabbedPane();
        panelDatosPersonales = new javax.swing.JPanel();
        lblNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lblApellidos = new javax.swing.JLabel();
        txtApellidos = new javax.swing.JTextField();
        lblFechaNacimiento = new javax.swing.JLabel();
        txtFechaNacimiento = new javax.swing.JTextField();
        lblGenero = new javax.swing.JLabel();
        cmbGenero = new javax.swing.JComboBox<>();
        lblTipoUsuario = new javax.swing.JLabel();
        cmbTipoUsuario = new javax.swing.JComboBox<>();
        lblIdentificacion = new javax.swing.JLabel();
        txtIdentificacion = new javax.swing.JTextField();
        lblEspecialidad = new javax.swing.JLabel();
        cmbEspecialidad = new javax.swing.JComboBox<>();
        panelDatosContacto = new javax.swing.JPanel();
        lblDireccion = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        lblCiudad = new javax.swing.JLabel();
        txtCiudad = new javax.swing.JTextField();
        lblEstado = new javax.swing.JLabel();
        txtEstado = new javax.swing.JTextField();
        lblCodigoPostal = new javax.swing.JLabel();
        txtCodigoPostal = new javax.swing.JTextField();
        lblTelefono = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        btnGenerarEmail = new javax.swing.JButton();
        lblSugerenciaEmail = new javax.swing.JLabel();
        panelCredenciales = new javax.swing.JPanel();
        lblUsuario = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        lblPassword = new javax.swing.JLabel();
        txtPassword = new javax.swing.JPasswordField();
        lblConfirmarPassword = new javax.swing.JLabel();
        txtConfirmarPassword = new javax.swing.JPasswordField();
        lblInstruccionesPassword = new javax.swing.JLabel();
        panelPermisos = new javax.swing.JPanel();
        lblTituloPermisos = new javax.swing.JLabel();
        chkHistoriasClinicas = new javax.swing.JCheckBox();
        chkFacturacion = new javax.swing.JCheckBox();
        chkInventario = new javax.swing.JCheckBox();
        chkReportes = new javax.swing.JCheckBox();
        chkAdministrador = new javax.swing.JCheckBox();
        panelBotones = new javax.swing.JPanel();
        btnCancelar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(800, 600));

        panelTitulo.setBackground(new java.awt.Color(70, 130, 180));
        panelTitulo.setPreferredSize(new java.awt.Dimension(800, 60));
        panelTitulo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitulo.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(255, 255, 255));
        lblTitulo.setText("Insertar Usuario");
        panelTitulo.add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 15, 200, 30));

        tabbedPane.setBackground(new java.awt.Color(240, 248, 255));
        tabbedPane.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        tabbedPane.setPreferredSize(new java.awt.Dimension(800, 255));

        panelDatosPersonales.setMinimumSize(new java.awt.Dimension(800, 600));
        panelDatosPersonales.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblNombre.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblNombre.setText("Nombre");
        panelDatosPersonales.add(lblNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, 100, 25));
        panelDatosPersonales.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, 200, 25));

        lblApellidos.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblApellidos.setText("Apellidos");
        panelDatosPersonales.add(lblApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, 100, 25));
        panelDatosPersonales.add(txtApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, 200, 25));

        lblFechaNacimiento.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblFechaNacimiento.setText("Fecha de Nacimiento");
        panelDatosPersonales.add(lblFechaNacimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, 160, 25));
        panelDatosPersonales.add(txtFechaNacimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, 160, 25));

        lblGenero.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblGenero.setText("Género");
        panelDatosPersonales.add(lblGenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 100, 25));

        cmbGenero.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        panelDatosPersonales.add(cmbGenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 150, 150, 25));

        lblTipoUsuario.setText("Tipo de Usuario");
        panelDatosPersonales.add(lblTipoUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, 120, 25));

        cmbTipoUsuario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        panelDatosPersonales.add(cmbTipoUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 190, 180, 25));

        lblIdentificacion.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblIdentificacion.setText("Identificación");
        panelDatosPersonales.add(lblIdentificacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 30, 120, 25));
        panelDatosPersonales.add(txtIdentificacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 30, 180, 25));

        lblEspecialidad.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblEspecialidad.setText("Especialidad");
        panelDatosPersonales.add(lblEspecialidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 70, 120, 25));

        cmbEspecialidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        panelDatosPersonales.add(cmbEspecialidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 70, 180, 25));

        tabbedPane.addTab("Datos Personales", panelDatosPersonales);

        panelDatosContacto.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblDireccion.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblDireccion.setText("Dirección");
        panelDatosContacto.add(lblDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, 100, 25));
        panelDatosContacto.add(txtDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, 300, 25));

        lblCiudad.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblCiudad.setText("Ciudad");
        panelDatosContacto.add(lblCiudad, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, 100, 25));
        panelDatosContacto.add(txtCiudad, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, 200, 25));

        lblEstado.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblEstado.setText("Estado/Provincia");
        panelDatosContacto.add(lblEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, 150, 25));
        panelDatosContacto.add(txtEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, 160, 25));

        lblCodigoPostal.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblCodigoPostal.setText("Código Postal");
        panelDatosContacto.add(lblCodigoPostal, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 120, 25));
        panelDatosContacto.add(txtCodigoPostal, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 100, 25));

        lblTelefono.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblTelefono.setText("Teléfono");
        panelDatosContacto.add(lblTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(495, 30, 100, 25));
        panelDatosContacto.add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(625, 30, 150, 25));

        lblEmail.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblEmail.setText("Email");
        panelDatosContacto.add(lblEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 70, 100, 25));

        txtEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmailActionPerformed(evt);
            }
        });
        panelDatosContacto.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 70, 200, 25));

        btnGenerarEmail.setBackground(new java.awt.Color(100, 149, 237));
        btnGenerarEmail.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnGenerarEmail.setForeground(new java.awt.Color(255, 255, 255));
        btnGenerarEmail.setText("Generar Email");
        btnGenerarEmail.setPreferredSize(new java.awt.Dimension(120, 25));
        btnGenerarEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerarEmailActionPerformed(evt);
            }
        });
        panelDatosContacto.add(btnGenerarEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 110, 120, 25));

        lblSugerenciaEmail.setFont(new java.awt.Font("Arial", 2, 12)); // NOI18N
        lblSugerenciaEmail.setForeground(new java.awt.Color(100, 100, 100));
        lblSugerenciaEmail.setText("Sugerencia: Se generará automáticamente basado en nombre y apellidos");
        panelDatosContacto.add(lblSugerenciaEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 200, 400, 20));

        tabbedPane.addTab("Datos de Contacto", panelDatosContacto);

        panelCredenciales.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblUsuario.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblUsuario.setText("Nombre de Usuario");
        panelCredenciales.add(lblUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, 150, 25));
        panelCredenciales.add(txtUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 50, 200, 25));

        lblPassword.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblPassword.setText("Contraseña");
        panelCredenciales.add(lblPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 150, 25));
        panelCredenciales.add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 100, 200, 25));

        lblConfirmarPassword.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblConfirmarPassword.setText("Confirmar Contraseña");
        panelCredenciales.add(lblConfirmarPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 150, 150, 25));
        panelCredenciales.add(txtConfirmarPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 150, 200, 25));

        lblInstruccionesPassword.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblInstruccionesPassword.setForeground(new java.awt.Color(153, 153, 153));
        lblInstruccionesPassword.setText("La contraseña debe tener al menos 8 caracteres, incluyendo letras y números");
        panelCredenciales.add(lblInstruccionesPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 200, -1, -1));

        tabbedPane.addTab("Credenciales", panelCredenciales);

        panelPermisos.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        panelPermisos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTituloPermisos.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        lblTituloPermisos.setText("Seleccione los permisos para este usuario");
        panelPermisos.add(lblTituloPermisos, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 350, 40));

        chkHistoriasClinicas.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        chkHistoriasClinicas.setText("Acceso a Historias Clínicas");
        panelPermisos.add(chkHistoriasClinicas, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 80, 250, 25));

        chkFacturacion.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        chkFacturacion.setText("Acceso a Facturación");
        panelPermisos.add(chkFacturacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, 250, 25));

        chkInventario.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        chkInventario.setText("Acceso a Inventario");
        panelPermisos.add(chkInventario, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 250, 25));

        chkReportes.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        chkReportes.setText("Acceso a Reportes");
        panelPermisos.add(chkReportes, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 170, 250, 25));

        chkAdministrador.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        chkAdministrador.setForeground(new java.awt.Color(0, 51, 102));
        chkAdministrador.setText("Administrador del Sistema");
        panelPermisos.add(chkAdministrador, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 200, 250, 25));

        tabbedPane.addTab("Permisos", panelPermisos);

        panelTitulo.add(tabbedPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 715, 257));

        panelBotones.setBackground(new java.awt.Color(255, 255, 255));
        panelBotones.setPreferredSize(new java.awt.Dimension(800, 60));
        panelBotones.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 5));

        btnCancelar.setBackground(new java.awt.Color(220, 20, 60));
        btnCancelar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.setPreferredSize(new java.awt.Dimension(120, 40));
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        panelBotones.add(btnCancelar);

        btnGuardar.setBackground(new java.awt.Color(46, 139, 87));
        btnGuardar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.setPreferredSize(new java.awt.Dimension(120, 40));
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        panelBotones.add(btnGuardar);

        panelTitulo.add(panelBotones, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 310, 715, 70));

        getContentPane().add(panelTitulo, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        // Confirmar si desea cancelar
        int respuesta = JOptionPane.showConfirmDialog(this,
            "¿Está seguro que desea cancelar? Se perderán los datos no guardados.",
            "Confirmar", JOptionPane.YES_NO_OPTION);

        if (respuesta == JOptionPane.YES_OPTION) {
            this.dispose();
        }
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
     // Validar campos obligatorios
        if (txtNombre.getText().trim().isEmpty() || txtApellidos.getText().trim().isEmpty() ||
                txtIdentificacion.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Por favor, complete los campos obligatorios:\n" +
                    "• Nombre\n" +
                    "• Apellidos\n" +
                    "• Identificación",
                    "Error de validación", JOptionPane.ERROR_MESSAGE);
            tabbedPane.setSelectedIndex(0); // Ir a la pestaña de datos personales
            return;
        }
        
        // Validar tipo de usuario
        String tipoUsuario = (String) cmbTipoUsuario.getSelectedItem();
        if ("Seleccione...".equals(tipoUsuario)) {
            JOptionPane.showMessageDialog(this,
                    "Por favor, seleccione un tipo de usuario",
                    "Error de validación", JOptionPane.ERROR_MESSAGE);
            tabbedPane.setSelectedIndex(0);
            cmbTipoUsuario.requestFocus();
            return;
        }
        
        // Validar que las contraseñas coincidan
        String password = new String(txtPassword.getPassword());
        String confirmPassword = new String(txtConfirmarPassword.getPassword());
        
        if (!password.isEmpty() && !password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this,
                    "Las contraseñas no coinciden",
                    "Error de validación", JOptionPane.ERROR_MESSAGE);
            tabbedPane.setSelectedIndex(2); // Ir a la pestaña de credenciales
            txtConfirmarPassword.requestFocus();
            return;
        }
        
        // NUEVA VALIDACIÓN: Verificar si se necesita generar email
        if (txtEmail.getText().trim().isEmpty()) {
            int opcion = JOptionPane.showConfirmDialog(this,
                "No se ha especificado un email para este usuario.\n\n" +
                "¿Desea generar uno automáticamente basado en:\n" +
                "• Nombre: " + txtNombre.getText().trim() + "\n" +
                "• Apellidos: " + txtApellidos.getText().trim() + "\n\n" +
                "El email será necesario para que el usuario pueda acceder al sistema.",
                "Generar Email Automáticamente",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            
            if (opcion == JOptionPane.YES_OPTION) {
                // Generar email automáticamente
                String emailGenerado = generarEmailPrincipal(txtNombre.getText().trim(), txtApellidos.getText().trim());
                
                // Verificar si existe
                if (verificarEmailExistente(emailGenerado)) {
                    emailGenerado = generarEmailAlternativo(txtNombre.getText().trim(), txtApellidos.getText().trim());
                }
                
                txtEmail.setText(emailGenerado);
                
                JOptionPane.showMessageDialog(this,
                    "✅ Email generado automáticamente:\n\n" +
                    "📧 " + emailGenerado + "\n\n" +
                    "Este email se usará para el acceso al sistema.",
                    "Email Generado",
                    JOptionPane.INFORMATION_MESSAGE);
                    
            } else if (opcion == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(this,
                    "⚠️ ADVERTENCIA:\n\n" +
                    "El usuario se guardará sin email.\n" +
                    "No podrá acceder al sistema hasta que se le asigne uno.",
                    "Usuario sin Email",
                    JOptionPane.WARNING_MESSAGE);
            } else {
                // Cancelar - volver a la pestaña de contacto
                tabbedPane.setSelectedIndex(1);
                txtEmail.requestFocus();
                return;
            }
        }
        
        // Validar formato de email si se proporcionó
        if (!txtEmail.getText().trim().isEmpty() && !validarEmail(txtEmail.getText().trim())) {
            JOptionPane.showMessageDialog(this,
                    "El formato del email no es válido",
                    "Error de validación", JOptionPane.ERROR_MESSAGE);
            tabbedPane.setSelectedIndex(1); // Ir a la pestaña de contacto
            txtEmail.requestFocus();
            return;
        }
        
        // En el mensaje de éxito, incluir el email generado
        String emailFinal = txtEmail.getText().trim();
        String mensajeExito = "✅ USUARIO GUARDADO EXITOSAMENTE\n\n" +
            "Nombre: " + txtNombre.getText().trim() + " " + txtApellidos.getText().trim() + "\n" +
            "Identificación: " + txtIdentificacion.getText().trim() + "\n" +
            "Tipo: " + tipoUsuario + "\n";
        
        if (!emailFinal.isEmpty()) {
            mensajeExito += "Email: " + emailFinal + "\n\n" +
                "🔑 CREDENCIALES DE ACCESO:\n" +
                "• Email: " + emailFinal + "\n" +
                "• Contraseña: " + (password.isEmpty() ? "Se debe asignar una contraseña" : "Configurada correctamente") + "\n\n";
        }
        
        mensajeExito += "El usuario ha sido registrado correctamente en el sistema.";
        
        JOptionPane.showMessageDialog(this, mensajeExito, "Usuario Guardado", JOptionPane.INFORMATION_MESSAGE);
        
        // Cerrar esta ventana
        this.dispose();
        
        // Volver a la ventana de Administrador
        try {
            Administrador ventanaAdmin = new Administrador();
            ventanaAdmin.setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                "Error al regresar al panel de administración: " + e.getMessage(),
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnGenerarEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerarEmailActionPerformed
         String nombre = txtNombre.getText().trim();
    String apellidos = txtApellidos.getText().trim();
    
    if (nombre.isEmpty() || apellidos.isEmpty()) {
        JOptionPane.showMessageDialog(this,
            "Para generar el email automáticamente, primero debe completar:\n" +
            "• Nombre\n" +
            "• Apellidos\n\n" +
            "Luego haga clic en 'Generar Email'",
            "Datos Requeridos", 
            JOptionPane.WARNING_MESSAGE);
        
        // Ir a la pestaña de datos personales
        tabbedPane.setSelectedIndex(0);
        
        if (nombre.isEmpty()) {
            txtNombre.requestFocus();
        } else {
            txtApellidos.requestFocus();
        }
        return;
    }
    
    // Generar múltiples opciones de email
    String[] opcionesEmail = generarOpcionesEmail(nombre, apellidos);
    
    // Mostrar diálogo para seleccionar el email
    String emailSeleccionado = (String) JOptionPane.showInputDialog(
        this,
        "Seleccione el formato de email que desea usar:\n\n" +
        "Nombre: " + nombre + "\n" +
        "Apellidos: " + apellidos + "\n",
        "Seleccionar Email",
        JOptionPane.QUESTION_MESSAGE,
        null,
        opcionesEmail,
        opcionesEmail[0]
    );
    
    if (emailSeleccionado != null) {
        // Verificar si el email ya existe (simulación)
        if (verificarEmailExistente(emailSeleccionado)) {
            // Si existe, ofrecer alternativas
            String emailAlternativo = generarEmailAlternativo(nombre, apellidos);
            
            int opcion = JOptionPane.showConfirmDialog(this,
                "⚠️ El email '" + emailSeleccionado + "' ya está en uso.\n\n" +
                "¿Desea usar esta alternativa?\n" +
                "📧 " + emailAlternativo,
                "Email Duplicado",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
            
            if (opcion == JOptionPane.YES_OPTION) {
                txtEmail.setText(emailAlternativo);
            } else {
                // Permitir al usuario editar manualmente
                txtEmail.setText(emailSeleccionado);
                txtEmail.requestFocus();
                txtEmail.selectAll();
            }
        } else {
            // Email disponible
            txtEmail.setText(emailSeleccionado);
            
            JOptionPane.showMessageDialog(this,
                "✅ Email generado correctamente:\n\n" +
                "📧 " + emailSeleccionado + "\n\n" +
                "Este email estará disponible para el login del usuario.",
                "Email Generado",
                JOptionPane.INFORMATION_MESSAGE);
        }
        
        // Actualizar la sugerencia
        lblSugerenciaEmail.setText("Email generado: " + txtEmail.getText());
        lblSugerenciaEmail.setForeground(new Color(0, 128, 0)); // Verde
        // En el método btnGuardarActionPerformed, agrega esta línea de debug:
        System.out.println("Email a guardar: '" + txtEmail.getText().trim() + "'");
    }
    }//GEN-LAST:event_btnGenerarEmailActionPerformed

    private void txtEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailActionPerformed
      // Validar el email cuando el usuario presiona Enter
    String email = txtEmail.getText().trim();
    
    if (!email.isEmpty()) {
        if (validarEmail(email)) {
            // Email válido - actualizar sugerencia
            lblSugerenciaEmail.setText("Email válido: " + email);
            lblSugerenciaEmail.setForeground(new Color(0, 128, 0)); // Verde
        } else {
            // Email inválido - mostrar error
            lblSugerenciaEmail.setText("⚠️ Formato de email inválido");
            lblSugerenciaEmail.setForeground(new Color(220, 20, 60)); // Rojo
            
            JOptionPane.showMessageDialog(this,
                "El formato del email no es válido.\n\n" +
                "Formato correcto: usuario@dominio.com",
                "Email Inválido",
                JOptionPane.WARNING_MESSAGE);
            
            txtEmail.requestFocus();
            txtEmail.selectAll();
        }
    } else {
        // Campo vacío - mostrar sugerencia
        actualizarSugerenciaEmail();
    }
    }//GEN-LAST:event_txtEmailActionPerformed

/**
 * Valida el formato de fecha DD/MM/AAAA
 */
private boolean validarFecha(String fecha) {
    try {
        String[] partes = fecha.split("/");
        if (partes.length != 3) return false;
        
        int dia = Integer.parseInt(partes[0]);
        int mes = Integer.parseInt(partes[1]);
        int año = Integer.parseInt(partes[2]);
        
        // Validaciones básicas
        if (dia < 1 || dia > 31) return false;
        if (mes < 1 || mes > 12) return false;
        if (año < 1900 || año > 2024) return false;
        
        return true;
    } catch (NumberFormatException e) {
        return false;
    }
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(insertarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(insertarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(insertarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(insertarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new insertarUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnGenerarEmail;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JCheckBox chkAdministrador;
    private javax.swing.JCheckBox chkFacturacion;
    private javax.swing.JCheckBox chkHistoriasClinicas;
    private javax.swing.JCheckBox chkInventario;
    private javax.swing.JCheckBox chkReportes;
    private javax.swing.JComboBox<String> cmbEspecialidad;
    private javax.swing.JComboBox<String> cmbGenero;
    private javax.swing.JComboBox<String> cmbTipoUsuario;
    private javax.swing.JLabel lblApellidos;
    private javax.swing.JLabel lblCiudad;
    private javax.swing.JLabel lblCodigoPostal;
    private javax.swing.JLabel lblConfirmarPassword;
    private javax.swing.JLabel lblDireccion;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblEspecialidad;
    private javax.swing.JLabel lblEstado;
    private javax.swing.JLabel lblFechaNacimiento;
    private javax.swing.JLabel lblGenero;
    private javax.swing.JLabel lblIdentificacion;
    private javax.swing.JLabel lblInstruccionesPassword;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblPassword;
    private javax.swing.JLabel lblSugerenciaEmail;
    private javax.swing.JLabel lblTelefono;
    private javax.swing.JLabel lblTipoUsuario;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblTituloPermisos;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JPanel panelBotones;
    private javax.swing.JPanel panelCredenciales;
    private javax.swing.JPanel panelDatosContacto;
    private javax.swing.JPanel panelDatosPersonales;
    private javax.swing.JPanel panelPermisos;
    private javax.swing.JPanel panelTitulo;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtCiudad;
    private javax.swing.JTextField txtCodigoPostal;
    private javax.swing.JPasswordField txtConfirmarPassword;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEstado;
    private javax.swing.JTextField txtFechaNacimiento;
    private javax.swing.JTextField txtIdentificacion;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtTelefono;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
