/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Ventanas;
import Conexion.ConexionDB;
import Conexion.UsuarioDAO;
import Conexion.UsuarioDAO.UsuarioCompleto;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author socta
 */
public class EliminarUsuario extends javax.swing.JFrame {
    private UsuarioDAO usuarioDAO;
    private List<UsuarioCompleto> usuariosActuales;
    
    /**
     * Creates new form EliminarUsuario
     */
    public EliminarUsuario() {
        // Inicializar DAO
        usuarioDAO = new UsuarioDAO();
        
        initComponents();
        inicializarComponentes();
        personalizarComponentes();
        cargarDatosIniciales();
    }
    
    /**
     * Inicializa los componentes con valores predeterminados
     */
    private void inicializarComponentes() {
        // Inicializar combo de criterios de búsqueda
        cmbCriterioBusqueda.removeAllItems();
        cmbCriterioBusqueda.addItem("Nombre");
        cmbCriterioBusqueda.addItem("Apellidos");
        cmbCriterioBusqueda.addItem("Identificación");
        cmbCriterioBusqueda.addItem("Tipo de Usuario");
        
        // Configurar tabla
        tablaUsuarios.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        
        // Ocultar etiqueta de confirmación inicialmente
        lblConfirmacion.setVisible(false);
        
        // Centrar la ventana
        this.setLocationRelativeTo(null);
        
        // Añadir listener para el cierre de la ventana
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                btnVolverActionPerformed(null);
            }
        });
    }
    
    /**
     * Personaliza la apariencia de los componentes
     */
    private void personalizarComponentes() {
        // Personalizar botones
        personalizarBoton(btnEliminar, new Color(220, 20, 60), Color.WHITE);
        personalizarBoton(btnCancelar, new Color(128, 128, 128), Color.WHITE);
        personalizarBoton(btnVolver, new Color(0, 51, 102), Color.WHITE);
        personalizarBoton(btnBuscar, new Color(100, 149, 237), Color.WHITE);
        
        // Personalizar tabla
        tablaUsuarios.setRowHeight(25);
        tablaUsuarios.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        tablaUsuarios.getTableHeader().setBackground(new Color(70, 130, 180));
        tablaUsuarios.getTableHeader().setForeground(Color.WHITE);
    }
    
    /**
     * Cargar datos iniciales de la base de datos
     */
    private void cargarDatosIniciales() {
        try {
            System.out.println("🔄 Iniciando carga de datos...");
        
            // Verificar conexión
            if (ConexionDB.getConexion() == null) {
                System.err.println("❌ Error: Conexión es null");
                JOptionPane.showMessageDialog(this,
                    "❌ Error de conexión a la base de datos.\n" +
                    "Verifique que PostgreSQL esté ejecutándose y la configuración sea correcta.",
                    "Error de Conexión",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
        
            System.out.println("✅ Conexión establecida correctamente");
        
            // Obtener usuarios de la base de datos
            List<UsuarioCompleto> usuarios = usuarioDAO.obtenerTodosLosUsuarios();
        
            System.out.println("📊 Usuarios obtenidos de la BD: " + usuarios.size());
        
            if (usuarios.isEmpty()) {
                System.out.println("⚠️ No se encontraron usuarios en la base de datos");
            
                // Verificar si hay datos en las tablas
                verificarDatosEnTablas();
            
                JOptionPane.showMessageDialog(this,
                    "⚠️ No se encontraron usuarios en la base de datos.\n\n" +
                    "Posibles causas:\n" +
                    "• Las tablas están vacías\n" +
                    "• Los scripts de inserción no se ejecutaron\n" +
                    "• Problema con el schema de la base de datos\n\n" +
                    "Revise la consola para más detalles.",
                    "Sin Datos",
                    JOptionPane.WARNING_MESSAGE);
            } else {
                System.out.println("✅ Cargando " + usuarios.size() + " usuarios en la tabla");
            }
        
            // Cargar usuarios en la tabla (aunque esté vacía)
            cargarUsuarios(usuarios);
        
        } catch (Exception e) {
            System.err.println("❌ Error al cargar datos iniciales: " + e.getMessage());
            e.printStackTrace();
        
            JOptionPane.showMessageDialog(this,
                "❌ Error al cargar datos iniciales:\n\n" + e.getMessage() + 
                "\n\nRevise la consola para más detalles.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Verificar si hay datos en las tablas principales
     */
    private void verificarDatosEnTablas() {
        try {
            System.out.println("\n🔍 === VERIFICANDO DATOS EN TABLAS ===");
        
            java.sql.Connection conn = ConexionDB.getConexion();
            if (conn == null) {
                System.err.println("❌ No se pudo obtener conexión para verificar");
                return;
            }
        
            // Verificar tabla usuarios
            java.sql.Statement stmt = conn.createStatement();
            java.sql.ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as total FROM usuarios");
            if (rs.next()) {
                int totalUsuarios = rs.getInt("total");
                System.out.println("👥 Total usuarios en BD: " + totalUsuarios);
            }
        
            // Verificar tabla tipos_usuario
            rs = stmt.executeQuery("SELECT COUNT(*) as total FROM tipos_usuario");
            if (rs.next()) {
                int totalTipos = rs.getInt("total");
                System.out.println("🏷️ Total tipos de usuario: " + totalTipos);
            }
        
            // Mostrar algunos usuarios de ejemplo
            rs = stmt.executeQuery("SELECT u.nombre, u.apellidos, tu.nombre as tipo FROM usuarios u JOIN tipos_usuario tu ON u.tipo_usuario_id = tu.id LIMIT 5");
            System.out.println("\n📋 Primeros usuarios encontrados:");
            int contador = 1;
            while (rs.next()) {
                System.out.printf("%d. %s %s (%s)\n", 
                    contador++,
                    rs.getString("nombre"), 
                    rs.getString("apellidos"), 
                    rs.getString("tipo"));
            }
        
            rs.close();
            stmt.close();
        
            System.out.println("=== FIN VERIFICACIÓN ===\n");
        
        } catch (Exception e) {
            System.err.println("❌ Error al verificar datos: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Cargar usuarios en la tabla
     */
    private void cargarUsuarios(List<UsuarioCompleto> usuarios) {
        System.out.println("🔄 Cargando " + usuarios.size() + " usuarios en la tabla...");
    
        usuariosActuales = usuarios;
    
        // Configurar modelo de tabla
        String[] columnas = {"ID", "Nombre", "Apellidos", "Tipo Usuario", "Identificación", "Email"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Hacer la tabla no editable
            }
        };
    
        // Llenar tabla con datos
        for (UsuarioCompleto usuario : usuarios) {
            Object[] fila = {
                usuario.getId(),
                usuario.getNombre() != null ? usuario.getNombre() : "N/A",
                usuario.getApellidos() != null ? usuario.getApellidos() : "N/A", 
                usuario.getTipoUsuario() != null ? usuario.getTipoUsuario() : "N/A",
                usuario.getIdentificacion() != null ? usuario.getIdentificacion() : "N/A",
                usuario.getEmail() != null ? usuario.getEmail() : "N/A"
            };
            modelo.addRow(fila);
        
            // Debug: mostrar cada usuario que se agrega
            System.out.printf("➕ Agregado: %s %s (%s)\n", 
                usuario.getNombre(), 
                usuario.getApellidos(), 
                usuario.getTipoUsuario());
        }
    
        // Establecer el modelo en la tabla
        tablaUsuarios.setModel(modelo);
    
        // Ajustar ancho de columnas
        if (tablaUsuarios.getColumnCount() > 0) {
            tablaUsuarios.getColumnModel().getColumn(0).setPreferredWidth(50);  // ID
            tablaUsuarios.getColumnModel().getColumn(1).setPreferredWidth(100); // Nombre
            tablaUsuarios.getColumnModel().getColumn(2).setPreferredWidth(100); // Apellidos
            tablaUsuarios.getColumnModel().getColumn(3).setPreferredWidth(120); // Tipo Usuario
            tablaUsuarios.getColumnModel().getColumn(4).setPreferredWidth(100); // Identificación
            tablaUsuarios.getColumnModel().getColumn(5).setPreferredWidth(180); // Email
        }
    
        // Actualizar información
        lblInstrucciones.setText(
            String.format("Se encontraron %d usuarios. Seleccione uno de la tabla y haga clic en 'Eliminar' para eliminarlo del sistema", 
                         usuarios.size())
        );
    
        System.out.println("✅ Tabla actualizada con " + usuarios.size() + " usuarios");
    
        // Forzar actualización visual
        tablaUsuarios.revalidate();
        tablaUsuarios.repaint();
    }
    
    /**
     * Personaliza un botón con colores y efectos
     */
    private void personalizarBoton(JButton boton, Color fondo, Color texto) {
        boton.setBackground(fondo);
        boton.setForeground(texto);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createRaisedBevelBorder(),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Efecto hover
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(mezclarColores(fondo, Color.BLACK, 0.1f));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(fondo);
            }
        });
    }
    
    /**
     * Mezcla dos colores con un porcentaje dado
     */
    private Color mezclarColores(Color color1, Color color2, float porcentaje) {
        int r = (int) (color1.getRed() * (1 - porcentaje) + color2.getRed() * porcentaje);
        int g = (int) (color1.getGreen() * (1 - porcentaje) + color2.getGreen() * porcentaje);
        int b = (int) (color1.getBlue() * (1 - porcentaje) + color2.getBlue() * porcentaje);
        return new Color(r, g, b);
    }



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelTitulo = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        panelPrincipal = new javax.swing.JPanel();
        lblBusqueda = new javax.swing.JLabel();
        txtBusqueda = new javax.swing.JTextField();
        lblCriterioBusqueda = new javax.swing.JLabel();
        cmbCriterioBusqueda = new javax.swing.JComboBox<>();
        btnBuscar = new javax.swing.JButton();
        scrollTabla = new java.awt.ScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaUsuarios = new javax.swing.JTable();
        lblInstrucciones = new javax.swing.JLabel();
        lblConfirmacion = new javax.swing.JLabel();
        panelBotones = new javax.swing.JPanel();
        btnEliminar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Eliminar Usuario");
        setPreferredSize(new java.awt.Dimension(800, 600));

        panelTitulo.setBackground(new java.awt.Color(70, 130, 180));
        panelTitulo.setPreferredSize(new java.awt.Dimension(800, 60));
        panelTitulo.setLayout(null);

        lblTitulo.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lblTitulo.setText("Eliminar Usuario");
        panelTitulo.add(lblTitulo);
        lblTitulo.setBounds(300, 15, 200, 30);

        getContentPane().add(panelTitulo, java.awt.BorderLayout.NORTH);

        panelPrincipal.setBackground(new java.awt.Color(240, 248, 255));
        panelPrincipal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblBusqueda.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblBusqueda.setText("Buscar Usuario");
        panelPrincipal.add(lblBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, 120, 25));
        panelPrincipal.add(txtBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 30, 250, 25));

        lblCriterioBusqueda.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblCriterioBusqueda.setText("Criterio");
        panelPrincipal.add(lblCriterioBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 30, 80, 25));

        cmbCriterioBusqueda.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        panelPrincipal.add(cmbCriterioBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 30, 150, 25));

        btnBuscar.setBackground(new java.awt.Color(100, 149, 237));
        btnBuscar.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        panelPrincipal.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 30, 80, 25));

        scrollTabla.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        tablaUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"1", "Juan", "Pérez", "Doctor", "12345678", "juan.perez@ejemplo.com"},
                {"2", "María", "López,", "Enfermera", "87654321", "maria.lopez@ejemplo.com"},
                {"3", "Carlos", "Rodríguez", "Administrativo,", "13579246", "carlos.rodriguez@ejemplo.com"},
                {"4", "Ana ", "Martínez ", "Paciente", "24681357 ", "ana.Martinez@gmail.com"},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Apellidos", "Tipo Usuario", "Identificación", "Email"
            }
        ));
        jScrollPane1.setViewportView(tablaUsuarios);

        scrollTabla.add(jScrollPane1);

        panelPrincipal.add(scrollTabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 700, 300));

        lblInstrucciones.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        lblInstrucciones.setForeground(new java.awt.Color(80, 80, 80));
        lblInstrucciones.setText("Seleccione un usuario de la tabla y haga clic en 'Eliminar' para eliminarlo del sistema");
        panelPrincipal.add(lblInstrucciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 390, 700, 200));

        lblConfirmacion.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblConfirmacion.setForeground(new java.awt.Color(220, 20, 60));
        lblConfirmacion.setText("¿Está seguro que desea eliminar al usuario seleccionado?");
        panelPrincipal.add(lblConfirmacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 420, 700, 25));

        getContentPane().add(panelPrincipal, java.awt.BorderLayout.CENTER);

        panelBotones.setBackground(new java.awt.Color(70, 130, 180));
        panelBotones.setPreferredSize(new java.awt.Dimension(800, 60));
        panelBotones.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 15));

        btnEliminar.setBackground(new java.awt.Color(220, 20, 60));
        btnEliminar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminar.setText("Eliminar");
        btnEliminar.setPreferredSize(new java.awt.Dimension(120, 40));
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        panelBotones.add(btnEliminar);

        btnCancelar.setBackground(new java.awt.Color(128, 128, 128));
        btnCancelar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnCancelar.setForeground(new java.awt.Color(255, 255, 255));
        btnCancelar.setText("Cancelar");
        btnCancelar.setPreferredSize(new java.awt.Dimension(120, 40));
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        panelBotones.add(btnCancelar);

        btnVolver.setBackground(new java.awt.Color(0, 51, 102));
        btnVolver.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver");
        btnVolver.setPreferredSize(new java.awt.Dimension(120, 40));
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        panelBotones.add(btnVolver);

        getContentPane().add(panelBotones, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed

        // Verificar si hay una fila seleccionada
        int filaSeleccionada = tablaUsuarios.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this,
                "⚠️ Por favor, seleccione un usuario de la tabla",
                "Selección requerida", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            // Obtener datos del usuario seleccionado
            Long usuarioId = (Long) tablaUsuarios.getValueAt(filaSeleccionada, 0);
            String nombreUsuario = tablaUsuarios.getValueAt(filaSeleccionada, 1).toString();
            String apellidosUsuario = tablaUsuarios.getValueAt(filaSeleccionada, 2).toString();
            String tipoUsuario = tablaUsuarios.getValueAt(filaSeleccionada, 3).toString();
            
            // Verificar si el usuario tiene dependencias
            if (usuarioDAO.usuarioTieneDependencias(usuarioId)) {
                int respuesta = JOptionPane.showConfirmDialog(this,
                    "⚠️ ADVERTENCIA: El usuario " + nombreUsuario + " " + apellidosUsuario + 
                    " (" + tipoUsuario + ") tiene registros asociados en el sistema.\n\n" +
                    "Si continúa, el usuario será desactivado pero sus registros se mantendrán.\n" +
                    "¿Desea continuar con la eliminación?",
                    "Usuario con dependencias",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);
                
                if (respuesta != JOptionPane.YES_OPTION) {
                    return;
                }
            }
            
            // Confirmar eliminación
            int confirmacion = JOptionPane.showConfirmDialog(this,
                "🗑️ ¿Está seguro que desea eliminar al usuario?\n\n" +
                "👤 Nombre: " + nombreUsuario + " " + apellidosUsuario + "\n" +
                "🏷️ Tipo: " + tipoUsuario + "\n\n" +
                "Esta acción desactivará el usuario en el sistema.",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            
            if (confirmacion == JOptionPane.YES_OPTION) {
                // Eliminar usuario de la base de datos
                if (usuarioDAO.eliminarUsuario(usuarioId)) {
                    JOptionPane.showMessageDialog(this,
                        "✅ Usuario eliminado correctamente\n\n" +
                        "El usuario " + nombreUsuario + " " + apellidosUsuario + 
                        " ha sido desactivado del sistema.",
                        "Eliminación exitosa",
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    // Recargar datos
                    cargarDatosIniciales();
                    
                    // Ocultar la etiqueta de confirmación
                    lblConfirmacion.setVisible(false);
                    
                    // Limpiar selección
                    tablaUsuarios.clearSelection();
                    
                } else {
                    JOptionPane.showMessageDialog(this,
                        "❌ Error al eliminar el usuario\n\n" +
                        "No se pudo completar la operación. Intente nuevamente.",
                        "Error de eliminación",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "❌ Error inesperado: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
          // Limpiar campos y selección
        txtBusqueda.setText("");
        tablaUsuarios.clearSelection();
        lblConfirmacion.setVisible(false);
         // Recargar datos originales
        cargarDatosIniciales();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        // Cerrar esta ventana y volver a la ventana de administrador
        this.dispose();
        new Administrador().setVisible(true);
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
    // Obtener criterios de búsqueda
        String textoBusqueda = txtBusqueda.getText().trim();
        
        if (textoBusqueda.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "⚠️ Por favor, ingrese un texto para buscar",
                "Campo vacío", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String criterio = cmbCriterioBusqueda.getSelectedItem().toString();
        
        try {
            // Realizar búsqueda en la base de datos
            List<UsuarioCompleto> usuariosEncontrados = usuarioDAO.buscarUsuarios(textoBusqueda, criterio);
            
            // Cargar resultados en la tabla
            cargarUsuarios(usuariosEncontrados);
            
            // Mostrar mensaje de resultado
            if (usuariosEncontrados.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "🔍 No se encontraron usuarios que coincidan con:\n\n" +
                    "Texto: \"" + textoBusqueda + "\"\n" +
                    "Criterio: " + criterio,
                    "Sin resultados",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "✅ Búsqueda completada\n\n" +
                    "Se encontraron " + usuariosEncontrados.size() + " usuario(s) que coinciden con:\n" +
                    "Texto: \"" + textoBusqueda + "\"\n" +
                    "Criterio: " + criterio,
                    "Resultados de búsqueda",
                    JOptionPane.INFORMATION_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "❌ Error al realizar la búsqueda: " + e.getMessage(),
                "Error de búsqueda",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EliminarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EliminarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EliminarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EliminarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EliminarUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JComboBox<String> cmbCriterioBusqueda;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBusqueda;
    private javax.swing.JLabel lblConfirmacion;
    private javax.swing.JLabel lblCriterioBusqueda;
    private javax.swing.JLabel lblInstrucciones;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JPanel panelBotones;
    private javax.swing.JPanel panelPrincipal;
    private javax.swing.JPanel panelTitulo;
    private java.awt.ScrollPane scrollTabla;
    private javax.swing.JTable tablaUsuarios;
    private javax.swing.JTextField txtBusqueda;
    // End of variables declaration//GEN-END:variables
}
