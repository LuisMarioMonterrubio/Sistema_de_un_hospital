/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Ventanas;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.netbeans.lib.awtextra.AbsoluteConstraints;
import org.netbeans.lib.awtextra.AbsoluteLayout;

/**
 *
 * @author socta
 */
public class Administrador extends javax.swing.JFrame {

    /**
     * Creates new form Administrador
     */
    public Administrador() {
        initComponents();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.setMinimumSize(new Dimension(800, 600));
        this.setLocationRelativeTo(null);
        personalizarComponentes();
        configurarAdaptabilidad();
        configurarCierreVentana();
    }
    
    private void personalizarComponentes() {
        personalizarBoton(btnModificar, new Color(255, 165, 0), Color.WHITE);
        personalizarBoton(btnCerrar, new Color(128, 128, 128), Color.WHITE);

        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelBotones.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        try {
            ImageIcon icono = new ImageIcon(getClass().getResource("/IMAGENES/logo---.png"));
            if (icono.getIconWidth() != -1) {
                Image img = icono.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                lblLogo.setIcon(new ImageIcon(img));
                lblLogo.setText("");
            }
        } catch (Exception e) {
            System.out.println("No se pudo cargar el logo: " + e.getMessage());
        }
    }
    
    private void configurarCierreVentana() {
        // Configurar comportamiento de cierre
        this.setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                btnCerrarActionPerformed(new java.awt.event.ActionEvent(this, 0, ""));
            }
        });
    }
    
     private void configurarAdaptabilidad() {
        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int width = getContentPane().getWidth();
                int height = getContentPane().getHeight();

                ((AbsoluteLayout) panelPrincipal.getLayout()).removeLayoutComponent(panelTitulo);
                panelPrincipal.add(panelTitulo, new AbsoluteConstraints(0, 0, width, 80));

                ((AbsoluteLayout) panelPrincipal.getLayout()).removeLayoutComponent(panelLateral);
                panelPrincipal.add(panelLateral, new AbsoluteConstraints(0, 80, 200, height - 80));

                int panelBotonesWidth = Math.min(400, width - 100);
                int panelBotonesX = (width - panelBotonesWidth) / 2;
                int panelBotonesY = 100;

                panelPrincipal.add(panelBotones, new AbsoluteConstraints(panelBotonesX, panelBotonesY, panelBotonesWidth, height - panelBotonesY - 50));

                int buttonWidth = panelBotonesWidth - 40;
                int buttonX = (panelBotonesWidth - buttonWidth) / 2;
                int buttonHeight = 50;
                int spacing = 15;
                int startY = 20;

                panelBotones.add(btnModificar, new AbsoluteConstraints(buttonX, startY, buttonWidth, buttonHeight));
                panelBotones.add(btnCerrar, new AbsoluteConstraints(buttonX, startY + (buttonHeight + spacing), buttonWidth, buttonHeight));

                revalidate();
                repaint();
            }
        });
    }
    
    private void personalizarBoton(javax.swing.JButton boton, Color fondo, Color texto) {
        boton.setBackground(fondo);
        boton.setForeground(texto);
        boton.setFont(new Font("Arial", Font.BOLD, 16));
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createRaisedBevelBorder(),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Efecto hover para los botones
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(mezclarColores(fondo, Color.BLACK, 0.1f));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(fondo);
            }
        });
    }
    
    private Color mezclarColores(Color color1, Color color2, float porcentaje) {
        int r = (int) (color1.getRed() * (1 - porcentaje) + color2.getRed() * porcentaje);
        int g = (int) (color1.getGreen() * (1 - porcentaje) + color2.getGreen() * porcentaje);
        int b = (int) (color1.getBlue() * (1 - porcentaje) + color2.getBlue() * porcentaje);
        return new Color(r, g, b);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelPrincipal = new javax.swing.JPanel();
        panelTitulo = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        panelLateral = new javax.swing.JPanel();
        lblLogo = new javax.swing.JLabel();
        panelBotones = new javax.swing.JPanel();
        btnModificar = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Administrador de Usuarios");
        setPreferredSize(new java.awt.Dimension(580, 490));
        setSize(new java.awt.Dimension(800, 700));

        panelPrincipal.setBackground(new java.awt.Color(240, 248, 255));
        panelPrincipal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelTitulo.setBackground(new java.awt.Color(70, 130, 180));
        panelTitulo.setVerifyInputWhenFocusTarget(false);
        panelTitulo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitulo.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lblTitulo.setText("Usuarios");
        panelTitulo.add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 130, 20));

        panelLateral.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        panelLateral.setLayout(new java.awt.BorderLayout());

        lblLogo.setIcon(new javax.swing.ImageIcon("C:\\Users\\socta\\Downloads\\ilustracion_Panel_Lateral.png")); // NOI18N
        lblLogo.setText("logo");
        lblLogo.setMaximumSize(new java.awt.Dimension(208, 450));
        lblLogo.setMinimumSize(new java.awt.Dimension(208, 450));
        lblLogo.setPreferredSize(new java.awt.Dimension(208, 450));
        panelLateral.add(lblLogo, java.awt.BorderLayout.CENTER);

        panelTitulo.add(panelLateral, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 450));

        panelBotones.setBackground(new java.awt.Color(240, 248, 255));
        panelBotones.setBorder(javax.swing.BorderFactory.createEmptyBorder(30, 50, 30, 50));
        panelBotones.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnModificar.setBackground(new java.awt.Color(255, 165, 0));
        btnModificar.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        btnModificar.setText("Usuarios");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        panelBotones.add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 280, -1));

        btnCerrar.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });
        panelBotones.add(btnCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 280, -1));

        panelTitulo.add(panelBotones, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 30, 300, 400));

        panelPrincipal.add(panelTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 1030));

        getContentPane().add(panelPrincipal, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        // Mostrar diálogo de confirmación
        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Está seguro que desea cerrar la sesión y volver a la pantalla de acceso?",
            "Confirmar cierre",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            // Mostrar mensaje de despedida
            JOptionPane.showMessageDialog(
                this,
                "Gracias por utilizar el Sistema SanArte.\nHasta pronto.",
                "Sesión finalizada",
                JOptionPane.INFORMATION_MESSAGE);
            
            // Cerrar esta ventana y volver a la ventana de acceso
            this.dispose();
            
            // Crear y mostrar la ventana de acceso
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {
                    new Acces().setVisible(true);
                }
            });
        }
        // Si el usuario selecciona "No", no hacemos nada y se mantiene en la ventana actual
    }//GEN-LAST:event_btnCerrarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
     // Crear una instancia de la ventana ModificarUsuario
    ModificarUsuario ventanaModificar = new ModificarUsuario();
    
    // Hacer visible la ventana
    ventanaModificar.setVisible(true);
    
    // Ocultar la ventana actual
    this.dispose();
    }//GEN-LAST:event_btnModificarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Administrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Administrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Administrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Administrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Administrador().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JPanel panelBotones;
    private javax.swing.JPanel panelLateral;
    private javax.swing.JPanel panelPrincipal;
    private javax.swing.JPanel panelTitulo;
    // End of variables declaration//GEN-END:variables
}
