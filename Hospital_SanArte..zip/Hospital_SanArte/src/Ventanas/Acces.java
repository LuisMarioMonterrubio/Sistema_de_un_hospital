/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Ventanas;
import Ventanas.Administrador;
import Ventanas.Paciente;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.GradientPaint;
import javax.swing.JPanel;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author socta
 */
public class Acces extends javax.swing.JFrame {
       
    // Patrón para validar correo electrónico
    private static final String EMAIL_PATTERN = "^[a-zA-Z0-9_+&-]+(?:\\.[a-zA-Z0-9_+&-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    private static final Pattern emailPattern = Pattern.compile(EMAIL_PATTERN);
    
    // Variable para controlar si el captcha fue resuelto correctamente
    private boolean captchaResuelto = false;
    private javax.swing.Timer verificadorCaptcha;
    
    public Acces() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("Sistema SanArte - Acceso");
        this.setResizable(false);
        
        // Personalizar componentes después de inicializar
        personalizarComponentes();
        
        // Limpiar textos predeterminados DESPUÉS de initComponents
        limpiarCamposIniciales();
        
        // Configurar el captcha
        configurarCaptcha();
        
        // Inicialmente deshabilitar el botón entrar
        btnEntrar.setEnabled(false);
        actualizarEstiloBotonDeshabilitado();
    }
    
    // Método para configurar el captcha
    private void configurarCaptcha() {
        // Crear un timer para verificar periódicamente el estado del captcha
        verificadorCaptcha = new javax.swing.Timer(500, e -> verificarEstadoCaptcha());
        verificadorCaptcha.start();
    }
    
    // Método para verificar el estado del captcha
    private void verificarEstadoCaptcha() {
        try {
            // Buscar el JTextField dentro del captchaPanel2
            JTextField captchaField = encontrarCampoTextoEnCaptcha(captchaPanel2);
            
            if (captchaField != null) {
                String textoIngresado = captchaField.getText().trim();
                String textoCaptcha = captchaPanel2.getTexto_Captcha();
                
                if (!textoIngresado.isEmpty() && textoIngresado.equalsIgnoreCase(textoCaptcha)) {
                    if (!captchaResuelto) {
                        captchaResuelto = true;
                        habilitarBotonEntrar();
                    }
                } else {
                    if (captchaResuelto) {
                        captchaResuelto = false;
                        deshabilitarBotonEntrar();
                    }
                }
            }
        } catch (Exception ex) {
            // En caso de error, mantener el botón deshabilitado
            if (captchaResuelto) {
                captchaResuelto = false;
                deshabilitarBotonEntrar();
            }
        }
    }
    
    // Método recursivo para encontrar el JTextField en el captcha
    private JTextField encontrarCampoTextoEnCaptcha(Container container) {
        for (Component comp : container.getComponents()) {
            if (comp instanceof JTextField) {
                return (JTextField) comp;
            } else if (comp instanceof Container) {
                JTextField found = encontrarCampoTextoEnCaptcha((Container) comp);
                if (found != null) {
                    return found;
                }
            }
        }
        return null;
    }
    
    // Método para habilitar el botón entrar
    private void habilitarBotonEntrar() {
        btnEntrar.setEnabled(true);
        btnEntrar.setBackground(new Color(74, 144, 226));
        btnEntrar.setForeground(Color.WHITE);
        btnEntrar.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    
    // Método para deshabilitar el botón entrar
    private void deshabilitarBotonEntrar() {
        btnEntrar.setEnabled(false);
        actualizarEstiloBotonDeshabilitado();
    }
    
    // Método para actualizar el estilo del botón deshabilitado
    private void actualizarEstiloBotonDeshabilitado() {
        btnEntrar.setBackground(new Color(200, 200, 200));
        btnEntrar.setForeground(new Color(120, 120, 120));
        btnEntrar.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    
    // Método para detectar el tipo de usuario basado en el correo
    private String detectarTipoUsuario(String email) {
        if (email.equals("admin@sanarte.com")) {
            return "Admin";
        } else if (email.equals("doctor@sanarte.com")) {
            return "Doctor";
        } else if (esEmailValido(email)) {
            return "Paciente";
        }
        return "";
    }
    
    // Método para validar credenciales según el tipo de usuario detectado
    private boolean validarCredenciales(String email, String contraseña, String tipoUsuario) {
        switch (tipoUsuario) {
            case "Doctor":
                return email.equals("doctor@sanarte.com") && contraseña.equals("med123");
            case "Admin":
                return email.equals("admin@sanarte.com") && contraseña.equals("admin123");
            case "Paciente":
                return esEmailValido(email) && !contraseña.isEmpty();
            default:
                return false;
        }
    }
    
    // Método para limpiar campos iniciales
    private void limpiarCamposIniciales() {
        txtCorreo.setText("");
        txtClave.setText("");
        lblError.setText("");
    }
    
    // Método para validar formato de correo electrónico
    private boolean esEmailValido(String email) {
        return emailPattern.matcher(email).matches();
    }
    
    /**
     * Genera un ID único para el paciente basado en su email
     * Ejemplo: juan.perez@email.com -> JP001
     */
    private String generarIdPaciente(String email) {
        try {
            // Extraer la parte local del email (antes del @)
            String parteLocal = email.substring(0, email.indexOf("@"));
            
            // Obtener las iniciales
            String[] partes = parteLocal.split("[._-]");
            StringBuilder iniciales = new StringBuilder();
            
            for (String parte : partes) {
                if (!parte.isEmpty()) {
                    iniciales.append(parte.substring(0, 1).toUpperCase());
                }
            }
            
            // Si no hay suficientes iniciales, usar las primeras 2 letras
            if (iniciales.length() < 2) {
                String nombreLimpio = parteLocal.replaceAll("[._-]", "");
                if (nombreLimpio.length() >= 2) {
                    iniciales = new StringBuilder(nombreLimpio.substring(0, 2).toUpperCase());
                } else {
                    iniciales = new StringBuilder(nombreLimpio.toUpperCase() + "X");
                }
            }
            
            // Generar número secuencial basado en el hash del email
            int numeroSecuencial = Math.abs(email.hashCode() % 999) + 1;
            
            // Formatear el ID: iniciales + número de 3 dígitos
            return String.format("%s%03d", iniciales.toString(), numeroSecuencial);
            
        } catch (Exception e) {
            // En caso de error, generar un ID genérico
            return "PAC" + String.format("%03d", Math.abs(email.hashCode() % 999) + 1);
        }
    }
    
    /**
     * Extrae un nombre legible del correo electrónico
     * Ejemplo: juan.perez@email.com -> Juan Pérez
     */
    private String extraerNombreDeEmail(String email) {
        try {
            String parteLocal = email.substring(0, email.indexOf("@"));
            String nombreLimpio = parteLocal.replace(".", " ").replace("_", " ").replace("-", " ");
            String[] palabras = nombreLimpio.split(" ");
            StringBuilder nombreFormateado = new StringBuilder();
            
            for (String palabra : palabras) {
                if (!palabra.isEmpty()) {
                    if (nombreFormateado.length() > 0) {
                        nombreFormateado.append(" ");
                    }
                    nombreFormateado.append(palabra.substring(0, 1).toUpperCase())
                                   .append(palabra.substring(1).toLowerCase());
                }
            }
            return nombreFormateado.toString();
        } catch (Exception e) {
            return "Usuario Paciente";
        }
    }
    
    // Panel personalizado con gradiente azul
    class PanelGradiente extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            
            // Crear gradiente azul
            GradientPaint gradient = new GradientPaint(
                0, 0, new Color(74, 144, 226),
                0, getHeight(), new Color(56, 103, 214)
            );
            g2d.setPaint(gradient);
            g2d.fillRect(0, 0, getWidth(), getHeight());
        }
    }
    
    private void personalizarComponentes() {
        // Configurar el panel principal
        getContentPane().setBackground(new Color(248, 249, 250));
        
        // Personalizar panel izquierdo con gradiente
        configurarPanelIzquierdo();
        
        // Personalizar panel derecho
        jPanelDerecho.setBackground(Color.WHITE);
        
        // Personalizar título principal
        lblTituloPrincipal.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTituloPrincipal.setForeground(new Color(33, 37, 41));
        
        // Personalizar subtítulo
        lblSubtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSubtitulo.setForeground(new Color(108, 117, 125));
        
        // Personalizar etiquetas
        lblCorreo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblCorreo.setForeground(new Color(33, 37, 41));
        
        lblClave.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblClave.setForeground(new Color(33, 37, 41));
        
        // Personalizar campos de texto
        personalizarCampoTexto(txtCorreo);
        personalizarCampoPassword(txtClave);
        
        // Personalizar botones
        personalizarBotonPrincipal(btnEntrar, new Color(74, 144, 226));
        personalizarBotonSecundario(btnUtilidad);
        personalizarBotonPeligro(btnSalir);
        
        // Personalizar mensaje de error
        lblError.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblError.setForeground(new Color(220, 53, 69));
    }
    
    private void configurarPanelIzquierdo() {
        // Crear panel con gradiente
        PanelGradiente panelGradiente = new PanelGradiente();
        panelGradiente.setBounds(0, 0, 400, 600);
        panelGradiente.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        
        // Configurar componentes del panel izquierdo con posiciones específicas
        lblCorazon.setFont(new Font("Segoe UI", Font.PLAIN, 40));
        lblCorazon.setForeground(Color.WHITE);
        lblCorazon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCorazon.setOpaque(true);
        lblCorazon.setBackground(new Color(255, 255, 255, 50));
        lblCorazon.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        lblTituloSanArte.setFont(new Font("Segoe UI", Font.BOLD, 36));
        lblTituloSanArte.setForeground(Color.WHITE);
        lblTituloSanArte.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        
        lblSloganIzquierdo.setFont(new Font("Segoe UI", Font.ITALIC, 16));
        lblSloganIzquierdo.setForeground(new Color(255, 255, 255, 200));
        lblSloganIzquierdo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        
        lblSistemaGestion.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSistemaGestion.setForeground(new Color(255, 255, 255, 180));
        lblSistemaGestion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        
        lblDoctores.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblDoctores.setForeground(Color.WHITE);
        lblDoctores.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        
        lblPacientesIzq.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblPacientesIzq.setForeground(Color.WHITE);
        lblPacientesIzq.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        
        // Agregar componentes al panel gradiente con coordenadas específicas
        panelGradiente.add(lblCorazon, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 100, 60));
        panelGradiente.add(lblTituloSanArte, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, 300, 50));
        panelGradiente.add(lblSloganIzquierdo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 340, 60));
        panelGradiente.add(lblSistemaGestion, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, 300, 30));
        panelGradiente.add(lblDoctores, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 450, 120, 30));
        panelGradiente.add(lblPacientesIzq, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 450, 120, 30));
        
        // Limpiar y agregar el panel gradiente
        jPanelIzquierdo.removeAll();
        jPanelIzquierdo.setLayout(new java.awt.BorderLayout());
        jPanelIzquierdo.add(panelGradiente, java.awt.BorderLayout.CENTER);
        jPanelIzquierdo.revalidate();
        jPanelIzquierdo.repaint();
    }
    
    private void personalizarCampoTexto(javax.swing.JTextField campo) {
        campo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        campo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(206, 212, 218), 1),
            BorderFactory.createEmptyBorder(12, 16, 12, 16)
        ));
        campo.setBackground(Color.WHITE);
        campo.setForeground(new Color(33, 37, 41));
    }
    
    private void personalizarCampoPassword(javax.swing.JPasswordField campo) {
        campo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        campo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(206, 212, 218), 1),
            BorderFactory.createEmptyBorder(12, 16, 12, 16)
        ));
        campo.setBackground(Color.WHITE);
        campo.setForeground(new Color(33, 37, 41));
    }
    
    private void personalizarBotonPrincipal(javax.swing.JButton boton, Color color) {
        boton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        
        // Efecto hover solo si está habilitado
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (boton.isEnabled()) {
                    boton.setBackground(color.darker());
                }
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                if (boton.isEnabled()) {
                    boton.setBackground(color);
                }
            }
        });
    }
    
    private void personalizarBotonSecundario(javax.swing.JButton boton) {
        boton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        boton.setBackground(new Color(248, 249, 250));
        boton.setForeground(new Color(73, 80, 87));
        boton.setFocusPainted(false);
        boton.setBorderPainted(true);
        boton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(206, 212, 218), 1),
            BorderFactory.createEmptyBorder(11, 23, 11, 23)
        ));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Efecto hover
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(new Color(233, 236, 239));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(new Color(248, 249, 250));
            }
        });
    }
    
    private void personalizarBotonPeligro(javax.swing.JButton boton) {
        Color color = new Color(220, 53, 69);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        
        // Efecto hover
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(color.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(color);
            }
        });
    }
    
    // Método para limpiar mensajes de error
    private void limpiarError() {
        lblError.setText("");
        restaurarBordesNormales();
    }
    
    // Método para restaurar bordes normales
    private void restaurarBordesNormales() {
        txtCorreo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(206, 212, 218), 1),
            BorderFactory.createEmptyBorder(12, 16, 12, 16)));
        
        txtClave.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(206, 212, 218), 1),
            BorderFactory.createEmptyBorder(12, 16, 12, 16)));
    }
    
    // Método para mostrar error en campo de texto
    private void mostrarErrorEnCampoTexto(javax.swing.JTextField campo) {
        campo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 53, 69), 2),
            BorderFactory.createEmptyBorder(12, 16, 12, 16)));
    }
    
    // Método para mostrar error en campo de contraseña
    private void mostrarErrorEnCampoPassword(javax.swing.JPasswordField campo) {
        campo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 53, 69), 2),
            BorderFactory.createEmptyBorder(12, 16, 12, 16)));
    }


   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroupTipo = new javax.swing.ButtonGroup();
        jPanelIzquierdo = new javax.swing.JPanel();
        lblCorazon = new javax.swing.JLabel();
        lblTituloSanArte = new javax.swing.JLabel();
        lblSloganIzquierdo = new javax.swing.JLabel();
        lblSistemaGestion = new javax.swing.JLabel();
        lblDoctores = new javax.swing.JLabel();
        lblPacientesIzq = new javax.swing.JLabel();
        jPanelDerecho = new javax.swing.JPanel();
        lblTituloPrincipal = new javax.swing.JLabel();
        lblSubtitulo = new javax.swing.JLabel();
        lblCorreo = new javax.swing.JLabel();
        txtCorreo = new javax.swing.JTextField();
        lblClave = new javax.swing.JLabel();
        txtClave = new javax.swing.JPasswordField();
        lblError = new javax.swing.JLabel();
        btnEntrar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        btnUtilidad = new javax.swing.JButton();
        captchaPanel2 = new Captcha_Componentes.CaptchaPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema SanArte");
        setBackground(new java.awt.Color(255, 255, 255));
        setBounds(new java.awt.Rectangle(0, 0, 400, 600));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanelIzquierdo.setBackground(new java.awt.Color(74, 144, 226));
        jPanelIzquierdo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblCorazon.setBackground(new java.awt.Color(74, 144, 226));
        lblCorazon.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        lblCorazon.setForeground(new java.awt.Color(74, 144, 226));
        lblCorazon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCorazon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/corazon----r.png"))); // NOI18N
        lblCorazon.setOpaque(true);
        jPanelIzquierdo.add(lblCorazon, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 150, 70));

        lblTituloSanArte.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        lblTituloSanArte.setForeground(new java.awt.Color(255, 255, 255));
        lblTituloSanArte.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTituloSanArte.setText("SanArte");
        jPanelIzquierdo.add(lblTituloSanArte, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 300, 50));

        lblSloganIzquierdo.setBackground(new java.awt.Color(255, 255, 255));
        lblSloganIzquierdo.setFont(new java.awt.Font("Segoe UI", 2, 16)); // NOI18N
        lblSloganIzquierdo.setText("La salud que mereces, con el cuidado que necesitas");
        jPanelIzquierdo.add(lblSloganIzquierdo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 340, 60));

        lblSistemaGestion.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lblSistemaGestion.setForeground(new java.awt.Color(255, 255, 255));
        lblSistemaGestion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSistemaGestion.setText("⚕ Sistema de Gestión Médica");
        jPanelIzquierdo.add(lblSistemaGestion, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, 300, 30));

        lblDoctores.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lblDoctores.setForeground(new java.awt.Color(255, 255, 255));
        lblDoctores.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblDoctores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/simbolo-de-la-medicina.png"))); // NOI18N
        lblDoctores.setText(" Doctores");
        jPanelIzquierdo.add(lblDoctores, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 190, 100));

        lblPacientesIzq.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        lblPacientesIzq.setForeground(new java.awt.Color(255, 255, 255));
        lblPacientesIzq.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblPacientesIzq.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Clientes.png"))); // NOI18N
        lblPacientesIzq.setText("Pacientes");
        jPanelIzquierdo.add(lblPacientesIzq, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 420, 150, 100));

        getContentPane().add(jPanelIzquierdo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 390, 570));

        jPanelDerecho.setForeground(new java.awt.Color(255, 255, 255));
        jPanelDerecho.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTituloPrincipal.setFont(new java.awt.Font("Arial", 1, 25)); // NOI18N
        lblTituloPrincipal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTituloPrincipal.setText("Entrada de Usuario");
        jPanelDerecho.add(lblTituloPrincipal, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 290, 40));

        lblSubtitulo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblSubtitulo.setForeground(new java.awt.Color(108, 117, 125));
        lblSubtitulo.setText("Accede a tu cuenta del sistema médico");
        jPanelDerecho.add(lblSubtitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 360, 20));

        lblCorreo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCorreo.setForeground(new java.awt.Color(33, 37, 41));
        lblCorreo.setText("Correo Electrónico");
        jPanelDerecho.add(lblCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 360, 20));

        txtCorreo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txtCorreo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(206, 212, 218)));
        txtCorreo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCorreoKeyPressed(evt);
            }
        });
        jPanelDerecho.add(txtCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 360, 45));

        lblClave.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblClave.setForeground(new java.awt.Color(33, 37, 41));
        lblClave.setText("Clave de Acceso");
        jPanelDerecho.add(lblClave, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, 360, 20));

        txtClave.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtClave.setText("jPasswordField1");
        txtClave.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(206, 212, 218)));
        txtClave.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtClaveKeyPressed(evt);
            }
        });
        jPanelDerecho.add(txtClave, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 360, 45));

        lblError.setForeground(new java.awt.Color(220, 53, 69));
        lblError.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanelDerecho.add(lblError, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 360, 25));

        btnEntrar.setBackground(new java.awt.Color(74, 144, 226));
        btnEntrar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEntrar.setForeground(new java.awt.Color(255, 255, 255));
        btnEntrar.setText("Entrar");
        btnEntrar.setBorderPainted(false);
        btnEntrar.setFocusPainted(false);
        btnEntrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEntrarActionPerformed(evt);
            }
        });
        jPanelDerecho.add(btnEntrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 480, 100, 40));

        btnSalir.setBackground(new java.awt.Color(220, 53, 69));
        btnSalir.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnSalir.setForeground(new java.awt.Color(255, 255, 255));
        btnSalir.setText("Salir");
        btnSalir.setBorderPainted(false);
        btnSalir.setFocusPainted(false);
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        jPanelDerecho.add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 480, 100, 40));

        btnUtilidad.setBackground(new java.awt.Color(248, 249, 250));
        btnUtilidad.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnUtilidad.setForeground(new java.awt.Color(73, 80, 87));
        btnUtilidad.setText("Utilidad");
        btnUtilidad.setFocusPainted(false);
        btnUtilidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUtilidadActionPerformed(evt);
            }
        });
        jPanelDerecho.add(btnUtilidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 480, 100, 40));
        jPanelDerecho.add(captchaPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 340, 200, 110));

        getContentPane().add(jPanelDerecho, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 0, 400, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEntrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEntrarActionPerformed
           // Verificar primero si el captcha está resuelto
    if (!captchaResuelto) {
        lblError.setText("Debe completar el captcha correctamente");
        return;
    }
    
    // Obtener valores de los campos
    String email = txtCorreo.getText().trim();
    String contraseña = new String(txtClave.getPassword());
    
    // Validaciones básicas
    if (email.isEmpty() || contraseña.isEmpty()) {
        lblError.setText("Por favor, complete todos los campos");
        // Efecto visual de error
        if (email.isEmpty()) {
            mostrarErrorEnCampoTexto(txtCorreo);
        }
        if (contraseña.isEmpty()) {
            mostrarErrorEnCampoPassword(txtClave);
        }
        return;
    }
    
    // Validar formato de correo electrónico OBLIGATORIO para todos
    if (!esEmailValido(email)) {
        lblError.setText("Por favor, ingrese un correo electrónico válido");
        mostrarErrorEnCampoTexto(txtCorreo);
        return;
    }
    
    // Detectar tipo de usuario automáticamente basado en el correo
    String tipoUsuario = detectarTipoUsuario(email);
    
    if (tipoUsuario.isEmpty()) {
        lblError.setText("Correo electrónico no reconocido");
        mostrarErrorEnCampoTexto(txtCorreo);
        return;
    }
    
    // Limpiar errores visuales si llegamos aquí
    limpiarError();
    
    // Validar credenciales según el tipo de usuario detectado
    boolean accesoConcedido = validarCredenciales(email, contraseña, tipoUsuario);
    
    if (!accesoConcedido) {
        lblError.setText("Credenciales incorrectas para " + tipoUsuario);
        mostrarErrorEnCampoTexto(txtCorreo);
        mostrarErrorEnCampoPassword(txtClave);
        return;
    }
    
    // Si llegamos aquí, el acceso fue concedido
    JOptionPane.showMessageDialog(this,
        "¡Bienvenido/a al Sistema SanArte!\n\n" +
        "Usuario: " + email + "\n" +
        "Tipo: " + tipoUsuario + "\n\n" +
        "Acceso concedido exitosamente.",
        "Acceso Concedido",
        JOptionPane.INFORMATION_MESSAGE);
    
    // Abrir la ventana correspondiente según el tipo de usuario
    if (tipoUsuario.equals("Admin")) {
        this.dispose();
        try {
            new Administrador().setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error al abrir la ventana de Administrador: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
            System.err.println("Error al abrir Administrador: " + e.getMessage());
            e.printStackTrace();
            this.setVisible(true); // Restaurar ventana actual si hay error
        }
    } else if (tipoUsuario.equals("Doctor")) {
        JOptionPane.showMessageDialog(this,
            "Redirigiendo a la ventana de Doctor...",
            "Información", JOptionPane.INFORMATION_MESSAGE);
        // Aquí puedes agregar: new Doctor().setVisible(true); cuando tengas la clase
    } else if (tipoUsuario.equals("Paciente")) {
    this.dispose();
    try {
        String nombreCompleto = extraerNombreDeEmail(email);
        String idPaciente = generarIdPaciente(email);  // ← CORRECTO
        new Paciente(nombreCompleto, email, idPaciente ).setVisible(true);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
            "Error al abrir la ventana de Paciente: " + e.getMessage(),
            "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
        this.setVisible(true);
    }
    }
    }//GEN-LAST:event_btnEntrarActionPerformed


    private void btnUtilidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUtilidadActionPerformed
      String email = txtCorreo.getText().trim();
        String contraseña = new String(txtClave.getPassword());
        
        // Validar que los campos no estén vacíos
        if (email.isEmpty() || contraseña.isEmpty()) {
            lblError.setText("Debe ingresar correo y contraseña para acceder a Utilidad");
            if (email.isEmpty()) {
                mostrarErrorEnCampoTexto(txtCorreo);
            }
            if (contraseña.isEmpty()) {
                mostrarErrorEnCampoPassword(txtClave);
            }
            return;
        }
        
        // Validar formato de correo OBLIGATORIO
        if (!esEmailValido(email)) {
            lblError.setText("Por favor, ingrese un correo electrónico válido");
            mostrarErrorEnCampoTexto(txtCorreo);
            return;
        }
        
        // Verificar que sea administrador
        if (!email.equals("admin@sanarte.com")) {
            JOptionPane.showMessageDialog(this,
                "Esta funcionalidad solo está disponible para administradores.\n\n" +
                "Por favor ingrese las credenciales de administrador.",
                "Acceso Restringido", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Verificar credenciales específicas del administrador
        if (email.equals("admin@sanarte.com") && contraseña.equals("admin123")) {
            // Verificar captcha
            if (!captchaResuelto) {
                lblError.setText("Debe completar el captcha correctamente");
                return;
            }
            
            limpiarError();
            JOptionPane.showMessageDialog(this,
                "¡Acceso a Sistema concedido!\n\n" +
                "Administrador: " + email + "\n" +
                "Redirigiendo al sistema de utilidades...",
                "Acceso a Sistema", JOptionPane.INFORMATION_MESSAGE);
            
            this.dispose();
            try {
                new Sistema().setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "Error al abrir la ventana del Sistema: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
                System.err.println("Error al abrir Sistema: " + e.getMessage());
                e.printStackTrace();
                this.setVisible(true); // Restaurar ventana actual si hay error
            }
        } else {
            lblError.setText("Credenciales incorrectas para acceder al Sistema de Utilidad");
            mostrarErrorEnCampoPassword(txtClave);
            mostrarErrorEnCampoTexto(txtCorreo);
        }
    }//GEN-LAST:event_btnUtilidadActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed

      int opcion = JOptionPane.showConfirmDialog(this,
            "¿Está seguro que desea salir del Sistema SanArte?",
            "Confirmar Salida", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        
        if (opcion == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_btnSalirActionPerformed

    private void txtCorreoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCorreoKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            txtClave.requestFocus();
        }
        limpiarError();
    }//GEN-LAST:event_txtCorreoKeyPressed
    

    
    private void txtClaveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtClaveKeyPressed
    if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            if (btnEntrar.isEnabled()) {
                btnEntrarActionPerformed(null);
            } else {
                lblError.setText("Debe completar el captcha correctamente");
            }
        }
        limpiarError();
    }//GEN-LAST:event_txtClaveKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    /* Set the Nimbus look and feel */
    try {
        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("Nimbus".equals(info.getName())) {
                javax.swing.UIManager.setLookAndFeel(info.getClassName());
                break;
            }
        }
    } catch (ClassNotFoundException ex) {
        java.util.logging.Logger.getLogger(Acces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (InstantiationException ex) {
        java.util.logging.Logger.getLogger(Acces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (IllegalAccessException ex) {
        java.util.logging.Logger.getLogger(Acces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (javax.swing.UnsupportedLookAndFeelException ex) {
        java.util.logging.Logger.getLogger(Acces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }

    /* Create and display the form */
    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            try {
                new Acces().setVisible(true);
            } catch (Exception e) {
                System.err.println("Error al crear la ventana Acces: " + e.getMessage());
                e.printStackTrace();
                
                javax.swing.JOptionPane.showMessageDialog(null,
                    "Error crítico al iniciar la aplicación.\n" +
                    "Por favor, contacte al administrador del sistema.\n\n" +
                    "Error: " + e.getMessage(),
                    "Error de Aplicación",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
                
                System.exit(1);
            }
        }
    });
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEntrar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnUtilidad;
    private javax.swing.ButtonGroup buttonGroupTipo;
    private Captcha_Componentes.CaptchaPanel captchaPanel2;
    private javax.swing.JPanel jPanelDerecho;
    private javax.swing.JPanel jPanelIzquierdo;
    private javax.swing.JLabel lblClave;
    private javax.swing.JLabel lblCorazon;
    private javax.swing.JLabel lblCorreo;
    private javax.swing.JLabel lblDoctores;
    private javax.swing.JLabel lblError;
    private javax.swing.JLabel lblPacientesIzq;
    private javax.swing.JLabel lblSistemaGestion;
    private javax.swing.JLabel lblSloganIzquierdo;
    private javax.swing.JLabel lblSubtitulo;
    private javax.swing.JLabel lblTituloPrincipal;
    private javax.swing.JLabel lblTituloSanArte;
    private javax.swing.JPasswordField txtClave;
    private javax.swing.JTextField txtCorreo;
    // End of variables declaration//GEN-END:variables
}
