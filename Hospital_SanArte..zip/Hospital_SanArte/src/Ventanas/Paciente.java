/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Ventanas;
import elementos.Correo;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableCellEditor;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.MessagingException;


/**
 *
 * @author socta
 */
public class Paciente extends javax.swing.JFrame {
 // Variables de instancia para datos del paciente
    private String nombrePaciente;
    private String correoPaciente;
    private String idPaciente; // ← CAMBIO: de int a String
    
    // CardLayout para navegación entre secciones
    private CardLayout cardLayout;
    
    /**
     * Constructor por defecto para el diseñador visual de NetBeans
     */
    public Paciente() {
        this("Juan Pérez", "juan.perez@email.com", "JP001"); // ← CAMBIO: String en lugar de int
    }
    
    /**
     * Constructor con parámetros del paciente logueado
     * CAMBIO: Ahora acepta String para el ID
     */
    public Paciente(String nombre, String correo, String id) { // ← CAMBIO: int id → String id
        this.nombrePaciente = nombre;
        this.correoPaciente = correo;
        this.idPaciente = id; // ← CAMBIO: Ahora es String
        
        initComponents();
        configurarVentanaInicial();
        configurarEventosPersonalizados();
        mostrarSeccion("historial"); // Mostrar historial por defecto
    }
    
    /**
     * Configuración inicial de la ventana después de initComponents()
     */
    private void configurarVentanaInicial() {
        // Centrar ventana en pantalla
        setLocationRelativeTo(null);
        
        // Configurar CardLayout para el panel de contenido
        cardLayout = new CardLayout();
        panelContenido.setLayout(cardLayout);
        
        // Añadir todos los paneles al CardLayout
        panelContenido.add(panelHistorial, "historial");
        panelContenido.add(panelCitas, "citas");
        panelContenido.add(panelNuevaCita, "nuevaCita");
        panelContenido.add(panelAgendaDisponible, "agenda");
        panelContenido.add(panelMensajes, "mensajes");
        
        // Configurar información del paciente en el panel lateral
        // ← CAMBIO: Mostrar el ID del paciente también
        lblNombrePaciente.setText("<html><center>" + nombrePaciente + 
                                 "<br><small>" + correoPaciente + "</small>" +
                                 "<br><small>ID: " + idPaciente + "</small></center></html>");
        
        // Configurar título inicial
        lblTitulo.setText("Mi Historial Médico");
        
        // Resaltar botón activo inicial

        
        // Cargar datos de ejemplo en todas las secciones
        cargarDatosHistorialMedico();
        cargarDatosCitasProgramadas();
        cargarDatosAgendaDisponible();
        cargarMensajesNotificaciones();
        configurarFormularioNuevaCita();
    }
    
    /**
     * Configurar eventos adicionales y efectos visuales
     */
    private void configurarEventosPersonalizados() {
        // Efectos hover para todos los botones del menú lateral
    
        configurarEfectoHover(btnCitasProgramadas);
        configurarEfectoHover(btnAgendarCita);
        configurarEfectoHover(btnAgendaDisponible);
        configurarEfectoHover(btnCerrarSesion);
        
        // Configurar eventos de botones de acción
        btnAgendar.addActionListener(e -> procesarAgendarCita());
        btnFiltrar.addActionListener(e -> aplicarFiltrosAgenda());
        
        // Configurar evento de doble clic en mensajes
        listaMensajes.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    mostrarDetallesMensaje();
                }
            }
        });
    }
    
    /**
     * Configurar efecto hover para botones del menú lateral
     */
    private void configurarEfectoHover(JButton boton) {
        Color colorNormal = new Color(63, 61, 163);
        Color colorHover = new Color(83, 81, 183);
        Color colorActivo = new Color(103, 101, 203);
        
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (!boton.getBackground().equals(colorActivo)) {
                    boton.setBackground(colorHover);
                }
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                if (!boton.getBackground().equals(colorActivo)) {
                    boton.setBackground(colorNormal);
                }
            }
        });
    }
    
    /**
     * MÉTODO PRINCIPAL - Cambiar entre secciones del portal
     * Este método controla toda la navegación de la aplicación
     */
    private void mostrarSeccion(String seccion) {
        // Cambiar el panel visible usando CardLayout
        cardLayout.show(panelContenido, seccion);
        
        // Cambiar título y resaltar botón según la sección
        switch (seccion) {
     
                
            case "citas":
                lblTitulo.setText("Mis Citas Programadas");
                resaltarBotonActivo(btnCitasProgramadas);
                break;
                
            case "nuevaCita":
                lblTitulo.setText("Agendar Nueva Cita");
                resaltarBotonActivo(btnAgendarCita);
                break;
                
            case "agenda":
                lblTitulo.setText("Agenda Disponible");
                resaltarBotonActivo(btnAgendaDisponible);
                break;
                
            
        }
        
        // Actualizar la interfaz
        panelContenido.revalidate();
        panelContenido.repaint();
    }
    
    /**
     * Resaltar visualmente el botón activo en el menú lateral
     */
    private void resaltarBotonActivo(JButton botonActivo) {
        Color colorNormal = new Color(63, 61, 163);
        Color colorActivo = new Color(103, 101, 203);
        
        // Resetear todos los botones al color normal

        btnCitasProgramadas.setBackground(colorNormal);
        btnAgendarCita.setBackground(colorNormal);
        btnAgendaDisponible.setBackground(colorNormal);

        btnCerrarSesion.setBackground(colorNormal);
        
        // Resaltar el botón activo
        botonActivo.setBackground(colorActivo);
    }
    
    /**
     * Cargar datos del historial médico del paciente
     */
    private void cargarDatosHistorialMedico() {
        String[] columnas = {"FECHA", "DOCTOR", "DIAGNÓSTICO", "TRATAMIENTO", "RECETA"};
        
        // Datos de ejemplo - Aquí conectarías con PostgreSQL
        Object[][] datos = {
            {"2024-03-15", "Dr. Carlos Rodriguez", "Gripe común", "Paracetamol", "Paracetamol 500mg cada 8 horas"},
            {"2024-02-20", "Dra. Ana López", "Control rutinario", "Ninguno", "N/A"},
            {"2024-01-10", "Dr. Juan Pérez", "Hipertensión", "Enalapril", "Enalapril 10mg una vez al día"},
            {"2023-12-05", "Dra. María García", "Diabetes tipo 2", "Metformina", "Metformina 850mg dos veces al día"},
            {"2023-11-18", "Dr. Carlos Rodriguez", "Bronquitis", "Amoxicilina", "Amoxicilina 875mg cada 12 horas por 7 días"}
        };
        
        DefaultTableModel modelo = new DefaultTableModel(datos, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Tabla de solo lectura
            }
        };
        
        tablaHistorial.setModel(modelo);
        tablaHistorial.setRowHeight(35);
        tablaHistorial.getTableHeader().setReorderingAllowed(false);
        tablaHistorial.getTableHeader().setBackground(new Color(240, 240, 240));
        tablaHistorial.setSelectionBackground(new Color(232, 240, 254));
        
        // Ajustar ancho de columnas
        tablaHistorial.getColumnModel().getColumn(0).setPreferredWidth(80);  // Fecha
        tablaHistorial.getColumnModel().getColumn(1).setPreferredWidth(120); // Doctor
        tablaHistorial.getColumnModel().getColumn(2).setPreferredWidth(150); // Diagnóstico
        tablaHistorial.getColumnModel().getColumn(3).setPreferredWidth(100); // Tratamiento
        tablaHistorial.getColumnModel().getColumn(4).setPreferredWidth(200); // Receta
    }
    
    /**
     * Cargar datos de citas programadas del paciente
     */
    private void cargarDatosCitasProgramadas() {
        String[] columnas = {"FECHA", "HORA", "DOCTOR", "ESPECIALIDAD", "ESTADO", "ACCIONES"};
        
        Object[][] datos = {
            {"2024-07-25", "10:00", "Dr. Carlos Rodriguez", "Medicina General", "Confirmada", ""},
            {"2024-08-10", "15:30", "Dra. Ana López", "Cardiología", "Pendiente", ""},
            {"2024-08-15", "09:00", "Dr. Juan Pérez", "Dermatología", "Confirmada", ""},
            {"2024-08-22", "11:30", "Dra. María García", "Endocrinología", "Pendiente", ""}
        };
        
        DefaultTableModel modelo = new DefaultTableModel(datos, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5; // Solo la columna de acciones es editable
            }
        };
        
        tablaCitas.setModel(modelo);
        tablaCitas.setRowHeight(40);
        tablaCitas.getTableHeader().setReorderingAllowed(false);
        tablaCitas.getTableHeader().setBackground(new Color(240, 240, 240));
        
        // Configurar botones en la columna de acciones
        tablaCitas.getColumnModel().getColumn(5).setCellRenderer(new ButtonRenderer("Cancelar", new Color(220, 53, 69)));
        tablaCitas.getColumnModel().getColumn(5).setCellEditor(new CancelarCitaEditor());
        
        // Ajustar ancho de columnas
        tablaCitas.getColumnModel().getColumn(0).setPreferredWidth(80);  // Fecha
        tablaCitas.getColumnModel().getColumn(1).setPreferredWidth(60);  // Hora
        tablaCitas.getColumnModel().getColumn(2).setPreferredWidth(120); // Doctor
        tablaCitas.getColumnModel().getColumn(3).setPreferredWidth(120); // Especialidad
        tablaCitas.getColumnModel().getColumn(4).setPreferredWidth(80);  // Estado
        tablaCitas.getColumnModel().getColumn(5).setPreferredWidth(100); // Acciones
    }
    
    /**
     * Cargar datos de agenda disponible para reservar citas
     */
    private void cargarDatosAgendaDisponible() {
        String[] columnas = {"FECHA", "HORA", "MÉDICO", "ESPECIALIDAD", "RESERVAR"};
        
        Object[][] datos = {
            {"2024-07-25", "09:00", "Dr. Carlos Rodriguez", "Medicina General", ""},
            {"2024-07-25", "09:30", "Dr. Carlos Rodriguez", "Medicina General", ""},
            {"2024-07-25", "10:00", "Dra. Ana López", "Cardiología", ""},
            {"2024-07-25", "10:30", "Dra. Ana López", "Cardiología", ""},
            {"2024-07-26", "15:00", "Dr. Juan Pérez", "Dermatología", ""},
            {"2024-07-26", "15:30", "Dr. Juan Pérez", "Dermatología", ""},
            {"2024-07-27", "08:30", "Dra. María García", "Endocrinología", ""},
            {"2024-07-27", "09:00", "Dra. María García", "Endocrinología", ""}
        };
        
        DefaultTableModel modelo = new DefaultTableModel(datos, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4; // Solo la columna de reservar es editable
            }
        };
        
        tablaAgenda.setModel(modelo);
        tablaAgenda.setRowHeight(35);
        tablaAgenda.getTableHeader().setReorderingAllowed(false);
        tablaAgenda.getTableHeader().setBackground(new Color(240, 240, 240));
        
        // Configurar botones en la columna de reservar
        tablaAgenda.getColumnModel().getColumn(4).setCellRenderer(new ButtonRenderer("Reservar", new Color(40, 167, 69)));
        tablaAgenda.getColumnModel().getColumn(4).setCellEditor(new ReservarCitaEditor());
        
        // Ajustar ancho de columnas
        tablaAgenda.getColumnModel().getColumn(0).setPreferredWidth(80);  // Fecha
        tablaAgenda.getColumnModel().getColumn(1).setPreferredWidth(60);  // Hora
        tablaAgenda.getColumnModel().getColumn(2).setPreferredWidth(120); // Médico
        tablaAgenda.getColumnModel().getColumn(3).setPreferredWidth(120); // Especialidad
        tablaAgenda.getColumnModel().getColumn(4).setPreferredWidth(100); // Reservar
    }
    
    /**
     * Cargar mensajes y notificaciones del paciente
     */
    private void cargarMensajesNotificaciones() {
        DefaultListModel<String> modelo = new DefaultListModel<>();
        modelo.addElement("🩺 Dr. Carlos Rodriguez: Recuerde tomar su medicación según lo indicado (2024-07-20)");
        modelo.addElement("📅 Sistema: Su cita ha sido confirmada para el 25 de julio a las 10:00 AM (2024-07-19)");
        modelo.addElement("📋 Dra. Ana López: Los resultados de sus análisis están listos para recoger (2024-07-15)");
        modelo.addElement("💊 Sistema: Es hora de renovar su receta de Enalapril (2024-07-10)");
        modelo.addElement("🔔 Recordatorio: Tiene una cita pendiente de confirmar para el 10 de agosto (2024-07-08)");
        modelo.addElement("📞 Recepción: Por favor confirme su asistencia a la cita del viernes (2024-07-05)");
        
        listaMensajes.setModel(modelo);
        listaMensajes.setCellRenderer(new MensajePersonalizadoRenderer());
        listaMensajes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }
    
    /**
     * Configurar formulario para agendar nueva cita
     */
    private void configurarFormularioNuevaCita() {
        // Configurar fecha actual por defecto
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        txtFecha.setText(sdf.format(new Date()));
        
        // Configurar fecha de filtro
        txtFiltroFecha.setText(sdf.format(new Date()));
    }
    
    /**
     * Procesar el agendamiento de una nueva cita
     */
    private void procesarAgendarCita() {
        String especialidad = (String) comboEspecialidad.getSelectedItem();
        String medico = (String) comboMedico.getSelectedItem();
        String fecha = txtFecha.getText().trim();
        String hora = (String) comboHora.getSelectedItem();
        String motivo = txtMotivo.getText().trim();
        
        // Validaciones del formulario
        if (fecha.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Por favor ingrese una fecha válida",
                "Error de Validación",
                JOptionPane.ERROR_MESSAGE);
            txtFecha.requestFocus();
            return;
        }
        
        if (motivo.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Por favor ingrese el motivo de la cita",
                "Error de Validación",
                JOptionPane.ERROR_MESSAGE);
            txtMotivo.requestFocus();
            return;
        }
        
        if (motivo.length() < 10) {
            JOptionPane.showMessageDialog(this,
                "El motivo debe tener al menos 10 caracteres",
                "Error de Validación",
                JOptionPane.ERROR_MESSAGE);
            txtMotivo.requestFocus();
            return;
        }
        
        // Mostrar confirmación detallada
        String mensaje = String.format(
            "¿Confirmar el agendamiento de la cita?\n\n" +
            "📋 Especialidad: %s\n" +
            "👨‍⚕️ Médico: %s\n" +
            "📅 Fecha: %s\n" +
            "🕐 Hora: %s\n" +
            "📝 Motivo: %s\n" +
            "👤 Paciente: %s (ID: %s)", // ← CAMBIO: Mostrar información del paciente
            especialidad, medico, fecha, hora, motivo, nombrePaciente, idPaciente
        );
        
        int opcion = JOptionPane.showConfirmDialog(
            this,
            mensaje,
            "Confirmar Nueva Cita",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (opcion == JOptionPane.YES_OPTION) {
            // Aquí guardarías en la base de datos PostgreSQL
            // insertarNuevaCita(idPaciente, especialidad, medico, fecha, hora, motivo);
            
            JOptionPane.showMessageDialog(this,
                "✅ Cita agendada correctamente\n\nRecibirá una confirmación por SMS",
                "Cita Agendada",
                JOptionPane.INFORMATION_MESSAGE);
            
            // Limpiar formulario después del éxito
            limpiarFormularioNuevaCita();
            
            // Actualizar datos de citas programadas
            cargarDatosCitasProgramadas();
            
            // Cambiar a la sección de citas programadas
            mostrarSeccion("citas");
        }
    }
    
    /**
     * Limpiar formulario de nueva cita
     */
    private void limpiarFormularioNuevaCita() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        txtFecha.setText(sdf.format(new Date()));
        txtMotivo.setText("");
        comboEspecialidad.setSelectedIndex(0);
        comboMedico.setSelectedIndex(0);
        comboHora.setSelectedIndex(0);
    }
    
    /**
     * Aplicar filtros a la agenda disponible
     */
    private void aplicarFiltrosAgenda() {
        String especialidadFiltro = (String) comboFiltroEspecialidad.getSelectedItem();
        String fechaFiltro = txtFiltroFecha.getText().trim();
        
        if (fechaFiltro.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Por favor ingrese una fecha para filtrar",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Aquí aplicarías el filtro real consultando la base de datos
        JOptionPane.showMessageDialog(this,
            String.format("🔍 Filtros aplicados:\n\n📋 Especialidad: %s\n📅 Fecha: %s\n\nMostrando resultados...",
                especialidadFiltro, fechaFiltro),
            "Filtros Aplicados",
            JOptionPane.INFORMATION_MESSAGE);
        
        // Recargar datos con filtros (aquí harías la consulta SQL filtrada)
        cargarDatosAgendaDisponible();
    }
    
    /**
     * Mostrar detalles de un mensaje seleccionado
     */
    private void mostrarDetallesMensaje() {
        String mensajeSeleccionado = listaMensajes.getSelectedValue();
        if (mensajeSeleccionado != null) {
            JOptionPane.showMessageDialog(this,
                mensajeSeleccionado,
                "Detalles del Mensaje",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    /**
     * Cerrar sesión del paciente
     */
    private void cerrarSesionPaciente() {
        int opcion = JOptionPane.showConfirmDialog(
            this,
            "¿Está seguro que desea cerrar sesión?\n\nSe perderán los datos no guardados.",
            "Cerrar Sesión",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (opcion == JOptionPane.YES_OPTION) {
            // Mostrar mensaje de despedida
            JOptionPane.showMessageDialog(this,
                String.format("👋 Hasta luego, %s\n\nGracias por usar SanArte", nombrePaciente),
                "Sesión Cerrada",
                JOptionPane.INFORMATION_MESSAGE);
            
            dispose(); // Cerrar esta ventana
            
            // Aquí normalmente abrirías la ventana de login
            try {
                new Acces().setVisible(true);
            } catch (Exception e) {
                System.err.println("Error al abrir ventana de acceso: " + e.getMessage());
                System.exit(0);
            }
        }
    }
    
    // ==================== CLASES AUXILIARES PARA TABLAS ====================
    
    /**
     * Renderer personalizado para botones en tablas
     */
    class ButtonRenderer extends JButton implements TableCellRenderer {
        private String texto;
        private Color colorFondo;
        
        public ButtonRenderer(String texto, Color colorFondo) {
            this.texto = texto;
            this.colorFondo = colorFondo;
            setOpaque(true);
            setFont(new Font("Arial", Font.BOLD, 12));
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            setText(texto);
            setBackground(colorFondo);
            setForeground(Color.WHITE);
            setBorder(BorderFactory.createRaisedBevelBorder());
            return this;
        }
    }
    
    /**
     * Editor para botones de cancelar citas
     */
    class CancelarCitaEditor extends DefaultCellEditor {
        protected JButton button;
        private boolean isPushed;
        private JTable tabla;
        
        public CancelarCitaEditor() {
            super(new JCheckBox());
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(e -> fireEditingStopped());
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            this.tabla = table;
            button.setText("Cancelar");
            button.setBackground(new Color(220, 53, 69));
            button.setForeground(Color.WHITE);
            button.setFont(new Font("Arial", Font.BOLD, 12));
            isPushed = true;
            return button;
        }
        
        @Override
        public Object getCellEditorValue() {
            if (isPushed) {
                int fila = tabla.getSelectedRow();
                String fecha = (String) tabla.getValueAt(fila, 0);
                String hora = (String) tabla.getValueAt(fila, 1);
                String doctor = (String) tabla.getValueAt(fila, 2);
                String especialidad = (String) tabla.getValueAt(fila, 3);
                
                String mensaje = String.format(
                    "¿Está seguro que desea cancelar esta cita?\n\n" +
                    "📅 Fecha: %s\n" +
                    "🕐 Hora: %s\n" +
                    "👨‍⚕️ Doctor: %s\n" +
                    "📋 Especialidad: %s\n\n" +
                    "⚠️ Esta acción no se puede deshacer",
                    fecha, hora, doctor, especialidad
                );
                
                int opcion = JOptionPane.showConfirmDialog(button,
                    mensaje,
                    "Cancelar Cita",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);
                
                if (opcion == JOptionPane.YES_OPTION) {
                    // Aquí eliminarías la cita de la base de datos
                    // eliminarCita(idPaciente, fecha, hora, doctor);
                    
                    JOptionPane.showMessageDialog(button,
                        "✅ Cita cancelada correctamente\n\nSe ha enviado una notificación al doctor",
                        "Cita Cancelada",
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    // Eliminar fila de la tabla
                    DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
                    modelo.removeRow(fila);
                }
            }
            isPushed = false;
            return "Cancelar";
        }
        
        @Override
        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }
    }
    
    /**
     * Editor para botones de reservar citas
     */
    class ReservarCitaEditor extends DefaultCellEditor {
        protected JButton button;
        private boolean isPushed;
        private JTable tabla;
        
        public ReservarCitaEditor() {
            super(new JCheckBox());
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(e -> fireEditingStopped());
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            this.tabla = table;
            button.setText("Reservar");
            button.setBackground(new Color(40, 167, 69));
            button.setForeground(Color.WHITE);
            button.setFont(new Font("Arial", Font.BOLD, 12));
            isPushed = true;
            return button;
        }
        
        @Override
        public Object getCellEditorValue() {
            if (isPushed) {
                int fila = tabla.getSelectedRow();
                String fecha = (String) tabla.getValueAt(fila, 0);
                String hora = (String) tabla.getValueAt(fila, 1);
                String medico = (String) tabla.getValueAt(fila, 2);
                String especialidad = (String) tabla.getValueAt(fila, 3);
                
                String mensaje = String.format(
                    "¿Desea reservar esta cita?\n\n" +
                    "📅 Fecha: %s\n" +
                    "🕐 Hora: %s\n" +
                    "👨‍⚕️ Médico: %s\n" +
                    "📋 Especialidad: %s\n\n" +
                    "✅ La cita será confirmada automáticamente",
                    fecha, hora, medico, especialidad
                );
                
                int opcion = JOptionPane.showConfirmDialog(button,
                    mensaje,
                    "Confirmar Reserva",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE);
                
                if (opcion == JOptionPane.YES_OPTION) {
                    // Aquí guardarías la nueva cita en la base de datos
                    // insertarCitaReservada(idPaciente, fecha, hora, medico, especialidad);
                    
                    JOptionPane.showMessageDialog(button,
                        "🎉 Cita reservada correctamente\n\nRecibirá una confirmación por SMS",
                        "Reserva Exitosa",
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    // Actualizar datos de citas programadas
                    cargarDatosCitasProgramadas();
                    
                    // Eliminar la fila de agenda disponible
                    DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
                    modelo.removeRow(fila);
                }
            }
            isPushed = false;
            return "Reservar";
        }
        
        @Override
        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }
    }
    
    /**
     * Renderer personalizado para la lista de mensajes
     */
    class MensajePersonalizadoRenderer extends JPanel implements ListCellRenderer<String> {
        private JLabel lblMensaje = new JLabel();
        private JLabel lblFecha = new JLabel();
        
        public MensajePersonalizadoRenderer() {
            setLayout(new BorderLayout());
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
            ));
            
            lblMensaje.setFont(new Font("Arial", Font.PLAIN, 14));
            lblFecha.setFont(new Font("Arial", Font.ITALIC, 11));
            lblFecha.setForeground(new Color(128, 128, 128));
            
            add(lblMensaje, BorderLayout.CENTER);
            add(lblFecha, BorderLayout.EAST);
        }
        
        @Override
        public Component getListCellRendererComponent(JList<? extends String> list, String value, int index,
                boolean isSelected, boolean cellHasFocus) {
            
            // Extraer fecha del mensaje (texto entre paréntesis al final)
            String mensaje = value;
            String fecha = "";
            
            int posParentesis = value.lastIndexOf("(");
            if (posParentesis > 0) {
                mensaje = value.substring(0, posParentesis).trim();
                fecha = value.substring(posParentesis + 1, value.length() - 1);
            }
            
            lblMensaje.setText("<html>" + mensaje + "</html>");
            lblFecha.setText(fecha);
            
            // Colores de selección
            if (isSelected) {
                setBackground(new Color(232, 240, 254));
                lblMensaje.setForeground(new Color(25, 25, 25));
            } else {
                setBackground(Color.WHITE);
                lblMensaje.setForeground(new Color(50, 50, 50));
            }
            
            return this;
        }
    }

    
 


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        panelLateral = new javax.swing.JPanel();
        panelUsuario = new javax.swing.JPanel();
        lblLogo = new javax.swing.JLabel();
        lblNombrePaciente = new javax.swing.JLabel();
        btnCitasProgramadas = new javax.swing.JButton();
        btnAgendarCita = new javax.swing.JButton();
        btnAgendaDisponible = new javax.swing.JButton();
        btnCerrarSesion = new javax.swing.JButton();
        panelPrincipal = new javax.swing.JPanel();
        panelTitulo = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        panelContenido = new javax.swing.JPanel();
        panelHistorial = new javax.swing.JPanel();
        scrollPaneHistorial = new javax.swing.JScrollPane();
        tablaHistorial = new javax.swing.JTable();
        panelCitas = new javax.swing.JPanel();
        scrollPaneCitas = new javax.swing.JScrollPane();
        tablaCitas = new javax.swing.JTable();
        panelNuevaCita = new javax.swing.JPanel();
        panelFormulario = new javax.swing.JPanel();
        lblEspecialidad = new javax.swing.JLabel();
        comboEspecialidad = new javax.swing.JComboBox<>();
        lblMedico = new javax.swing.JLabel();
        comboMedico = new javax.swing.JComboBox<>();
        lblFecha = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        lblHora = new javax.swing.JLabel();
        comboHora = new javax.swing.JComboBox<>();
        lblMotivo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtMotivo = new java.awt.TextArea();
        btnAgendar = new javax.swing.JButton();
        panelAgendaDisponible = new javax.swing.JPanel();
        panelFiltros = new javax.swing.JPanel();
        lblFiltroEspecialidad = new javax.swing.JLabel();
        comboFiltroEspecialidad = new javax.swing.JComboBox<>();
        lblFiltroFecha = new javax.swing.JLabel();
        txtFiltroFecha = new javax.swing.JTextField();
        btnFiltrar = new javax.swing.JButton();
        scrollPaneAgenda = new javax.swing.JScrollPane();
        tablaAgenda = new javax.swing.JTable();
        panelMensajes = new javax.swing.JPanel();
        scrollPaneMensajes = new javax.swing.JScrollPane();
        listaMensajes = new javax.swing.JList<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("SanArte - Portal del Paciente");
        setMinimumSize(new java.awt.Dimension(1000, 700));
        setPreferredSize(new java.awt.Dimension(1000, 700));
        setSize(new java.awt.Dimension(1200, 800));

        panelLateral.setBackground(new java.awt.Color(63, 61, 163));
        panelLateral.setPreferredSize(new java.awt.Dimension(250, 100));
        panelLateral.setLayout(new javax.swing.BoxLayout(panelLateral, javax.swing.BoxLayout.Y_AXIS));

        panelUsuario.setBackground(new java.awt.Color(63, 61, 163));
        panelUsuario.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 10, 20, 10));

        lblLogo.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        lblLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblLogo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLogo.setText("🏥 SanArte");
        panelUsuario.add(lblLogo);

        lblNombrePaciente.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblNombrePaciente.setForeground(new java.awt.Color(255, 255, 255));
        lblNombrePaciente.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNombrePaciente.setText("<html><center>Juan Pérez<br><small>juan.perez@email.com</small></center></html>");
        panelUsuario.add(lblNombrePaciente);

        panelLateral.add(panelUsuario);

        btnCitasProgramadas.setBackground(new java.awt.Color(63, 61, 163));
        btnCitasProgramadas.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnCitasProgramadas.setForeground(new java.awt.Color(255, 255, 255));
        btnCitasProgramadas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Libro_historial_--.png"))); // NOI18N
        btnCitasProgramadas.setText(" Mis Citas Programadas");
        btnCitasProgramadas.setBorderPainted(false);
        btnCitasProgramadas.setFocusPainted(false);
        btnCitasProgramadas.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnCitasProgramadas.setMaximumSize(new java.awt.Dimension(220, 50));
        btnCitasProgramadas.setMinimumSize(new java.awt.Dimension(220, 70));
        btnCitasProgramadas.setPreferredSize(new java.awt.Dimension(220, 40));
        btnCitasProgramadas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCitasProgramadasActionPerformed(evt);
            }
        });
        panelLateral.add(btnCitasProgramadas);

        btnAgendarCita.setBackground(new java.awt.Color(63, 61, 163));
        btnAgendarCita.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnAgendarCita.setForeground(new java.awt.Color(255, 255, 255));
        btnAgendarCita.setText("🏥 Agendar Nueva Cita");
        btnAgendarCita.setBorderPainted(false);
        btnAgendarCita.setFocusPainted(false);
        btnAgendarCita.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAgendarCita.setMaximumSize(new java.awt.Dimension(220, 50));
        btnAgendarCita.setMinimumSize(new java.awt.Dimension(220, 70));
        btnAgendarCita.setPreferredSize(new java.awt.Dimension(220, 40));
        btnAgendarCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgendarCitaActionPerformed(evt);
            }
        });
        panelLateral.add(btnAgendarCita);

        btnAgendaDisponible.setBackground(new java.awt.Color(63, 61, 163));
        btnAgendaDisponible.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnAgendaDisponible.setForeground(new java.awt.Color(255, 255, 255));
        btnAgendaDisponible.setText("📅 Agenda Disponible");
        btnAgendaDisponible.setFocusPainted(false);
        btnAgendaDisponible.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAgendaDisponible.setMinimumSize(new java.awt.Dimension(220, 70));
        btnAgendaDisponible.setPreferredSize(new java.awt.Dimension(220, 40));
        btnAgendaDisponible.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgendaDisponibleActionPerformed(evt);
            }
        });
        panelLateral.add(btnAgendaDisponible);

        btnCerrarSesion.setBackground(new java.awt.Color(63, 61, 163));
        btnCerrarSesion.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnCerrarSesion.setForeground(new java.awt.Color(255, 255, 255));
        btnCerrarSesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/eliminar.png"))); // NOI18N
        btnCerrarSesion.setText("Cerrar Sesión");
        btnCerrarSesion.setBorderPainted(false);
        btnCerrarSesion.setFocusPainted(false);
        btnCerrarSesion.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnCerrarSesion.setMaximumSize(new java.awt.Dimension(220, 50));
        btnCerrarSesion.setMinimumSize(new java.awt.Dimension(220, 70));
        btnCerrarSesion.setPreferredSize(new java.awt.Dimension(220, 40));
        btnCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarSesionActionPerformed(evt);
            }
        });
        panelLateral.add(btnCerrarSesion);

        getContentPane().add(panelLateral, java.awt.BorderLayout.LINE_START);

        panelPrincipal.setBackground(new java.awt.Color(255, 255, 255));
        panelPrincipal.setLayout(new java.awt.BorderLayout());

        panelTitulo.setBackground(new java.awt.Color(255, 255, 255));

        lblTitulo.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        lblTitulo.setText("Mi Historial Médico");
        lblTitulo.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 20, 10, 0));
        panelTitulo.add(lblTitulo);

        panelPrincipal.add(panelTitulo, java.awt.BorderLayout.NORTH);

        panelContenido.setBackground(new java.awt.Color(255, 255, 255));
        panelContenido.setLayout(new java.awt.CardLayout());

        panelHistorial.setBackground(new java.awt.Color(255, 255, 255));

        scrollPaneHistorial.setBackground(new java.awt.Color(255, 255, 255));
        scrollPaneHistorial.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 20, 20, 20));

        tablaHistorial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "FECHA", "DOCTOR", "DIAGNÓSTICO", "TRATAMIENTO", "RECETA"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaHistorial.setRowHeight(30);
        scrollPaneHistorial.setViewportView(tablaHistorial);

        panelHistorial.add(scrollPaneHistorial);

        panelContenido.add(panelHistorial, "card2");

        panelCitas.setBackground(new java.awt.Color(255, 255, 255));

        scrollPaneCitas.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 20, 20, 20));

        tablaCitas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "FECHA", "HORA", "DOCTOR", "ESPECIALIDAD", "ESTADO", "ACCIONES"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaCitas.setRowHeight(40);
        scrollPaneCitas.setViewportView(tablaCitas);

        panelCitas.add(scrollPaneCitas);

        panelContenido.add(panelCitas, "card3");

        panelNuevaCita.setBackground(new java.awt.Color(255, 255, 255));

        panelFormulario.setBackground(new java.awt.Color(255, 255, 255));
        panelFormulario.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panelFormulario.setLayout(new java.awt.GridBagLayout());

        lblEspecialidad.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblEspecialidad.setText("Especialidad");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panelFormulario.add(lblEspecialidad, gridBagConstraints);

        comboEspecialidad.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        comboEspecialidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Medicina General", "Cardiología", "Dermatología", "Pediatría", "Oftalmología", "Endocrinología", "Neurología" }));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panelFormulario.add(comboEspecialidad, gridBagConstraints);

        lblMedico.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblMedico.setText("Médico");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panelFormulario.add(lblMedico, gridBagConstraints);

        comboMedico.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dr. Carlos Rodriguez", "Dra. Ana López", "Dr. Juan Pérez", "Dra. María García" }));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panelFormulario.add(comboMedico, gridBagConstraints);

        lblFecha.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblFecha.setText("Fecha:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panelFormulario.add(lblFecha, gridBagConstraints);

        txtFecha.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        txtFecha.setText("2024-07-25");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panelFormulario.add(txtFecha, gridBagConstraints);

        lblHora.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblHora.setText("Hora:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panelFormulario.add(lblHora, gridBagConstraints);

        comboHora.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        comboHora.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "15:00", "15:30", "16:00", "16:30" }));
        comboHora.setSelectedIndex(2);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panelFormulario.add(comboHora, gridBagConstraints);

        lblMotivo.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblMotivo.setText("Motivo:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHEAST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panelFormulario.add(lblMotivo, gridBagConstraints);

        txtMotivo.setColumns(20);
        txtMotivo.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtMotivo.setRows(4);
        jScrollPane1.setViewportView(txtMotivo);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        panelFormulario.add(jScrollPane1, gridBagConstraints);

        btnAgendar.setBackground(new java.awt.Color(63, 61, 163));
        btnAgendar.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnAgendar.setForeground(new java.awt.Color(255, 255, 255));
        btnAgendar.setText("Agendar Cita");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(10, 5, 5, 5);
        panelFormulario.add(btnAgendar, gridBagConstraints);

        panelNuevaCita.add(panelFormulario);

        panelContenido.add(panelNuevaCita, "card4");

        panelAgendaDisponible.setBackground(new java.awt.Color(255, 255, 255));
        panelAgendaDisponible.setLayout(new java.awt.BorderLayout());

        panelFiltros.setBackground(new java.awt.Color(255, 255, 255));
        panelFiltros.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 20, 10, 20));
        panelFiltros.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        lblFiltroEspecialidad.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblFiltroEspecialidad.setText("Especialidad");
        panelFiltros.add(lblFiltroEspecialidad);

        comboFiltroEspecialidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todas", "Medicina General", "Cardiología", "Dermatología", "Pediatría", "Oftalmología", "Endocrinología", "Neurología" }));
        panelFiltros.add(comboFiltroEspecialidad);

        lblFiltroFecha.setText("Fecha:");
        panelFiltros.add(lblFiltroFecha);

        txtFiltroFecha.setColumns(10);
        txtFiltroFecha.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtFiltroFecha.setText("2024-07-25");
        panelFiltros.add(txtFiltroFecha);

        btnFiltrar.setBackground(new java.awt.Color(63, 61, 163));
        btnFiltrar.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnFiltrar.setForeground(new java.awt.Color(255, 255, 255));
        btnFiltrar.setText("Filtrar");
        panelFiltros.add(btnFiltrar);

        panelAgendaDisponible.add(panelFiltros, java.awt.BorderLayout.NORTH);

        scrollPaneAgenda.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 20, 20, 20));

        tablaAgenda.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "FECHA", "HORA", "MÉDICO", "ESPECIALIDAD", "RESERVAR"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaAgenda.setRowHeight(30);
        scrollPaneAgenda.setViewportView(tablaAgenda);

        panelAgendaDisponible.add(scrollPaneAgenda, java.awt.BorderLayout.CENTER);

        panelContenido.add(panelAgendaDisponible, "card5");

        panelMensajes.setBackground(new java.awt.Color(255, 255, 255));

        scrollPaneMensajes.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 20, 20, 20));

        listaMensajes.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        listaMensajes.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        listaMensajes.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        scrollPaneMensajes.setViewportView(listaMensajes);

        panelMensajes.add(scrollPaneMensajes);

        panelContenido.add(panelMensajes, "card6");

        panelPrincipal.add(panelContenido, java.awt.BorderLayout.CENTER);

        getContentPane().add(panelPrincipal, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCitasProgramadasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCitasProgramadasActionPerformed
        mostrarSeccion("citas");
    }//GEN-LAST:event_btnCitasProgramadasActionPerformed

    private void btnAgendarCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgendarCitaActionPerformed
        mostrarSeccion("nuevaCita");
    }//GEN-LAST:event_btnAgendarCitaActionPerformed

    private void btnAgendaDisponibleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgendaDisponibleActionPerformed
        mostrarSeccion("agenda");
    }//GEN-LAST:event_btnAgendaDisponibleActionPerformed

    private void btnCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarSesionActionPerformed
        // Mostrar diálogo de confirmación
        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Está seguro que desea cerrar SanArte - Portal del Paciente?",
            "Confirmar cierre",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);

        if (confirmacion == JOptionPane.YES_OPTION) {
            // Cerrar esta ventana y volver a la ventana de acceso
            this.dispose();
            new Acces().setVisible(true);
        }
    }//GEN-LAST:event_btnCerrarSesionActionPerformed

    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Paciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Paciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Paciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Paciente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Paciente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgendaDisponible;
    private javax.swing.JButton btnAgendar;
    private javax.swing.JButton btnAgendarCita;
    private javax.swing.JButton btnCerrarSesion;
    private javax.swing.JButton btnCitasProgramadas;
    private javax.swing.JButton btnFiltrar;
    private javax.swing.JComboBox<String> comboEspecialidad;
    private javax.swing.JComboBox<String> comboFiltroEspecialidad;
    private javax.swing.JComboBox<String> comboHora;
    private javax.swing.JComboBox<String> comboMedico;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblEspecialidad;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JLabel lblFiltroEspecialidad;
    private javax.swing.JLabel lblFiltroFecha;
    private javax.swing.JLabel lblHora;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblMedico;
    private javax.swing.JLabel lblMotivo;
    private javax.swing.JLabel lblNombrePaciente;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JList<String> listaMensajes;
    private javax.swing.JPanel panelAgendaDisponible;
    private javax.swing.JPanel panelCitas;
    private javax.swing.JPanel panelContenido;
    private javax.swing.JPanel panelFiltros;
    private javax.swing.JPanel panelFormulario;
    private javax.swing.JPanel panelHistorial;
    private javax.swing.JPanel panelLateral;
    private javax.swing.JPanel panelMensajes;
    private javax.swing.JPanel panelNuevaCita;
    private javax.swing.JPanel panelPrincipal;
    private javax.swing.JPanel panelTitulo;
    private javax.swing.JPanel panelUsuario;
    private javax.swing.JScrollPane scrollPaneAgenda;
    private javax.swing.JScrollPane scrollPaneCitas;
    private javax.swing.JScrollPane scrollPaneHistorial;
    private javax.swing.JScrollPane scrollPaneMensajes;
    private javax.swing.JTable tablaAgenda;
    private javax.swing.JTable tablaCitas;
    private javax.swing.JTable tablaHistorial;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtFiltroFecha;
    private java.awt.TextArea txtMotivo;
    // End of variables declaration//GEN-END:variables
}
