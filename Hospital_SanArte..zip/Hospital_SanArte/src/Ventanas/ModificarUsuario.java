/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Ventanas;

import Conexion.ConexionDB;
import Conexion.UsuarioDAO;
import Conexion.UsuarioDAO.UsuarioCompleto;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;


import Conexion.ConexionDB;
import Conexion.UsuarioDAO;
import Conexion.UsuarioDAO.UsuarioCompleto;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author socta
 */
public class ModificarUsuario extends javax.swing.JFrame {
 private UsuarioDAO usuarioDAO;
    private List<UsuarioCompleto> usuariosActuales;
    private boolean modoInsercion = false;
    private boolean modoModificacion = false;
    
    public ModificarUsuario() {
        usuarioDAO = new UsuarioDAO();
        initComponents();
        inicializarComponentes();
        personalizarComponentes();
        cargarDatosIniciales();
        
        // Personalizar botones adicionales
        personalizarBoton(btnInsertar, new Color(65, 105, 225), Color.WHITE);
        personalizarBoton(btnModificar, new Color(255, 140, 0), Color.WHITE); // Naranja
        personalizarBoton(btnEliminar, new Color(220, 20, 60), Color.WHITE);
    }
    
    /**
     * ACTUALIZAR TABLA AUTOMÁTICAMENTE
     */
    private void actualizarTabla() {
         try {
        usuariosActuales = usuarioDAO.obtenerTodosLosUsuarios();
        DefaultTableModel modelo = (DefaultTableModel) tablaUsuarios.getModel();
        modelo.setRowCount(0);  // Limpiar tabla existente
        
        for (UsuarioCompleto usuario : usuariosActuales) {
            modelo.addRow(new Object[]{
                usuario.getId(),
                usuario.getNombre(),
                usuario.getApellidos(),
                usuario.getTipoUsuario(),
                usuario.getIdentificacion(),
                usuario.getEmail()
            });
        }
        
        lblInstrucciones.setText("Total usuarios: " + usuariosActuales.size());
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
            "Error al actualizar tabla: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
    }
    }
    
    /**
     * CARGAR DATOS EN FORMULARIO DESDE TABLA
     */
    private void cargarDatosEnFormulario(int fila) {
        try {
            // Salir de cualquier modo especial
            modoInsercion = false;
            modoModificacion = false;
            btnInsertar.setText("Insertar");
            btnModificar.setText("Modificar");
            
            Long id = (Long) tablaUsuarios.getValueAt(fila, 0);
            String nombre = tablaUsuarios.getValueAt(fila, 1).toString();
            String apellidos = tablaUsuarios.getValueAt(fila, 2).toString();
            String tipoUsuario = tablaUsuarios.getValueAt(fila, 3).toString();
            String identificacion = tablaUsuarios.getValueAt(fila, 4).toString();
            String email = tablaUsuarios.getValueAt(fila, 5).toString();
            
            txtID.setText(id.toString());
            txtID.setEditable(false);
            txtNombre.setText(nombre);
            txtApellidos.setText(apellidos);
            
            // Buscar índice del tipo de usuario en el combo
            for (int i = 0; i < cmbTipoUsuario.getItemCount(); i++) {
                if (cmbTipoUsuario.getItemAt(i).equals(tipoUsuario)) {
                    cmbTipoUsuario.setSelectedIndex(i);
                    break;
                }
            }
            
            txtIdentificacion.setText(identificacion);
            txtEmail.setText(email);
            lblFormulario.setText("Usuario Seleccionado - " + nombre + " " + apellidos);
        } catch (Exception e) {
            System.err.println("Error al cargar datos: " + e.getMessage());
            JOptionPane.showMessageDialog(this,
                "Error al cargar datos del usuario seleccionado",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * LIMPIAR FORMULARIO
     */
    private void limpiarFormulario() {
        txtID.setText("");
    txtNombre.setText("");
    txtApellidos.setText("");
    txtIdentificacion.setText("");
    txtEmail.setText("");
    txtBusqueda.setText("");
    
    if (cmbTipoUsuario.getItemCount() > 0) {
        cmbTipoUsuario.setSelectedIndex(0);
    }
    
    modoInsercion = false;
    modoModificacion = false;
    btnInsertar.setText("Insertar");
    btnModificar.setText("Modificar");
    lblFormulario.setText("Datos del Usuario");
    }
    
    /**
     * PREPARAR MODO INSERCIÓN CON ID AUTO-GENERADO
     */
    private void prepararModoInsercion() {
         modoInsercion = true;
    limpiarFormulario();
    
    // Generar ID provisional
    Long proximoId = usuarioDAO.generarProximoId();
    txtID.setText(proximoId != null ? proximoId.toString() : "Auto-generado");
    txtID.setEditable(false);
    
    btnInsertar.setText("Guardar Nuevo");
    lblFormulario.setText("Nuevo Usuario - Complete los datos");
    txtNombre.requestFocus();
    }
    
    /**
     * PREPARAR MODO MODIFICACIÓN
     */
    private void prepararModoModificacion() {
        // Verificar que hay un usuario seleccionado
        int filaSeleccionada = tablaUsuarios.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this,
                "⚠ Por favor, seleccione un usuario de la tabla para modificar",
                "Selección requerida",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        modoModificacion = true;
        modoInsercion = false;
        btnModificar.setText("Confirmar Modificación");
        btnInsertar.setText("Insertar");
        
        // Cargar datos del usuario seleccionado
        cargarDatosEnFormulario(filaSeleccionada);
        lblFormulario.setText("Modificando Usuario - Complete los cambios");
        
        // Enfocar el primer campo editable
        txtNombre.requestFocus();
    }
    
    /**
     * INICIALIZAR COMPONENTES
     */
    private void inicializarComponentes() {
        cmbCriterioBusqueda.removeAllItems();
        cmbCriterioBusqueda.addItem("Nombre");
        cmbCriterioBusqueda.addItem("Apellidos");
        cmbCriterioBusqueda.addItem("Identificación");
        cmbCriterioBusqueda.addItem("Tipo de Usuario");
        
        // Cargar tipos de usuario desde BD
        cmbTipoUsuario.removeAllItems();
        try {
            List<String> tipos = usuarioDAO.obtenerTiposUsuario();
            for (String tipo : tipos) {
                cmbTipoUsuario.addItem(tipo);
            }
        } catch (Exception e) {
            System.err.println("Error al cargar tipos de usuario: " + e.getMessage());
            JOptionPane.showMessageDialog(this,
                "Error al cargar tipos de usuario",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
        
        tablaUsuarios.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        this.setLocationRelativeTo(null);
        
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                btnVolverActionPerformed(null);
            }
        });
    }
    
    /**
     * PERSONALIZAR COMPONENTES
     */
    private void personalizarComponentes() {
  
        
        personalizarBoton(btnLimpiar, new Color(255, 165, 0), Color.WHITE);
        personalizarBoton(btnVolver, new Color(0, 51, 102), Color.WHITE);
        personalizarBoton(btnBuscar, new Color(100, 149, 237), Color.WHITE);
        
        tablaUsuarios.setRowHeight(25);
        tablaUsuarios.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        tablaUsuarios.getTableHeader().setBackground(new Color(70, 130, 180));
        tablaUsuarios.getTableHeader().setForeground(Color.WHITE);
    }
    
    /**
     * PERSONALIZAR BOTÓN
     */
    private void personalizarBoton(JButton boton, Color fondo, Color texto) {
        boton.setBackground(fondo);
        boton.setForeground(texto);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createRaisedBevelBorder(),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(mezclarColores(fondo, Color.BLACK, 0.1f));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(fondo);
            }
        });
    }
    
    /**
     * MEZCLAR COLORES
     */
    private Color mezclarColores(Color color1, Color color2, float porcentaje) {
        int r = (int) (color1.getRed() * (1 - porcentaje) + color2.getRed() * porcentaje);
        int g = (int) (color1.getGreen() * (1 - porcentaje) + color2.getGreen() * porcentaje);
        int b = (int) (color1.getBlue() * (1 - porcentaje) + color2.getBlue() * porcentaje);
        return new Color(r, g, b);
    }
    
    /**
     * CARGAR DATOS INICIALES
     */
    private void cargarDatosIniciales() {
        try {
            List<UsuarioCompleto> usuarios = usuarioDAO.obtenerTodosLosUsuarios();
            cargarUsuarios(usuarios);
        } catch (Exception e) {
            System.err.println("Error al cargar datos iniciales: " + e.getMessage());
            JOptionPane.showMessageDialog(this,
                "Error al cargar datos iniciales: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * CARGAR USUARIOS EN TABLA
     */
    private void cargarUsuarios(List<UsuarioCompleto> usuarios) {
        usuariosActuales = usuarios;
        
        String[] columnas = {"ID", "Nombre", "Apellidos", "Tipo Usuario", "Identificación", "Email"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        for (UsuarioCompleto usuario : usuarios) {
            Object[] fila = {
                usuario.getId(),
                usuario.getNombre(),
                usuario.getApellidos(),
                usuario.getTipoUsuario(),
                usuario.getIdentificacion(),
                usuario.getEmail()
            };
            modelo.addRow(fila);
        }
        
        tablaUsuarios.setModel(modelo);
        
        if (tablaUsuarios.getColumnCount() > 0) {
            tablaUsuarios.getColumnModel().getColumn(0).setPreferredWidth(50);
            tablaUsuarios.getColumnModel().getColumn(1).setPreferredWidth(100);
            tablaUsuarios.getColumnModel().getColumn(2).setPreferredWidth(100);
            tablaUsuarios.getColumnModel().getColumn(3).setPreferredWidth(120);
            tablaUsuarios.getColumnModel().getColumn(4).setPreferredWidth(100);
            tablaUsuarios.getColumnModel().getColumn(5).setPreferredWidth(180);
        }
        
        lblInstrucciones.setText(
            String.format("Se encontraron %d usuarios. Seleccione uno para ver/modificar", usuarios.size())
        );
        
        tablaUsuarios.revalidate();
        tablaUsuarios.repaint();
    }
    
    /**
     * GENERAR USUARIO SISTEMA
     */
    private String generarUsuarioSistema(UsuarioCompleto usuario) {
        return usuarioDAO.generarUsuarioSistemaUnico(usuario.getNombre(), usuario.getApellidos());
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelTitulo = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        panelPrincipal = new javax.swing.JPanel();
        lblBusqueda = new javax.swing.JLabel();
        txtBusqueda = new javax.swing.JTextField();
        lblCriterioBusqueda = new javax.swing.JLabel();
        cmbCriterioBusqueda = new javax.swing.JComboBox<>();
        btnBuscar = new javax.swing.JButton();
        scrollTabla = new java.awt.ScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaUsuarios = new javax.swing.JTable();
        lblInstrucciones = new javax.swing.JLabel();
        separador = new javax.swing.JSeparator();
        lblFormulario = new javax.swing.JLabel();
        lblID = new javax.swing.JLabel();
        txtID = new javax.swing.JTextField();
        lblNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lblApellidos = new javax.swing.JLabel();
        txtApellidos = new javax.swing.JTextField();
        lblTipoUsuario = new javax.swing.JLabel();
        cmbTipoUsuario = new javax.swing.JComboBox<>();
        lblIdentificacion = new javax.swing.JLabel();
        txtIdentificacion = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        panelBotones = new javax.swing.JPanel();
        btnInsertar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Modificar Usuario");

        panelTitulo.setBackground(new java.awt.Color(70, 130, 180));
        panelTitulo.setPreferredSize(new java.awt.Dimension(800, 60));
        panelTitulo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitulo.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(255, 255, 255));
        lblTitulo.setText("Modificar Usuario");
        panelTitulo.add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 20, 230, 30));

        getContentPane().add(panelTitulo, java.awt.BorderLayout.PAGE_START);

        panelPrincipal.setBackground(new java.awt.Color(240, 240, 255));
        panelPrincipal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblBusqueda.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblBusqueda.setText("Buscar Usuario");
        panelPrincipal.add(lblBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, 120, 25));
        panelPrincipal.add(txtBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 30, 250, 25));

        lblCriterioBusqueda.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblCriterioBusqueda.setText("Criterio");
        panelPrincipal.add(lblCriterioBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 30, 80, 25));

        cmbCriterioBusqueda.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        panelPrincipal.add(cmbCriterioBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 30, 150, 25));

        btnBuscar.setBackground(new java.awt.Color(100, 149, 237));
        btnBuscar.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        panelPrincipal.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 30, 80, 25));

        tablaUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"1", "Juan", "Pérez", "Doctor", "12345678", "juan.perez@ejemplo.com"},
                {"2", "María", "López", "Enfermera", "87654321", "maria.lopez@ejemplo.com](mailto:maria.lopez@ejemplo.com"},
                {"3", "Carlos", "Rodríguez", "Administrativo", "13579246", "carlos.rodriguez@ejemplo.com"},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Apellidos", "Tipo Usuario", "Identificación", "Email"
            }
        ));
        tablaUsuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaUsuariosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaUsuarios);

        scrollTabla.add(jScrollPane1);

        panelPrincipal.add(scrollTabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 700, 150));

        lblInstrucciones.setFont(new java.awt.Font("Arial", 2, 12)); // NOI18N
        lblInstrucciones.setForeground(new java.awt.Color(80, 80, 80));
        lblInstrucciones.setText("Seleccione un usuario de la tabla y modifique sus datos en el formulario.");
        panelPrincipal.add(lblInstrucciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 240, 700, 20));
        panelPrincipal.add(separador, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 270, 700, 10));

        lblFormulario.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        lblFormulario.setText("Datos del Usuario");
        panelPrincipal.add(lblFormulario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, 200, 25));

        lblID.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblID.setText("ID");
        panelPrincipal.add(lblID, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 330, 100, 25));

        txtID.setEditable(false);
        panelPrincipal.add(txtID, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 330, 100, 25));

        lblNombre.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblNombre.setText("Nombre");
        panelPrincipal.add(lblNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 370, 100, 25));
        panelPrincipal.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 370, 200, 25));

        lblApellidos.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblApellidos.setText("Apellidos");
        panelPrincipal.add(lblApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 410, 100, 25));
        panelPrincipal.add(txtApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 410, 200, 25));

        lblTipoUsuario.setText("Tipo Usuario");
        panelPrincipal.add(lblTipoUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 330, 120, 25));

        cmbTipoUsuario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        panelPrincipal.add(cmbTipoUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 330, 120, 25));

        lblIdentificacion.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblIdentificacion.setText("Identificación");
        panelPrincipal.add(lblIdentificacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 370, 120, 25));
        panelPrincipal.add(txtIdentificacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 370, 120, 25));

        lblEmail.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblEmail.setText("Email");
        panelPrincipal.add(lblEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 410, 120, 25));
        panelPrincipal.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 410, 200, 25));

        getContentPane().add(panelPrincipal, java.awt.BorderLayout.CENTER);

        panelBotones.setBackground(new java.awt.Color(70, 130, 180));
        panelBotones.setPreferredSize(new java.awt.Dimension(600, 60));

        btnInsertar.setBackground(new java.awt.Color(65, 105, 225));
        btnInsertar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnInsertar.setForeground(new java.awt.Color(255, 255, 255));
        btnInsertar.setText("Insertar");
        btnInsertar.setPreferredSize(new java.awt.Dimension(120, 40));
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });
        panelBotones.add(btnInsertar);

        btnModificar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.setPreferredSize(new java.awt.Dimension(120, 40));
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        panelBotones.add(btnModificar);

        btnEliminar.setBackground(new java.awt.Color(220, 20, 60));
        btnEliminar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminar.setText("Eliminar");
        btnEliminar.setPreferredSize(new java.awt.Dimension(120, 40));
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        panelBotones.add(btnEliminar);

        btnLimpiar.setBackground(new java.awt.Color(255, 165, 0));
        btnLimpiar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpiar.setText("Limpiar");
        btnLimpiar.setPreferredSize(new java.awt.Dimension(120, 40));
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        panelBotones.add(btnLimpiar);

        btnVolver.setBackground(new java.awt.Color(0, 51, 102));
        btnVolver.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver");
        btnVolver.setPreferredSize(new java.awt.Dimension(120, 40));
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        panelBotones.add(btnVolver);

        getContentPane().add(panelBotones, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tablaUsuariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaUsuariosMouseClicked
         // Obtener la fila seleccionada
        int filaSeleccionada = tablaUsuarios.getSelectedRow();
        
        // Si hay una fila seleccionada, cargar los datos en el formulario
        if (filaSeleccionada != -1) {
            cargarDatosEnFormulario(filaSeleccionada);
        }
    }//GEN-LAST:event_tablaUsuariosMouseClicked

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        // Limpiar todos los campos del formulario
        limpiarFormulario();
        
        // Limpiar selección de la tabla
        tablaUsuarios.clearSelection();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
           // Cerrar esta ventana y volver a la ventana de administrador
        this.dispose();
        new Administrador().setVisible(true);
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String textoBusqueda = txtBusqueda.getText().trim();
        if (textoBusqueda.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Por favor ingrese un texto para buscar", 
                "Campo vacío", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String criterio = cmbCriterioBusqueda.getSelectedItem().toString();
        
        try {
            List<UsuarioCompleto> usuariosEncontrados = 
                usuarioDAO.buscarUsuarios(textoBusqueda, criterio);
            
            cargarUsuarios(usuariosEncontrados);
            
            if (usuariosEncontrados.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "No se encontraron usuarios con los criterios especificados",
                    "Sin resultados",
                    JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error al buscar usuarios: " + e.getMessage(),
                "Error de búsqueda",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarActionPerformed
        // Modo preparación: activar modo inserción
    if (!modoInsercion) {
        prepararModoInsercion();
        return;
    }

    // Validar campos obligatorios
    if (txtNombre.getText().trim().isEmpty() || 
        txtApellidos.getText().trim().isEmpty() || 
        txtIdentificacion.getText().trim().isEmpty() || 
        txtEmail.getText().trim().isEmpty()) {
        
        JOptionPane.showMessageDialog(this, 
            "❌ Todos los campos son obligatorios\nComplete toda la información", 
            "Campos incompletos", 
            JOptionPane.WARNING_MESSAGE);
        return;
    }

    // Validar formato de email
    if (!validarFormatoEmail(txtEmail.getText().trim())) {
        JOptionPane.showMessageDialog(this, 
            "❌ Formato de email inválido\nEjemplo válido: usuario@dominio.com", 
            "Email incorrecto", 
            JOptionPane.WARNING_MESSAGE);
        txtEmail.requestFocus();
        return;
    }

    try {
        // Obtener datos del formulario
        String nombre = txtNombre.getText().trim();
        String apellidos = txtApellidos.getText().trim();
        String identificacion = txtIdentificacion.getText().trim();
        String email = txtEmail.getText().trim();
        String tipoUsuario = cmbTipoUsuario.getSelectedItem().toString();

        // Verificar duplicados
        if (usuarioDAO.existeIdentificacion(identificacion)) {
            JOptionPane.showMessageDialog(this, 
                "❌ Identificación ya registrada: " + identificacion, 
                "Duplicado", 
                JOptionPane.WARNING_MESSAGE);
            txtIdentificacion.requestFocus();
            return;
        }
        
        if (usuarioDAO.existeEmail(email)) {
            JOptionPane.showMessageDialog(this, 
                "❌ Email ya registrado: " + email, 
                "Duplicado", 
                JOptionPane.WARNING_MESSAGE);
            txtEmail.requestFocus();
            return;
        }

        // Crear nuevo usuario
        UsuarioCompleto nuevoUsuario = new UsuarioCompleto();
        nuevoUsuario.setNombre(nombre);
        nuevoUsuario.setApellidos(apellidos);
        nuevoUsuario.setIdentificacion(identificacion);
        nuevoUsuario.setEmail(email);
        nuevoUsuario.setTipoUsuario(tipoUsuario);
        
        // Generar usuario sistema único
        String usuarioSistema = generarUsuarioSistemaUnico(nombre, apellidos);
        nuevoUsuario.setUsuarioSistema(usuarioSistema);
        
        // Obtener ID del tipo de usuario
        Long tipoUsuarioId = usuarioDAO.obtenerIdTipoUsuario(tipoUsuario);
        if (tipoUsuarioId == null) {
            JOptionPane.showMessageDialog(this, 
                "❌ Tipo de usuario no válido", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Confirmar inserción
        int confirmacion = JOptionPane.showConfirmDialog(this,
            "¿Confirmar inserción de nuevo usuario?\n\n" +
            "Nombre: " + nombre + " " + apellidos + "\n" +
            "Identificación: " + identificacion + "\n" +
            "Email: " + email + "\n" +
            "Tipo: " + tipoUsuario + "\n" +
            "Usuario sistema: " + usuarioSistema,
            "Confirmar inserción",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        // Insertar en base de datos
        boolean resultado = usuarioDAO.insertarUsuario(nuevoUsuario, tipoUsuarioId);
        
        if (resultado) {
            JOptionPane.showMessageDialog(this,
                "✅ Usuario insertado correctamente!\n" +
                "Usuario sistema: " + usuarioSistema,
                "Inserción exitosa",
                JOptionPane.INFORMATION_MESSAGE);
            
            // Actualizar tabla
            actualizarTabla();
            
            // Limpiar formulario y salir del modo inserción
            limpiarFormulario();
            modoInsercion = false;
            btnInsertar.setText("Insertar");
        } else {
            JOptionPane.showMessageDialog(this,
                "❌ Error al insertar usuario\nVerifique la conexión con la base de datos",
                "Error de inserción",
                JOptionPane.ERROR_MESSAGE);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
            "❌ Error crítico: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}       

// Método para generar usuario único
private String generarUsuarioSistemaUnico(String nombre, String apellidos) {
    String baseUsuario = (nombre.charAt(0) + apellidos.split(" ")[0]).toLowerCase();
    String usuario = baseUsuario;
    int contador = 1;
    
    while (usuarioDAO.existeUsuarioSistema(usuario)) {
        usuario = baseUsuario + contador;
        contador++;
    }
    return usuario;
}

// Método para validar email
private boolean validarFormatoEmail(String email) {
    return email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$");
    }//GEN-LAST:event_btnInsertarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
         // Verificar si hay una fila seleccionada
        int filaSeleccionada = tablaUsuarios.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this,
                "⚠ Por favor, seleccione un usuario de la tabla",
                "Selección requerida", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            // Obtener datos del usuario seleccionado
            Long usuarioId = (Long) tablaUsuarios.getValueAt(filaSeleccionada, 0);
            String nombreUsuario = tablaUsuarios.getValueAt(filaSeleccionada, 1).toString();
            String apellidosUsuario = tablaUsuarios.getValueAt(filaSeleccionada, 2).toString();
            String tipoUsuario = tablaUsuarios.getValueAt(filaSeleccionada, 3).toString();
            
            // Confirmar eliminación
            int confirmacion = JOptionPane.showConfirmDialog(this,
                "🗑 ¿Está seguro que desea eliminar al usuario?\n\n" +
                "👤 Nombre: " + nombreUsuario + " " + apellidosUsuario + "\n" +
                "🏷 Tipo: " + tipoUsuario + "\n\n" +
                "Esta acción desactivará el usuario en el sistema.",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            
            if (confirmacion == JOptionPane.YES_OPTION) {
                // Eliminar usuario de la base de datos
                if (usuarioDAO.eliminarUsuario(usuarioId)) {
                    JOptionPane.showMessageDialog(this,
                        "✅ Usuario eliminado correctamente\n\n" +
                        "El usuario " + nombreUsuario + " " + apellidosUsuario + 
                        " ha sido desactivado del sistema.",
                        "Eliminación exitosa",
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    // Recargar datos
                    cargarDatosIniciales();
                    
                    // Limpiar formulario
                    limpiarFormulario();
                } else {
                    JOptionPane.showMessageDialog(this,
                        "❌ Error al eliminar el usuario\n\n" +
                        "No se pudo completar la operación. Intente nuevamente.",
                        "Error de eliminación",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "❌ Error inesperado: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        // TODO add your handling code here:
         // Si no estamos en modo modificación, preparar el modo
        if (!modoModificacion) {
            prepararModoModificacion();
            return;
        }
        
        // Validar que hay un ID válido
        if (txtID.getText().isEmpty() || txtID.getText().contains("Auto-generado")) {
            JOptionPane.showMessageDialog(this,
                "Error: No hay un usuario válido seleccionado para modificar",
                "Usuario no seleccionado",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validar campos obligatorios
        if (txtNombre.getText().trim().isEmpty() || 
            txtApellidos.getText().trim().isEmpty() || 
            txtIdentificacion.getText().trim().isEmpty() || 
            txtEmail.getText().trim().isEmpty()) {
            
            JOptionPane.showMessageDialog(this,
                "Por favor complete todos los campos obligatorios",
                "Campos incompletos",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Validar email
        if (!usuarioDAO.validarFormatoEmail(txtEmail.getText().trim())) {
            JOptionPane.showMessageDialog(this,
                "Por favor ingrese un email válido",
                "Email inválido",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            Long id = Long.parseLong(txtID.getText());
            String nombre = txtNombre.getText().trim();
            String apellidos = txtApellidos.getText().trim();
            String tipoUsuario = cmbTipoUsuario.getSelectedItem().toString();
            String identificacion = txtIdentificacion.getText().trim();
            String email = txtEmail.getText().trim();
            
            // Confirmar modificación
            int confirmacion = JOptionPane.showConfirmDialog(this,
                "¿Confirma la modificación del usuario?\n\n" +
                "ID: " + id + "\n" +
                "Nombre: " + nombre + " " + apellidos + "\n" +
                "Identificación: " + identificacion + "\n" +
                "Email: " + email + "\n" +
                "Tipo: " + tipoUsuario,
                "Confirmar modificación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            
            if (confirmacion != JOptionPane.YES_OPTION) {
                return;
            }
            
            // Actualizar en base de datos
            boolean exito = usuarioDAO.actualizarUsuario(
                id, nombre, apellidos, tipoUsuario, identificacion, email);
            
            if (exito) {
                JOptionPane.showMessageDialog(this,
                    "✅ Usuario modificado correctamente\n\n" +
                    "ID: " + id + "\n" +
                    "Nombre: " + nombre + " " + apellidos,
                    "Modificación exitosa",
                    JOptionPane.INFORMATION_MESSAGE);
                
                // ✅ ACTUALIZAR TABLA AUTOMÁTICAMENTE
                actualizarTabla();
                
                // Limpiar formulario y salir del modo modificación
                limpiarFormulario();
                modoModificacion = false;
                btnModificar.setText("Modificar");
                lblFormulario.setText("Datos del Usuario");
                
                System.out.println("✅ Usuario modificado y tabla actualizada");
            } else {
                JOptionPane.showMessageDialog(this,
                    "❌ Error al modificar el usuario.\nVerifique que no existan duplicados en identificación o email.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                "ID de usuario inválido",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error inesperado: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnModificarActionPerformed


    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ModificarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ModificarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ModificarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ModificarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ModificarUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JComboBox<String> cmbCriterioBusqueda;
    private javax.swing.JComboBox<String> cmbTipoUsuario;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblApellidos;
    private javax.swing.JLabel lblBusqueda;
    private javax.swing.JLabel lblCriterioBusqueda;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblFormulario;
    private javax.swing.JLabel lblID;
    private javax.swing.JLabel lblIdentificacion;
    private javax.swing.JLabel lblInstrucciones;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblTipoUsuario;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JPanel panelBotones;
    private javax.swing.JPanel panelPrincipal;
    private javax.swing.JPanel panelTitulo;
    private java.awt.ScrollPane scrollTabla;
    private javax.swing.JSeparator separador;
    private javax.swing.JTable tablaUsuarios;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtBusqueda;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtIdentificacion;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
