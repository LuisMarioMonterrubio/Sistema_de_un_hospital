/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Ventanas;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author socta
 */
public class Sistema extends javax.swing.JFrame {

    /**
     * Creates new form Sistema
     */
    public Sistema() {
        initComponents();
        this.setLocationRelativeTo(null);
        personalizarComponentes();
        configurarEventos();
        
        // Ocultar las pestañas del JTabbedPane (opcional)
        tabbedPane.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        
        // Seleccionar la primera pestaña por defecto
        tabbedPane.setSelectedIndex(0);
        resetearColoresBotones();
        btnPacientes.setBackground(new Color(46, 139, 87)); // Verde para el botón seleccionado
    }
    
    private void personalizarComponentes() {
        // Personalizar botones
        personalizarBoton(btnPacientes);
        personalizarBoton(btnMedicos);
        personalizarBoton(btnRecetas);
        personalizarBoton(btnConsultas);
        personalizarBoton(btnConfiguracion);
        personalizarBoton(btnCerrar);
        
        // Personalizar tablas
        personalizarTabla(tablaPacientes);
        personalizarTabla(tablaMedicos);
        personalizarTabla(tablaConsultas);
    }
    private void configurarEventos() {
        // Configurar comportamiento de cierre
        this.setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                btnCerrarActionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null));
            }
        });
    }
    
    private void personalizarBoton(JButton boton) {
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createRaisedBevelBorder(),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Efecto hover
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (boton != btnCerrar) {
                    Color original = boton.getBackground();
                    boton.setBackground(mezclarColores(original, Color.WHITE, 0.2f));
                }
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                if (boton != btnCerrar && tabbedPane.getSelectedIndex() != obtenerIndicePorBoton(boton)) {
                    boton.setBackground(new Color(65, 105, 225)); // Azul
                }
            }
        });
    }
    private void personalizarTabla(JTable tabla) {
        tabla.setRowHeight(25);
        tabla.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(new Color(70, 130, 180));
        tabla.getTableHeader().setForeground(Color.WHITE);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }
    
    private Color mezclarColores(Color color1, Color color2, float porcentaje) {
        int r = (int) (color1.getRed() * (1 - porcentaje) + color2.getRed() * porcentaje);
        int g = (int) (color1.getGreen() * (1 - porcentaje) + color2.getGreen() * porcentaje);
        int b = (int) (color1.getBlue() * (1 - porcentaje) + color2.getBlue() * porcentaje);
        return new Color(r, g, b);
    }
    
    private int obtenerIndicePorBoton(JButton boton) {
        if (boton == btnPacientes) return 0;
        if (boton == btnMedicos) return 1;
        if (boton == btnRecetas) return 2;
        if (boton == btnConsultas) return 3;
        if (boton == btnConfiguracion) return 4;
        return -1;
    }
    
    private void resetearColoresBotones() {
        Color colorNormal = new Color(65, 105, 225); // Azul
        btnPacientes.setBackground(colorNormal);
        btnMedicos.setBackground(colorNormal);
        btnRecetas.setBackground(colorNormal);
        btnConsultas.setBackground(colorNormal);
        btnConfiguracion.setBackground(colorNormal);
        // No cambiamos el color del botón Cerrar
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelTitulo = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        lblLogo = new javax.swing.JLabel();
        panelLateral = new javax.swing.JPanel();
        btnPacientes = new javax.swing.JButton();
        btnMedicos = new javax.swing.JButton();
        btnRecetas = new javax.swing.JButton();
        btnConsultas = new javax.swing.JButton();
        btnConfiguracion = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();
        panelCentral = new javax.swing.JPanel();
        tabbedPane = new javax.swing.JTabbedPane();
        panelPacientes = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaPacientes = new javax.swing.JTable();
        panelMedicos = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaMedicos = new javax.swing.JTable();
        panelRecetas = new javax.swing.JPanel();
        lblPacienteReceta = new javax.swing.JLabel();
        cmbPacienteReceta = new javax.swing.JComboBox<>();
        lblMedicoReceta = new javax.swing.JLabel();
        cmbMedicoReceta = new javax.swing.JComboBox<>();
        lblDosisReceta = new javax.swing.JLabel();
        txtDosisReceta = new javax.swing.JTextField();
        lblMedicamentoReceta = new javax.swing.JLabel();
        txtMedicamentoReceta = new javax.swing.JTextField();
        lblInstruccionesReceta = new javax.swing.JLabel();
        txtInstruccionesReceta = new javax.swing.JTextField();
        btnGuardarReceta = new javax.swing.JButton();
        btnNuevaReceta = new javax.swing.JButton();
        panelConsultas = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablaConsultas = new javax.swing.JTable();
        panelConfiguracion = new javax.swing.JPanel();
        lblConfiguracionGeneral = new javax.swing.JLabel();
        chkMostrarInactivos = new javax.swing.JCheckBox();
        chkModoOscuro = new javax.swing.JCheckBox();
        lblIdioma = new javax.swing.JLabel();
        cmbIdioma = new javax.swing.JComboBox<>();
        btnGuardarConfiguracion = new javax.swing.JButton();
        btnRestaurarConfiguracion = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema");
        setPreferredSize(new java.awt.Dimension(1045, 470));
        getContentPane().setLayout(null);

        panelTitulo.setBackground(new java.awt.Color(70, 130, 180));
        panelTitulo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitulo.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(255, 255, 255));
        lblTitulo.setText("Sistema de Gestión Clínica - SanArte");
        panelTitulo.add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 15, 500, 30));
        panelTitulo.add(lblLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 5, 50, 50));

        getContentPane().add(panelTitulo);
        panelTitulo.setBounds(0, 0, 1024, 60);

        panelLateral.setBackground(new java.awt.Color(240, 248, 255));
        panelLateral.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnPacientes.setBackground(new java.awt.Color(65, 105, 255));
        btnPacientes.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        btnPacientes.setForeground(new java.awt.Color(255, 255, 255));
        btnPacientes.setText("Pacientes");
        btnPacientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPacientesActionPerformed(evt);
            }
        });
        panelLateral.add(btnPacientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 160, 50));

        btnMedicos.setBackground(new java.awt.Color(65, 105, 225));
        btnMedicos.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        btnMedicos.setForeground(new java.awt.Color(255, 255, 255));
        btnMedicos.setText("Médicos");
        btnMedicos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMedicosActionPerformed(evt);
            }
        });
        panelLateral.add(btnMedicos, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 160, 50));

        btnRecetas.setBackground(new java.awt.Color(65, 105, 255));
        btnRecetas.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        btnRecetas.setForeground(new java.awt.Color(255, 255, 255));
        btnRecetas.setText("Recetas");
        btnRecetas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecetasActionPerformed(evt);
            }
        });
        panelLateral.add(btnRecetas, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 160, 50));

        btnConsultas.setBackground(new java.awt.Color(60, 105, 255));
        btnConsultas.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        btnConsultas.setForeground(new java.awt.Color(255, 255, 255));
        btnConsultas.setText("Consultas");
        btnConsultas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultasActionPerformed(evt);
            }
        });
        panelLateral.add(btnConsultas, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 160, 50));

        btnConfiguracion.setBackground(new java.awt.Color(65, 105, 255));
        btnConfiguracion.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        btnConfiguracion.setForeground(new java.awt.Color(255, 255, 255));
        btnConfiguracion.setText("Configuración");
        btnConfiguracion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfiguracionActionPerformed(evt);
            }
        });
        panelLateral.add(btnConfiguracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 160, 60));

        btnCerrar.setBackground(new java.awt.Color(220, 20, 60));
        btnCerrar.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        btnCerrar.setForeground(new java.awt.Color(255, 255, 255));
        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });
        panelLateral.add(btnCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 160, 50));

        getContentPane().add(panelLateral);
        panelLateral.setBounds(0, 60, 200, 708);

        panelCentral.setBackground(new java.awt.Color(255, 255, 255));
        panelCentral.setMinimumSize(new java.awt.Dimension(693, 398));
        panelCentral.setLayout(new java.awt.BorderLayout());

        tabbedPane.setMinimumSize(new java.awt.Dimension(593, 398));
        tabbedPane.setPreferredSize(new java.awt.Dimension(593, 429));

        panelPacientes.setLayout(new java.awt.BorderLayout());

        tablaPacientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"1", "Juan", "Pérez López", "45", "Masculino", "555 123 4567", "juan.perez@email.com", "Calle Principal 123"},
                {"2", "María", "González Ruiz", "32", "Femenino", "555 234 5678", "maria.gonzalez@email.com", "Avenida Central 456"},
                {"3", "Carlos", "Rodríguez Sánchez", "58", "Masculino", "555 345 6789", "carlos.rodriguez@email.com", "Plaza Mayor 789"},
                {"4", "Ana", "Martínez Fernández", "27", "Femenino", "555 456 7890", "ana.martinez@email.com", "Secundaria 234"},
                {"5", "Pedro", "López García", "41", "Masculino", "555 567 8901", "pedro.lopez@email.com", "Avenida Norte 567"},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Apellidos", "Edad", "Género", "Teléfono", "Email", "Dirección"
            }
        ));
        jScrollPane1.setViewportView(tablaPacientes);

        panelPacientes.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Pacientes", panelPacientes);

        panelMedicos.setLayout(new java.awt.BorderLayout());

        tablaMedicos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"1", "Roberto", "Gómez Bolaños", "Medicina General", "555 111 2222", "roberto.gomez@clinica.com", "Lunes a Viernes 8:00-14:00"},
                {"2", "Laura", "Sánchez Pérez", "Cardiología", "555 222 3333", "laura.sanchez@clinica.com", "Martes y Jueves 15:00-20:00"},
                {"3", "Miguel", "Fernández Ruiz", "Pediatría", "555 333 4444", "miguel.fernandez@clinica.com", "Lunes, Miércoles y Viernes 9:00-17:00"},
                {"4", "Carmen", "Rodríguez López", "Dermatología", "555 444 5555", "carmen.rodriguez@clinica.com", "Miércoles 8:00-16:00"},
                {"5", "Javier", "Martínez García", "Traumatología", "555 555 6666", "javier.martinez@clinica.com", "Jueves y Viernes 10:00-18:00"},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Apellidos", "Especialidad", "Teléfono", "Email", "Horario"
            }
        ));
        jScrollPane2.setViewportView(tablaMedicos);

        panelMedicos.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Médicos", panelMedicos);

        panelRecetas.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblPacienteReceta.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        lblPacienteReceta.setText("Paciente");
        panelRecetas.add(lblPacienteReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        cmbPacienteReceta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        panelRecetas.add(cmbPacienteReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 15, -1, -1));

        lblMedicoReceta.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        lblMedicoReceta.setText("Médico");
        panelRecetas.add(lblMedicoReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 20, -1, -1));

        cmbMedicoReceta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        panelRecetas.add(cmbMedicoReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 15, -1, -1));

        lblDosisReceta.setText("Dosis de la Receta");
        panelRecetas.add(lblDosisReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));
        panelRecetas.add(txtDosisReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 500, 20));

        lblMedicamentoReceta.setText("Medicamento");
        panelRecetas.add(lblMedicamentoReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));
        panelRecetas.add(txtMedicamentoReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 500, 20));

        lblInstruccionesReceta.setText("Instrucciones");
        panelRecetas.add(lblInstruccionesReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));
        panelRecetas.add(txtInstruccionesReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, 500, 20));

        btnGuardarReceta.setText("Guardar Receta");
        panelRecetas.add(btnGuardarReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, -1, -1));

        btnNuevaReceta.setText("Nueva Receta");
        panelRecetas.add(btnNuevaReceta, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 340, -1, -1));

        tabbedPane.addTab("Recetas", panelRecetas);

        panelConsultas.setLayout(new java.awt.BorderLayout());

        tablaConsultas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"1", "2023-05-10", "Juan Pérez López", "Roberto Gómez Bolaños", "Dolor de cabeza", "Migraña", "Paracetamol 500mg cada 8 horas"},
                {"2", "2023-05-12", "María González Ruiz", "Laura Sánchez Pérez", "Dolor en el pecho", "Ansiedad", "Ejercicios de respiración y seguimiento"},
                {"3", "2023-05-15", "Carlos Rodríguez Sánchez", "Miguel Fernández Ruiz", "Fiebre alta", "Gripe", "Ibuprofeno 400mg cada 6 horas y reposo"},
                {"4", "2023-05-18", "Ana Martínez Fernández", "Carmen Rodríguez López", "Erupción cutánea", "Dermatitis", "Crema hidrocortisona 1% dos veces al día"},
                {"5", "2023-05-20", "Pedro López García", "Javier Martínez García", "Dolor en rodilla", "Esguince leve", "Reposo y aplicación de hielo"},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Fecha", "Paciente", "Médico", "Motivo", "Diagnóstico", "Tratamiento"
            }
        ));
        jScrollPane3.setViewportView(tablaConsultas);

        panelConsultas.add(jScrollPane3, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Consultas", panelConsultas);

        panelConfiguracion.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblConfiguracionGeneral.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lblConfiguracionGeneral.setText("Configuración General");
        panelConfiguracion.add(lblConfiguracionGeneral, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, 300, 30));

        chkMostrarInactivos.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        chkMostrarInactivos.setText("Mostrar usuarios inactivos");
        panelConfiguracion.add(chkMostrarInactivos, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 300, 30));

        chkModoOscuro.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        chkModoOscuro.setText("Modo oscuro");
        panelConfiguracion.add(chkModoOscuro, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 300, -1));

        lblIdioma.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblIdioma.setText("Idioma");
        panelConfiguracion.add(lblIdioma, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 100, 30));

        cmbIdioma.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Español", "English", "Français", "Português" }));
        panelConfiguracion.add(cmbIdioma, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 170, 200, 30));

        btnGuardarConfiguracion.setBackground(new java.awt.Color(46, 139, 87));
        btnGuardarConfiguracion.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnGuardarConfiguracion.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardarConfiguracion.setText("Guardar Configuración");
        btnGuardarConfiguracion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarConfiguracionActionPerformed(evt);
            }
        });
        panelConfiguracion.add(btnGuardarConfiguracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, 200, 40));

        btnRestaurarConfiguracion.setBackground(new java.awt.Color(70, 130, 180));
        btnRestaurarConfiguracion.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnRestaurarConfiguracion.setForeground(new java.awt.Color(255, 255, 255));
        btnRestaurarConfiguracion.setText("Restaurar Valores Predeterminados");
        btnRestaurarConfiguracion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRestaurarConfiguracionActionPerformed(evt);
            }
        });
        panelConfiguracion.add(btnRestaurarConfiguracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 250, 300, 40));

        tabbedPane.addTab("Configuración", panelConfiguracion);

        panelCentral.add(tabbedPane, java.awt.BorderLayout.PAGE_START);

        getContentPane().add(panelCentral);
        panelCentral.setBounds(200, 60, 824, 708);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPacientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPacientesActionPerformed
        // Cambiar a la pestaña Pacientes
        tabbedPane.setSelectedIndex(0);

        // Cambiar color de botones para mostrar el seleccionado
        resetearColoresBotones();
        btnPacientes.setBackground(new Color(46, 139, 87)); // Verde para el botón seleccionado
    }//GEN-LAST:event_btnPacientesActionPerformed

    private void btnMedicosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMedicosActionPerformed
        // Cambiar a la pestaña Médicos
        tabbedPane.setSelectedIndex(1);

        // Cambiar color de botones para mostrar el seleccionado
        resetearColoresBotones();
        btnMedicos.setBackground(new Color(46, 139, 87)); // Verde para el botón seleccionado
    }//GEN-LAST:event_btnMedicosActionPerformed

    private void btnRecetasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecetasActionPerformed
        // Cambiar a la pestaña Recetas
        tabbedPane.setSelectedIndex(2);

        // Cambiar color de botones para mostrar el seleccionado
        resetearColoresBotones();
        btnRecetas.setBackground(new Color(46, 139, 87)); // Verde para el botón seleccionado
    }//GEN-LAST:event_btnRecetasActionPerformed

    private void btnConsultasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultasActionPerformed
        // Cambiar a la pestaña Consultas
        tabbedPane.setSelectedIndex(3);

        // Cambiar color de botones para mostrar el seleccionado
        resetearColoresBotones();
        btnConsultas.setBackground(new Color(46, 139, 87)); // Verde para el botón seleccionado
    }//GEN-LAST:event_btnConsultasActionPerformed

    private void btnConfiguracionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfiguracionActionPerformed
        // Cambiar a la pestaña Configuración
        tabbedPane.setSelectedIndex(4);

        // Cambiar color de botones para mostrar el seleccionado
        resetearColoresBotones();
        btnConfiguracion.setBackground(new Color(46, 139, 87)); // Verde para el botón seleccionado
    }//GEN-LAST:event_btnConfiguracionActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        // Mostrar diálogo de confirmación
        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Está seguro que desea cerrar el Sistema de Gestión Clínica?",
            "Confirmar cierre",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);

        if (confirmacion == JOptionPane.YES_OPTION) {
            // Cerrar esta ventana y volver a la ventana de acceso
            this.dispose();
            new Acces().setVisible(true);
        }
    }//GEN-LAST:event_btnCerrarActionPerformed

    private void btnGuardarConfiguracionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarConfiguracionActionPerformed
        // Mostrar mensaje de éxito
        JOptionPane.showMessageDialog(this,
            "Configuración guardada correctamente",
            "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnGuardarConfiguracionActionPerformed

    private void btnRestaurarConfiguracionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRestaurarConfiguracionActionPerformed
        // Restaurar valores predeterminados
        chkMostrarInactivos.setSelected(true);
        chkModoOscuro.setSelected(false);
        cmbIdioma.setSelectedIndex(0);

        // Mostrar mensaje
        JOptionPane.showMessageDialog(this,
            "Se han restaurado los valores predeterminados",
            "Restauración completada", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnRestaurarConfiguracionActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Sistema().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnConfiguracion;
    private javax.swing.JButton btnConsultas;
    private javax.swing.JButton btnGuardarConfiguracion;
    private javax.swing.JButton btnGuardarReceta;
    private javax.swing.JButton btnMedicos;
    private javax.swing.JButton btnNuevaReceta;
    private javax.swing.JButton btnPacientes;
    private javax.swing.JButton btnRecetas;
    private javax.swing.JButton btnRestaurarConfiguracion;
    private javax.swing.JCheckBox chkModoOscuro;
    private javax.swing.JCheckBox chkMostrarInactivos;
    private javax.swing.JComboBox<String> cmbIdioma;
    private javax.swing.JComboBox<String> cmbMedicoReceta;
    private javax.swing.JComboBox<String> cmbPacienteReceta;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblConfiguracionGeneral;
    private javax.swing.JLabel lblDosisReceta;
    private javax.swing.JLabel lblIdioma;
    private javax.swing.JLabel lblInstruccionesReceta;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblMedicamentoReceta;
    private javax.swing.JLabel lblMedicoReceta;
    private javax.swing.JLabel lblPacienteReceta;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JPanel panelCentral;
    private javax.swing.JPanel panelConfiguracion;
    private javax.swing.JPanel panelConsultas;
    private javax.swing.JPanel panelLateral;
    private javax.swing.JPanel panelMedicos;
    private javax.swing.JPanel panelPacientes;
    private javax.swing.JPanel panelRecetas;
    private javax.swing.JPanel panelTitulo;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JTable tablaConsultas;
    private javax.swing.JTable tablaMedicos;
    private javax.swing.JTable tablaPacientes;
    private javax.swing.JTextField txtDosisReceta;
    private javax.swing.JTextField txtInstruccionesReceta;
    private javax.swing.JTextField txtMedicamentoReceta;
    // End of variables declaration//GEN-END:variables
}
